# Kid Arcade

**Kid-made · family co-design · Grok Build**

Public browser arcade: **Mac** + **Phone** emulators and a full set of games.  
Open a link → play on phone, iPad, or desktop. No install. No API keys required.

| | |
|--|--|
| **Family GitHub** | [AI-Fam-Coders](https://github.com/AI-Fam-Coders) |
| **Play (Pages)** | https://ai-fam-coders.github.io/kid-arcade/ |
| **Mac only (Pages)** | https://ai-fam-coders.github.io/mac-simulator/ |
| **Credit** | the kids · family co-design · Grok Build |

---

## Play now

| Link | What |
|------|------|
| [**Lobby**](https://ai-fam-coders.github.io/kid-arcade/) | All emulators + games |
| [**Mac Simulator**](https://ai-fam-coders.github.io/mac-simulator/) | Desktop boots straight into Games |
| [**Phone Simulator**](https://ai-fam-coders.github.io/kid-arcade/apps/phone-simulator/) | Phone shell + Arcade + Messages |
| [Games folder](https://ai-fam-coders.github.io/kid-arcade/games/) | Direct game URLs |

### Emulators

- **Mac** — Dock, Finder (Games folder), Messages (offline presets), every game opens **in a window**
- **Phone** — unlock, Messages presets, Arcade list

### Games (selection)

I Am Bird · I Am Monkey · BLOXY Classic · I Am Cat · Job Sim · Day Life Sim · Minecraft Grass · Presscoin · Pixel Noob Player · Pixl Singing Monsters · Roblox 2016 Web · Kinito Pixel Pet · Verity 3am Knock · AI City Collapse · Bloxy Multiplayer (solo) · Rec Room Arkhē

---

## Privacy

We **never** publish:

- Real names of children or family  
- Ages  
- Location / school  
- Face photos or household contact  

Public credit only: **the kids**, **family co-design**, **kid-led**.

Full policy: [AI-Fam-Coders/.github PRIVACY](https://github.com/AI-Fam-Coders/.github/blob/main/PRIVACY.md)

---

## How it works (visitors)

| Feature | Behavior |
|---------|----------|
| Chat / Messages / bots | **Offline presets** (always works) |
| Optional local Ollama | Advanced only — not required |
| Controls | Keyboard + mouse + touch where supported |
| Gore | Removed in public builds (stars / comedy) |
| Sign-in screens | Cosmetic only (no real accounts) |

---

## Run locally

```bash
# clone this repo, then:
python3 -m http.server 8800 --bind 127.0.0.1
```

- Lobby: http://127.0.0.1:8800/  
- Mac (in pack): http://127.0.0.1:8800/mac/  
- Phone: http://127.0.0.1:8800/apps/phone-simulator/  

---

## Repo layout

```
index.html          ← lobby
mac/                ← standalone Mac site (also published as mac-simulator)
apps/phone-simulator/
games/              ← all public titles
shared/             ← chat presets + mobile controls
```

| Doc | Purpose |
|-----|---------|
| [PRODUCT.md](./PRODUCT.md) | Public product bar |
| [ORIGIN.md](./ORIGIN.md) | Map to local canon (not required to play) |

---

## Related repos

| Repo | Role |
|------|------|
| [kid-arcade](https://github.com/AI-Fam-Coders/kid-arcade) | This site — full lobby + emulators + games |
| [mac-simulator](https://github.com/AI-Fam-Coders/mac-simulator) | Mac-only Pages root |
| [family-arcade](https://github.com/AI-Fam-Coders/family-arcade) | Catalog hub by AI tool |

---

<p align="center"><strong>Built with curiosity · powered by AI · led by the kids</strong></p>
