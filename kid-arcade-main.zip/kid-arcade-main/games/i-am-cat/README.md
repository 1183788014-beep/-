# I Am Cat-ish (Arkhe)


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

Cat **POV** house sandbox inspired by *I Am Cat*. **Not affiliated.**

## Play

```bash
cd projects/creative-visualizers-and-games/i-am-cat-arkhe
python3 -m http.server 8778
```

Open http://127.0.0.1:8778/

## Controls

| Key | Action |
|-----|--------|
| WASD | Prowl |
| Mouse | Look |
| Space | Jump |
| Shift | Sprint |
| **F** | Scratch (makes granny angry) |
| **R** | Grab / drop object |

## Loop

1. Scratch granny / mess with the house  
2. **Jump + sprint into her** to knock her out (whole-body ragdoll)  
3. She wakes up in **frying pan rage** and chases you  

Comedy only — not realistic violence.
