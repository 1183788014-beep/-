/**
 * I Am Cat-ish — cat POV house chaos with granny
 * Inspired by I Am Cat (not affiliated)
 */
(function () {
  'use strict';

  const canvas = document.getElementById('c');
  const overlay = document.getElementById('overlay');
  const btnStart = document.getElementById('btn-start');
  const chaosEl = document.getElementById('chaos');
  const heldEl = document.getElementById('held');
  const moodEl = document.getElementById('mood');
  const toastEl = document.getElementById('toast');

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.setClearColor(0x2a2018, 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x3a3028, 8, 28);

  // Cat POV — low to ground, slightly wide
  const camera = new THREE.PerspectiveCamera(80, 1, 0.05, 80);
  camera.rotation.order = 'YXZ';

  scene.add(new THREE.AmbientLight(0xffe8d0, 0.55));
  const sun = new THREE.DirectionalLight(0xfff0e0, 0.7);
  sun.position.set(4, 10, 2);
  scene.add(sun);
  const lamp = new THREE.PointLight(0xffcc88, 0.9, 18, 2);
  lamp.position.set(0, 2.4, 0);
  scene.add(lamp);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function mat(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function box(w, h, d, c) {
    return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c));
  }

  // ——— house ———
  const HOUSE = { minX: -6.5, maxX: 6.5, minZ: -5.5, maxZ: 5.5 };
  const colliders = []; // AABB {min,max}

  function addSolid(mesh, solid) {
    scene.add(mesh);
    if (solid !== false) {
      mesh.updateMatrixWorld(true);
      const b = new THREE.Box3().setFromObject(mesh);
      colliders.push({ min: b.min.clone(), max: b.max.clone() });
    }
    return mesh;
  }

  function buildHouse() {
    // floor
    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(14, 0.2, 12),
      mat(0xc4a574)
    );
    floor.position.y = -0.1;
    scene.add(floor);

    // rug
    const rug = box(3.5, 0.05, 2.2, 0xb04040);
    rug.position.set(0, 0.02, 0.5);
    scene.add(rug);

    // walls
    const wallC = 0xf0e6d8;
    const walls = [
      box(14, 3.2, 0.25, wallC),
      box(14, 3.2, 0.25, wallC),
      box(0.25, 3.2, 12, wallC),
      box(0.25, 3.2, 12, wallC),
    ];
    walls[0].position.set(0, 1.6, -5.75);
    walls[1].position.set(0, 1.6, 5.75);
    walls[2].position.set(-6.75, 1.6, 0);
    walls[3].position.set(6.75, 1.6, 0);
    walls.forEach((w) => addSolid(w));

    // ceiling
    const ceil = box(14, 0.15, 12, 0xe8e0d4);
    ceil.position.y = 3.25;
    scene.add(ceil);

    // couch
    const couch = new THREE.Group();
    const seat = box(3.2, 0.45, 1.1, 0x4a6a9a);
    seat.position.set(0, 0.35, 0);
    const back = box(3.2, 0.9, 0.3, 0x3a5a8a);
    back.position.set(0, 0.85, -0.45);
    const armL = box(0.3, 0.55, 1.1, 0x3a5a8a);
    armL.position.set(-1.55, 0.5, 0);
    const armR = armL.clone();
    armR.position.x = 1.55;
    couch.add(seat, back, armL, armR);
    couch.position.set(-2.5, 0, -3.5);
    scene.add(couch);
    addSolid(box(3.4, 0.9, 1.3, 0x4a6a9a), true).position.set(-2.5, 0.45, -3.5);
    // hide collision helper material? use invisible
    colliders[colliders.length - 1]; // last was solid
    // make last collider only — re-do: invisible solid
    scene.children[scene.children.length - 1].visible = false;

    // table
    const tableTop = box(1.6, 0.1, 1.0, 0x8b5a2b);
    tableTop.position.set(2.2, 0.75, 1.2);
    addSolid(tableTop);
    for (const [lx, lz] of [[-0.65, -0.35], [0.65, -0.35], [-0.65, 0.35], [0.65, 0.35]]) {
      const leg = box(0.1, 0.75, 0.1, 0x6b4018);
      leg.position.set(2.2 + lx, 0.375, 1.2 + lz);
      addSolid(leg);
    }

    // TV stand
    const tvstand = box(2.2, 0.55, 0.55, 0x3a2a20);
    tvstand.position.set(3.5, 0.3, -4.5);
    addSolid(tvstand);
    const tv = box(1.6, 0.95, 0.12, 0x111118);
    tv.position.set(3.5, 1.1, -4.55);
    addSolid(tv);

    // fridge / kitchen counter
    const counter = box(2.8, 0.9, 0.7, 0xe8e8f0);
    counter.position.set(-4.5, 0.45, 4.5);
    addSolid(counter);
    const fridge = box(1.0, 2.0, 0.85, 0xd0d8e0);
    fridge.position.set(-5.8, 1.0, 3.2);
    addSolid(fridge);

    // windows (emissive feel)
    const win = box(1.8, 1.2, 0.08, 0x88c8ff);
    win.position.set(0, 1.8, -5.62);
    scene.add(win);
    const win2 = win.clone();
    win2.position.set(3.5, 1.8, -5.62);
    scene.add(win2);

    // doorway trim (open space to "kitchen" feel already open)

    // lamp
    const lampPole = box(0.08, 1.6, 0.08, 0xccc4b0);
    lampPole.position.set(5.2, 0.8, 2.5);
    scene.add(lampPole);
    const shade = new THREE.Mesh(new THREE.ConeGeometry(0.45, 0.5, 8), mat(0xffe0a0));
    shade.position.set(5.2, 1.7, 2.5);
    scene.add(shade);
  }
  buildHouse();

  // ——— grabbable props ———
  const props = [];
  function makeProp(name, w, h, d, color, x, y, z) {
    const mesh = box(w, h, d, color);
    mesh.position.set(x, y, z);
    scene.add(mesh);
    const p = {
      name,
      mesh,
      w, h, d,
      x, y, z,
      vx: 0, vy: 0, vz: 0,
      held: false,
      onGround: true,
    };
    props.push(p);
    return p;
  }

  makeProp('yarn ball', 0.25, 0.25, 0.25, 0xe05070, -1, 0.2, 1);
  makeProp('mug', 0.18, 0.22, 0.18, 0xf5f5f5, 2.0, 0.9, 1.1);
  makeProp('remote', 0.12, 0.05, 0.35, 0x222228, 2.4, 0.85, 1.0);
  makeProp('book', 0.28, 0.08, 0.35, 0x4060a0, 1.9, 0.85, 1.4);
  makeProp('vase', 0.2, 0.4, 0.2, 0x50a070, 3.2, 0.85, -4.3);
  makeProp('sock', 0.15, 0.08, 0.3, 0xd0a080, 0.5, 0.08, 2.5);
  makeProp('pillow', 0.45, 0.2, 0.4, 0xf0d0c0, -2.0, 0.7, -3.2);
  makeProp('can', 0.12, 0.18, 0.12, 0xc0c0c8, -4.0, 1.0, 4.4);

  // frying pan (granny weapon, also on stove until rage)
  const panMesh = box(0.55, 0.06, 0.55, 0x3a3a40);
  const panHandle = box(0.08, 0.06, 0.45, 0x2a1a10);
  panHandle.position.set(0, 0, 0.4);
  const pan = new THREE.Group();
  pan.add(panMesh, panHandle);
  pan.position.set(-4.2, 1.0, 4.5);
  scene.add(pan);

  // ——— granny ———
  const granny = {
    mesh: null,
    parts: {},
    x: 1.5, y: 0, z: -1.5,
    vx: 0, vy: 0, vz: 0,
    rx: 0, ry: 0, rz: 0,
    wx: 0, wy: 0, wz: 0,
    yaw: 0,
    // states: chill | annoyed | ko | waking | rage
    state: 'chill',
    anger: 0, // 0..100
    koTimer: 0,
    lookAwayT: 0, // seconds looking away while KO → wakes
    attackCd: 0,
    walkT: 0,
    panHeld: false,
    hitCd: 0,
  };

  function buildGranny() {
    const g = new THREE.Group();
    const dress = box(0.7, 1.0, 0.45, 0xd4688a);
    dress.position.y = 1.0;
    const head = box(0.45, 0.45, 0.42, 0xffe0c0);
    head.position.y = 1.75;
    const hair = box(0.5, 0.25, 0.48, 0xe8e0f0);
    hair.position.y = 2.05;
    const glasses = box(0.42, 0.08, 0.08, 0x333340);
    glasses.position.set(0, 1.78, 0.22);
    const legL = box(0.18, 0.55, 0.18, 0xffe0c0);
    legL.position.set(-0.15, 0.3, 0);
    const legR = box(0.18, 0.55, 0.18, 0xffe0c0);
    legR.position.set(0.15, 0.3, 0);
    const armL = box(0.14, 0.55, 0.14, 0xffe0c0);
    armL.position.set(-0.48, 1.15, 0);
    const armR = box(0.14, 0.55, 0.14, 0xffe0c0);
    armR.position.set(0.48, 1.15, 0);
    const apron = box(0.5, 0.55, 0.08, 0xf5f0e8);
    apron.position.set(0, 0.95, 0.22);
    g.add(dress, head, hair, glasses, legL, legR, armL, armR, apron);
    g.position.set(granny.x, 0, granny.z);
    scene.add(g);
    granny.mesh = g;
    granny.parts = { dress, head, hair, glasses, legL, legR, armL, armR, apron };
  }
  buildGranny();

  // ——— cat player ———
  const cat = {
    x: -1, y: 0.45, z: 2.5,
    vx: 0, vy: 0, vz: 0,
    yaw: Math.PI, pitch: 0,
    onGround: true,
    speed: 4.2,
    sprint: 7.5,
    jump: 6.2,
    radius: 0.28,
    height: 0.45, // eye height
  };
  let locked = false;
  let started = false;
  const keys = Object.create(null);
  let heldProp = null;
  let chaos = 0;
  let scratchCd = 0;
  let grabCd = 0;
  let airDash = false; // jump then forward for KO
  let airDashT = 0; // linger after jump so landing dash still counts

  // ——— cat paws (first-person arms) ———
  const paws = new THREE.Group();
  camera.add(paws);
  scene.add(camera);

  function makePaw(side) {
    const g = new THREE.Group();
    const arm = box(0.12, 0.12, 0.45, 0xe8a050);
    arm.position.set(0, 0, -0.15);
    const paw = box(0.2, 0.1, 0.22, 0xf0b060);
    paw.position.set(0, -0.02, -0.42);
    // pads
    const pad = box(0.1, 0.04, 0.1, 0xe08090);
    pad.position.set(0, -0.06, -0.42);
    g.add(arm, paw, pad);
    g.position.set(side * 0.28, -0.28, -0.35);
    g.rotation.x = 0.35;
    g.userData.side = side;
    g.userData.baseY = -0.28;
    g.userData.baseX = side * 0.28;
    paws.add(g);
    return g;
  }
  const pawL = makePaw(-1);
  const pawR = makePaw(1);
  let pawAnim = 0; // scratch / grab anim timer
  let pawMode = 'idle'; // idle | scratch | grab

  // ——— cartoon effects ———
  const sparks = [];
  function spark(x, y, z, color) {
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 4, 4),
      new THREE.MeshBasicMaterial({ color: color || 0xffee66 })
    );
    m.position.set(x, y, z);
    scene.add(m);
    sparks.push({
      mesh: m,
      x, y, z,
      vx: rand(-2, 2), vy: rand(1, 4), vz: rand(-2, 2),
      life: 0.4,
    });
  }

  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), ms || 1800);
  }

  function setMood() {
    const map = {
      chill: ['Granny: sweet as pie', 'chill'],
      annoyed: ['Granny: "Oh you naughty cat!"', 'annoyed'],
      ko: ['Granny: passed out…', 'ko'],
      waking: ['Granny: stirring…', 'annoyed'],
      rage: ['Granny: FRYING PAN RAGE!!!', 'rage'],
    };
    const [text, cls] = map[granny.state] || map.chill;
    moodEl.textContent = text;
    moodEl.className = cls;
  }

  function addChaos(n) {
    chaos += n;
    chaosEl.textContent = String(chaos);
  }

  // ——— audio ———
  const sfx = {
    ctx: null,
    ensure() {
      if (this.ctx) return;
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
    },
    beep(f, d, type, v) {
      this.ensure();
      if (this.ctx.state === 'suspended') this.ctx.resume();
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type || 'square';
      o.frequency.value = f;
      g.gain.value = v || 0.08;
      o.connect(g);
      g.connect(this.ctx.destination);
      const t = this.ctx.currentTime;
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.start(t);
      o.stop(t + d + 0.02);
    },
    meow() { this.beep(500, 0.08, 'sine', 0.1); this.beep(380, 0.12, 'sine', 0.08); },
    scratch() { this.beep(900, 0.05, 'sawtooth', 0.06); this.beep(700, 0.06, 'sawtooth', 0.05); },
    bonk() { this.beep(120, 0.15, 'triangle', 0.12); },
    rage() { this.beep(200, 0.2, 'sawtooth', 0.1); this.beep(150, 0.25, 'square', 0.08); },
  };

  // ——— granny AI ———
  function grannyStartRagdoll(ix, iy, iz) {
    if (granny.state === 'ko' || granny.state === 'waking') return;
    granny.state = 'ko';
    granny.koTimer = 20; // long failsafe only — main wake is look-away
    granny.lookAwayT = 0;
    granny.vx = ix || 0;
    granny.vy = (iy != null ? iy : 4) + 2;
    granny.vz = iz || 0;
    granny.wx = rand(-5, 5);
    granny.wy = rand(-2, 2);
    granny.wz = rand(-5, 5);
    if (granny.y < 0.6) granny.y = 0.9;
    // drop pan if holding
    if (granny.panHeld) {
      granny.panHeld = false;
      pan.position.set(granny.x, 0.2, granny.z);
      pan.rotation.set(0.4, 0, 0.3);
    }
    setMood();
    sfx.bonk();
    toast('Granny passed out! Look away a few sec… she wakes mad', 2800);
    addChaos(15);
    for (let i = 0; i < 10; i++) spark(granny.x, granny.y + 1, granny.z, 0xffe066);
  }

  /** true if cat POV is roughly looking at granny */
  function isLookingAtGranny() {
    const gx = granny.x - cat.x;
    const gy = (granny.y + 0.7) - cat.y;
    const gz = granny.z - cat.z;
    const len = Math.hypot(gx, gy, gz) || 1;
    const toG = { x: gx / len, y: gy / len, z: gz / len };
    const look = new THREE.Vector3(0, 0, -1).applyEuler(
      new THREE.Euler(cat.pitch, cat.yaw, 0, 'YXZ')
    );
    const dot = toG.x * look.x + toG.y * look.y + toG.z * look.z;
    // need her somewhat in front of view (not behind / far off-angle)
    return dot > 0.28;
  }

  function grannyWakeRage() {
    granny.state = 'rage';
    granny.anger = 100;
    granny.y = 0;
    granny.rx = 0;
    granny.rz = 0;
    granny.vx = granny.vy = granny.vz = 0;
    granny.wx = granny.wy = granny.wz = 0;
    // reset limb pose
    Object.values(granny.parts).forEach((m) => m.rotation.set(0, 0, 0));
    granny.mesh.rotation.set(0, granny.yaw, 0);
    granny.mesh.position.set(granny.x, 0, granny.z);
    // pick up frying pan
    granny.panHeld = true;
    setMood();
    sfx.rage();
    toast('She\'s awake… and she has a frying pan!', 2800);
  }

  function updateGranny(dt) {
    if (granny.hitCd > 0) granny.hitCd -= dt;
    if (granny.attackCd > 0) granny.attackCd -= dt;

    if (granny.state === 'ko' || granny.state === 'waking') {
      granny.koTimer -= dt;
      granny.limpT = (granny.limpT || 0) + dt;

      // LOOK AWAY → wake: if you're not watching her, she sneaks awake
      if (isLookingAtGranny()) {
        granny.lookAwayT = 0;
        if (granny.state === 'waking') {
          // glanced back while she was stirring — still out
          granny.state = 'ko';
          setMood();
        }
      } else {
        granny.lookAwayT += dt;
        if (granny.lookAwayT >= 1.2 && granny.state === 'ko') {
          granny.state = 'waking';
          setMood();
          toast('She stirs while you look away…', 1400);
        }
        if (granny.lookAwayT >= 2.8) {
          grannyWakeRage();
          return;
        }
      }

      // ragdoll physics whole body
      granny.vy -= 20 * dt;
      granny.x += granny.vx * dt;
      granny.y += granny.vy * dt;
      granny.z += granny.vz * dt;
      granny.rx += granny.wx * dt;
      granny.ry += granny.wy * dt;
      granny.rz += granny.wz * dt;
      if (granny.y < 0.4) {
        granny.y = 0.4;
        granny.vy *= -0.25;
        granny.vx *= 0.8;
        granny.vz *= 0.8;
        granny.wx *= 0.7;
        granny.wz *= 0.7;
        const targetRx = Math.PI / 2;
        granny.rx += (targetRx - granny.rx) * Math.min(1, dt * 2.5);
      }
      granny.x = clamp(granny.x, HOUSE.minX + 0.5, HOUSE.maxX - 0.5);
      granny.z = clamp(granny.z, HOUSE.minZ + 0.5, HOUSE.maxZ - 0.5);
      // limp limbs (attached)
      const t = granny.limpT;
      granny.parts.armL.rotation.z = 0.8 + Math.sin(t * 8) * 0.4;
      granny.parts.armR.rotation.z = -0.8 + Math.cos(t * 7) * 0.4;
      granny.parts.legL.rotation.x = 0.5 + Math.sin(t * 5) * 0.5;
      granny.parts.legR.rotation.x = 0.4 + Math.cos(t * 5.5) * 0.5;
      granny.parts.head.rotation.z = Math.sin(t * 3) * 0.3;
      granny.mesh.position.set(granny.x, granny.y, granny.z);
      granny.mesh.rotation.set(granny.rx, granny.ry, granny.rz);

      // failsafe only if you stare forever
      if (granny.koTimer <= 0) {
        grannyWakeRage();
      }
      return;
    }

    // standing states
    granny.y = 0;
    granny.walkT += dt;

    if (granny.state === 'chill' || granny.state === 'annoyed') {
      // wander slowly / face cat if annoyed
      if (granny.state === 'annoyed' || granny.anger > 20) {
        const dx = cat.x - granny.x;
        const dz = cat.z - granny.z;
        granny.yaw = Math.atan2(dx, dz);
        // slow approach
        const dist = Math.hypot(dx, dz) || 1;
        if (dist > 2.2) {
          granny.x += (dx / dist) * 1.1 * dt;
          granny.z += (dz / dist) * 1.1 * dt;
        }
        // decay anger slowly if not scratched
        granny.anger = Math.max(0, granny.anger - dt * 2);
        if (granny.anger < 15 && granny.state === 'annoyed') {
          granny.state = 'chill';
          setMood();
        }
      } else {
        granny.x += Math.sin(granny.walkT * 0.4) * 0.4 * dt;
        granny.z += Math.cos(granny.walkT * 0.35) * 0.4 * dt;
        if (Math.random() < dt * 0.15) granny.yaw = rand(0, Math.PI * 2);
      }
      granny.parts.legL.rotation.x = Math.sin(granny.walkT * 4) * 0.35;
      granny.parts.legR.rotation.x = -Math.sin(granny.walkT * 4) * 0.35;
    }

    if (granny.state === 'rage') {
      const dx = cat.x - granny.x;
      const dz = cat.z - granny.z;
      const dist = Math.hypot(dx, dz) || 1;
      granny.yaw = Math.atan2(dx, dz);
      const spd = 3.4;
      granny.x += (dx / dist) * spd * dt;
      granny.z += (dz / dist) * spd * dt;
      granny.parts.legL.rotation.x = Math.sin(granny.walkT * 10) * 0.6;
      granny.parts.legR.rotation.x = -Math.sin(granny.walkT * 10) * 0.6;
      // swing pan
      granny.parts.armR.rotation.x = -0.5 + Math.sin(granny.walkT * 12) * 1.2;
      if (granny.panHeld) {
        // pan in right hand
        const hx = granny.x + Math.sin(granny.yaw) * 0.55;
        const hz = granny.z + Math.cos(granny.yaw) * 0.55;
        pan.position.set(hx, 1.2 + Math.sin(granny.walkT * 12) * 0.25, hz);
        pan.rotation.set(0.3, granny.yaw, Math.sin(granny.walkT * 12) * 0.8);
      }
      // frying pan smash — knock the CAT away (not the granny)
      // dx,dz = cat - granny → push along that direction (away from her)
      if (dist < 1.55 && cat.y < 2.2 && granny.attackCd <= 0) {
        granny.attackCd = 1.25;
        const push = 11;
        cat.vx = (dx / dist) * push;
        cat.vz = (dz / dist) * push;
        cat.vy = 4.5;
        cat.onGround = false;
        airDash = false;
        airDashT = 0; // don't treat pan launch as a pounce
        sfx.bonk();
        toast('Bonk! Frying pan!', 1200);
        addChaos(2);
        for (let i = 0; i < 8; i++) spark(cat.x, cat.y + 0.4, cat.z, 0xffaa44);
        // granny stays planted and keeps swinging — slight step in so she feels aggressive
        granny.x += (dx / dist) * 0.15;
        granny.z += (dz / dist) * 0.15;
      }
    } else {
      // pan stays in kitchen
      if (!granny.panHeld) {
        // leave where it is
      }
    }

    granny.x = clamp(granny.x, HOUSE.minX + 0.5, HOUSE.maxX - 0.5);
    granny.z = clamp(granny.z, HOUSE.minZ + 0.5, HOUSE.maxZ - 0.5);
    granny.mesh.position.set(granny.x, 0, granny.z);
    granny.mesh.rotation.set(0, granny.yaw, 0);
  }

  // ——— interactions ———
  function tryScratch() {
    if (scratchCd > 0) return;
    scratchCd = 0.4;
    pawMode = 'scratch';
    pawAnim = 0.35;
    sfx.scratch();

    // scratch props / furniture / granny in front
    const dir = forward();
    const reach = 1.6;
    const tx = cat.x + dir.x * reach;
    const tz = cat.z + dir.z * reach;

    // granny
    const gd = Math.hypot(granny.x - cat.x, granny.z - cat.z);
    if (gd < 1.8 && granny.state !== 'ko' && granny.state !== 'waking') {
      granny.anger = clamp(granny.anger + 22, 0, 100);
      if (granny.state === 'chill') {
        granny.state = 'annoyed';
        toast('Granny: "Hey! Bad kitty!"', 1600);
      } else if (granny.state === 'annoyed' && granny.anger > 70) {
        toast('Granny is fuming…', 1400);
      } else if (granny.state === 'rage') {
        toast('She is ALREADY mad!', 1000);
      }
      setMood();
      addChaos(5);
      for (let i = 0; i < 5; i++) spark(granny.x, 1.5, granny.z, 0xff8899);
      sfx.meow();
      return;
    }

    // props
    for (const p of props) {
      if (p.held) continue;
      const d = Math.hypot(p.x - tx, p.z - tz);
      if (d < 1.0) {
        p.vx += dir.x * 4 + rand(-1, 1);
        p.vz += dir.z * 4 + rand(-1, 1);
        p.vy = 3;
        p.onGround = false;
        addChaos(2);
        toast('Scratch! ' + p.name, 900);
        return;
      }
    }
    // couch area
    if (Math.hypot(-2.5 - cat.x, -3.5 - cat.z) < 2.5) {
      addChaos(1);
      toast('Couch shredded a little…', 900);
    } else {
      toast('*scratch scratch*', 700);
    }
  }

  function tryGrab() {
    if (grabCd > 0) return;
    grabCd = 0.25;
    if (heldProp) {
      // drop / throw forward
      const p = heldProp;
      p.held = false;
      const dir = forward();
      p.x = cat.x + dir.x * 0.6;
      p.y = cat.y + 0.2;
      p.z = cat.z + dir.z * 0.6;
      p.vx = dir.x * 5 + cat.vx;
      p.vy = 2.5;
      p.vz = dir.z * 5 + cat.vz;
      p.onGround = false;
      heldProp = null;
      heldEl.textContent = 'Paws: empty';
      pawMode = 'idle';
      toast('Dropped ' + p.name, 900);
      addChaos(1);
      return;
    }
    // pick nearest prop
    let best = null;
    let bestD = 1.4;
    for (const p of props) {
      if (p.held) continue;
      const d = Math.hypot(p.x - cat.x, p.z - cat.z, (p.y - cat.y));
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    if (best) {
      heldProp = best;
      best.held = true;
      heldEl.textContent = 'Paws: ' + best.name;
      pawMode = 'grab';
      pawAnim = 0.2;
      sfx.meow();
      toast('Grabbed ' + best.name, 1000);
      addChaos(1);
    } else {
      toast('Nothing to grab', 800);
    }
  }

  function forward() {
    return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, cat.yaw, 0, 'YXZ'));
  }

  /**
   * Jump + dash collision: cat body vs granny capsule/AABB.
   * Works when airborne or shortly after jump while holding W / moving fast.
   */
  function checkGrannyKnock() {
    // Only pounce-ragdoll while she's calm/annoyed — NOT during frying-pan rage
    // (her pan hit used to launch you airborne, which re-triggered pounce and "pushed her away")
    if (granny.state === 'ko' || granny.state === 'waking' || granny.state === 'rage') return;
    if (granny.hitCd > 0) return;

    // --- horizontal + vertical overlap (capsule-ish) ---
    const dx = cat.x - granny.x;
    const dz = cat.z - granny.z;
    const horiz = Math.hypot(dx, dz);
    const catR = 0.42;
    const grannyR = 0.55;
    if (horiz > catR + grannyR) return;

    // cat body vertical span (eyes at cat.y, feet ~ cat.y - 0.35)
    const catMinY = cat.y - 0.4;
    const catMaxY = cat.y + 0.25;
    // standing granny from 0..1.9
    const gMinY = granny.y;
    const gMaxY = granny.y + 1.85;
    const vertOverlap = catMinY < gMaxY && catMaxY > gMinY + 0.15;
    if (!vertOverlap) return;

    const horizSpeed = Math.hypot(cat.vx, cat.vz);
    const totalSpeed = Math.hypot(cat.vx, cat.vy, cat.vz);
    const midAir = !cat.onGround || cat.y > 0.52 || cat.vy > 0.3;
    const dashWindow = airDash || airDashT > 0;
    const holdingForward = !!(keys['KeyW'] || keys['KeyA'] || keys['KeyD'] || keys['KeyS']);
    // jump+W dash: in air (or dash window) with any real motion toward her
    const movingEnough = horizSpeed > 1.6 || totalSpeed > 2.2 || (midAir && holdingForward);

    if (!(midAir || dashWindow)) return;
    if (!movingEnough) return;

    // must be moving roughly toward granny (or overlapping hard)
    if (horiz > 0.15) {
      const toward = (-dx / horiz) * cat.vx + (-dz / horiz) * cat.vz; // velocity toward granny
      // allow if approaching, or already overlapping deeply mid-air
      if (toward < -0.5 && horiz > 0.7) return;
    }

    granny.hitCd = 0.55;
    const dir = forward();
    const ix = (dir.x * 5 + cat.vx * 1.2) || (horiz > 0.01 ? (dx / horiz) * -6 : 3);
    const iz = (dir.z * 5 + cat.vz * 1.2) || (horiz > 0.01 ? (dz / horiz) * -6 : 0);
    grannyStartRagdoll(ix, 4 + Math.max(0, cat.vy) + 2, iz);
    // bounce cat off a bit
    if (horiz > 0.01) {
      cat.vx += (dx / horiz) * 3;
      cat.vz += (dz / horiz) * 3;
    }
    cat.vy = Math.max(cat.vy, 2);
    sfx.meow();
    toast('Pounce! Granny down!', 1400);
  }

  // ——— props physics ———
  function updateProps(dt) {
    for (const p of props) {
      if (p.held && heldProp === p) {
        const dir = forward();
        p.x = cat.x + dir.x * 0.55;
        p.y = cat.y + 0.15;
        p.z = cat.z + dir.z * 0.55;
        p.mesh.position.set(p.x, p.y, p.z);
        p.mesh.rotation.y = cat.yaw;
        continue;
      }
      if (p.onGround && Math.abs(p.vx) < 0.05 && Math.abs(p.vz) < 0.05) {
        p.mesh.position.set(p.x, p.y, p.z);
        continue;
      }
      p.vy -= 18 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.vx *= 1 - dt * 1.5;
      p.vz *= 1 - dt * 1.5;
      const half = p.h / 2;
      if (p.y < half) {
        p.y = half;
        p.vy *= -0.2;
        p.vx *= 0.7;
        p.vz *= 0.7;
        if (Math.abs(p.vy) < 0.5) {
          p.vy = 0;
          p.onGround = true;
        }
      } else {
        p.onGround = false;
      }
      p.x = clamp(p.x, HOUSE.minX + 0.3, HOUSE.maxX - 0.3);
      p.z = clamp(p.z, HOUSE.minZ + 0.3, HOUSE.maxZ - 0.3);
      p.mesh.position.set(p.x, p.y, p.z);
      p.mesh.rotation.x += p.vx * dt;
      p.mesh.rotation.z -= p.vz * dt;
    }
  }

  // ——— collision for cat ———
  function tryMoveCat(nx, nz) {
    const r = cat.radius;
    const boxX = {
      min: new THREE.Vector3(nx - r, 0.05, cat.z - r),
      max: new THREE.Vector3(nx + r, cat.height + 0.2, cat.z + r),
    };
    let hit = false;
    for (const c of colliders) {
      if (boxX.min.x < c.max.x && boxX.max.x > c.min.x &&
          boxX.min.y < c.max.y && boxX.max.y > c.min.y &&
          boxX.min.z < c.max.z && boxX.max.z > c.min.z) {
        hit = true; break;
      }
    }
    if (!hit) cat.x = nx;
    const boxZ = {
      min: new THREE.Vector3(cat.x - r, 0.05, nz - r),
      max: new THREE.Vector3(cat.x + r, cat.height + 0.2, nz + r),
    };
    hit = false;
    for (const c of colliders) {
      if (boxZ.min.x < c.max.x && boxZ.max.x > c.min.x &&
          boxZ.min.y < c.max.y && boxZ.max.y > c.min.y &&
          boxZ.min.z < c.max.z && boxZ.max.z > c.min.z) {
        hit = true; break;
      }
    }
    if (!hit) cat.z = nz;
    cat.x = clamp(cat.x, HOUSE.minX + 0.35, HOUSE.maxX - 0.35);
    cat.z = clamp(cat.z, HOUSE.minZ + 0.35, HOUSE.maxZ - 0.35);
  }

  function updateCat(dt) {
    if (scratchCd > 0) scratchCd -= dt;
    if (grabCd > 0) grabCd -= dt;
    if (airDashT > 0) airDashT -= dt;

    const fwd = forward();
    const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, cat.yaw, 0, 'YXZ'));
    let mx = 0, mz = 0;
    const sprint = keys['ShiftLeft'] || keys['ShiftRight'];
    const spd = sprint ? cat.sprint : cat.speed;
    if (keys['KeyW']) { mx += fwd.x; mz += fwd.z; }
    if (keys['KeyS']) { mx -= fwd.x; mz -= fwd.z; }
    if (keys['KeyA']) { mx -= right.x; mz -= right.z; }
    if (keys['KeyD']) { mx += right.x; mz += right.z; }
    const len = Math.hypot(mx, mz);
    if (len > 0) {
      mx = (mx / len) * spd;
      mz = (mz / len) * spd;
    }

    // stronger air accel so jump+W is a real pounce
    const accel = cat.onGround ? 10 : 14;
    cat.vx += (mx - cat.vx) * Math.min(1, dt * accel);
    cat.vz += (mz - cat.vz) * Math.min(1, dt * accel);

    // air dash boost while holding W mid-jump
    if (!cat.onGround && keys['KeyW']) {
      cat.vx += fwd.x * 16 * dt;
      cat.vz += fwd.z * 16 * dt;
      airDash = true;
      airDashT = 0.55;
    }

    // jump
    if (keys['Space'] && cat.onGround) {
      cat.vy = cat.jump;
      cat.onGround = false;
      airDash = true;
      airDashT = 0.75;
      if (keys['KeyW']) {
        cat.vx += fwd.x * 3.5;
        cat.vz += fwd.z * 3.5;
      }
      sfx.beep(320, 0.06, 'sine', 0.06);
    }
    cat.vy -= 18 * dt;
    cat.y += cat.vy * dt;
    if (cat.y <= 0.45) {
      cat.y = 0.45;
      cat.vy = 0;
      cat.onGround = true;
      airDash = false;
      // airDashT still lingers briefly so landing pounce counts
    }

    tryMoveCat(cat.x + cat.vx * dt, cat.z + cat.vz * dt);

    // camera at cat eyes + slight bob
    const bob = cat.onGround && len > 0.1 ? Math.sin(performance.now() * 0.015) * 0.03 : 0;
    camera.position.set(cat.x, cat.y + bob, cat.z);
    camera.rotation.x = cat.pitch;
    camera.rotation.y = cat.yaw;

    // paw anim
    if (pawAnim > 0) pawAnim -= dt;
    const swing = pawMode === 'scratch' && pawAnim > 0
      ? Math.sin((0.35 - pawAnim) * 40) * 0.5
      : 0;
    pawL.position.y = pawL.userData.baseY + (pawMode === 'grab' ? 0.06 : 0);
    pawR.position.y = pawR.userData.baseY + (pawMode === 'grab' ? 0.06 : 0);
    pawL.rotation.x = 0.35 + swing;
    pawR.rotation.x = 0.35 - swing * 0.8;
    if (pawMode === 'scratch' && pawAnim <= 0) pawMode = heldProp ? 'grab' : 'idle';
    if (pawMode === 'idle') {
      pawL.rotation.z = Math.sin(performance.now() * 0.004) * 0.05;
      pawR.rotation.z = -Math.sin(performance.now() * 0.004) * 0.05;
    }

    checkGrannyKnock();
  }

  function updateSparks(dt) {
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.life -= dt;
      s.vy -= 10 * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      s.mesh.position.set(s.x, s.y, s.z);
      if (s.life <= 0 || s.y < 0) {
        scene.remove(s.mesh);
        sparks.splice(i, 1);
      }
    }
  }

  // ——— input ———
  function resize() {
    const w = innerWidth;
    const h = innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('click', () => {
    if (started) canvas.requestPointerLock();
  });
  document.addEventListener('pointerlockchange', () => {
    locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!locked) return;
    cat.yaw -= e.movementX * 0.0024;
    cat.pitch -= e.movementY * 0.002;
    cat.pitch = clamp(cat.pitch, -1.2, 1.1);
  });
  window.addEventListener('keydown', (e) => {
    keys[e.code] = true;
    if (!started) return;
    if (e.code === 'KeyF') tryScratch();
    if (e.code === 'KeyR') tryGrab();
  });
  window.addEventListener('keyup', (e) => { keys[e.code] = false; });

  btnStart.addEventListener('click', () => {
    started = true;
    overlay.classList.add('hidden');
    sfx.ensure();
    sfx.ctx.resume();
    sfx.meow();
    canvas.requestPointerLock();
    setMood();
    toast('You live here now. Be… mostly good.', 2500);
  });

  // ——— loop ———
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (started) {
      updateCat(dt);
      updateGranny(dt);
      updateProps(dt);
      updateSparks(dt);
    } else {
      camera.position.set(cat.x, cat.y, cat.z);
      camera.rotation.set(cat.pitch, cat.yaw, 0);
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
