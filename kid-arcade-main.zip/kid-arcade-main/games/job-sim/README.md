# Job Sim Arkhe


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

Comedy **first-person job sandbox** inspired by *Job Simulator* (not affiliated).

## Jobs

1. **Cubicle Specialiste** — coffee, stamp forms, shred, meeting, clock out  
2. **Gourmet Convenience** — stock, scan, bag, serve customer  
3. **Auto Detail** — soap, rinse, polish, honk, clock out  

## Controls

| Key | Action |
|-----|--------|
| WASD | Move |
| Mouse | Look (click to lock) |
| **E** / **F** | Grab or use |
| **Q** | Drop |

```bash
cd projects/creative-visualizers-and-games/job-sim-arkhe
python3 -m http.server 8781
```

Open http://127.0.0.1:8781/
