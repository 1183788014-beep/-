/**
 * Job Sim Arkhe — Job Simulator–inspired first-person comedy jobs
 * Not affiliated with Owlchemy / Job Simulator
 */
(function () {
  'use strict';

  const canvas = document.getElementById('c');
  const overlay = document.getElementById('overlay');
  const jobPick = document.getElementById('job-pick');
  const endScreen = document.getElementById('end');
  const btnStart = document.getElementById('btn-start');
  const btnAgain = document.getElementById('btn-again');
  const taskList = document.getElementById('task-list');
  const payEl = document.getElementById('pay');
  const chaosEl = document.getElementById('chaos');
  const heldEl = document.getElementById('held');
  const promptEl = document.getElementById('prompt');
  const toastEl = document.getElementById('toast');
  const bossEl = document.getElementById('boss');
  const endMsg = document.getElementById('end-msg');

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.setClearColor(0x6078a8, 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x6078a8, 14, 45);

  const camera = new THREE.PerspectiveCamera(72, 1, 0.05, 80);
  camera.rotation.order = 'YXZ';

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  scene.add(new THREE.HemisphereLight(0xc0d8ff, 0x404050, 0.5));
  const sun = new THREE.DirectionalLight(0xfff0dd, 0.75);
  sun.position.set(8, 14, 6);
  scene.add(sun);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function mat(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function box(w, h, d, c) {
    return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c));
  }

  // hands
  const hands = new THREE.Group();
  camera.add(hands);
  scene.add(camera);
  function makeHand(side) {
    const g = new THREE.Group();
    const arm = box(0.12, 0.12, 0.4, 0xf0c8a0);
    arm.position.z = -0.12;
    const fist = box(0.18, 0.16, 0.18, 0xe8b890);
    fist.position.z = -0.38;
    g.add(arm, fist);
    g.position.set(side * 0.28, -0.28, -0.4);
    g.rotation.x = 0.35;
    hands.add(g);
    return g;
  }
  const handL = makeHand(-1);
  const handR = makeHand(1);

  // player
  const player = {
    x: 0, y: 1.55, z: 6,
    yaw: Math.PI, pitch: 0,
    speed: 5.8,
  };
  let locked = false;
  let started = false;
  let jobId = null;
  const keys = Object.create(null);
  function key(n) {
    return !!(keys[n] || keys[n && n.toLowerCase && n.toLowerCase()]);
  }

  let pay = 0;
  let chaos = 0;
  let held = null; // { id, name, mesh, job }
  let tasks = [];
  let done = {};
  let worldRoot = new THREE.Group();
  scene.add(worldRoot);
  const props = []; // grabbables / interactables
  let jobState = {};

  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), ms || 2200);
  }
  function boss(msg) {
    bossEl.textContent = 'BossBot-9000: “' + msg + '”';
  }
  function addPay(n) {
    pay += n;
    payEl.textContent = String(pay);
  }
  function addChaos(n) {
    chaos += n;
    chaosEl.textContent = String(chaos);
  }

  function clearWorld() {
    while (worldRoot.children.length) {
      const c = worldRoot.children[0];
      worldRoot.remove(c);
    }
    props.length = 0;
    if (held && held.mesh) {
      scene.remove(held.mesh);
    }
    held = null;
    heldEl.textContent = 'Hands: empty';
    jobState = {};
    done = {};
  }

  function addMesh(mesh) {
    worldRoot.add(mesh);
    return mesh;
  }
  function floor(w, d, c, x, z) {
    const m = box(w, 0.12, d, c);
    m.position.set(x, -0.06, z);
    return addMesh(m);
  }
  function wall(w, h, d, c, x, y, z) {
    const m = box(w, h, d, c);
    m.position.set(x, y, z);
    return addMesh(m);
  }

  function makeProp(opts) {
    const m = box(opts.w || 0.25, opts.h || 0.25, opts.d || 0.25, opts.color || 0xcccccc);
    m.position.set(opts.x, opts.y, opts.z);
    addMesh(m);
    const p = {
      id: opts.id,
      name: opts.name,
      mesh: m,
      x: opts.x, y: opts.y, z: opts.z,
      grab: opts.grab !== false,
      use: opts.use || null,
      station: opts.station || null,
      held: false,
      baseY: opts.y,
    };
    props.push(p);
    return p;
  }

  // ——— JOB DEFINITIONS ———
  const JOBS = {
    office: {
      title: 'Cubicle Specialiste',
      spawn: { x: 0, z: 5, yaw: Math.PI },
      tasks: [
        { id: 'coffee', label: 'Pour coffee into the mug' },
        { id: 'stamp', label: 'Stamp 3 forms' },
        { id: 'shred', label: 'Shred a form' },
        { id: 'meeting', label: 'Sit in the meeting chair 5s' },
        { id: 'clockout', label: 'Hit the CLOCK OUT button' },
      ],
      build() {
        floor(16, 14, 0xb0b8c0, 0, 0);
        wall(16, 3, 0.25, 0xdde3ee, 0, 1.5, -6.5);
        wall(16, 3, 0.25, 0xdde3ee, 0, 1.5, 6.5);
        wall(0.25, 3, 14, 0xdde3ee, -7.8, 1.5, 0);
        wall(0.25, 3, 14, 0xdde3ee, 7.8, 1.5, 0);
        // cubicle desk
        const desk = box(2.2, 0.1, 1.0, 0x6a7a8a);
        desk.position.set(-2, 0.85, -1);
        addMesh(desk);
        wall(2.2, 1.2, 0.08, 0x8a9aaa, -2, 1.5, -1.5);
        // computer
        addMesh(box(0.7, 0.45, 0.06, 0x222228)).position.set(-2, 1.25, -1.35);
        addMesh(box(0.55, 0.32, 0.02, 0x40a0e0)).position.set(-2, 1.25, -1.3);
        // meeting table
        addMesh(box(2.5, 0.1, 1.2, 0x5a4a3a)).position.set(3, 0.85, 2);
        // chairs
        addMesh(box(0.5, 0.6, 0.5, 0x3a5a80)).position.set(3, 0.4, 3.2);
        // coffee machine
        addMesh(box(0.55, 0.9, 0.45, 0x333340)).position.set(5.5, 0.55, -4.5);
        makeProp({ id: 'pot', name: 'coffee pot', x: 5.5, y: 1.15, z: -4.2, w: 0.22, h: 0.28, d: 0.18, color: 0x222228, grab: true });
        makeProp({ id: 'mug', name: 'mug', x: -1.4, y: 0.95, z: -0.7, w: 0.16, h: 0.16, d: 0.16, color: 0xf5f5f5, grab: true, station: 'desk' });
        // forms
        for (let i = 0; i < 4; i++) {
          makeProp({
            id: 'form' + i, name: 'form',
            x: -2.4 + i * 0.15, y: 0.95, z: -0.6,
            w: 0.28, h: 0.02, d: 0.36, color: 0xf0f0e0, grab: true,
          });
        }
        // stamp pad
        makeProp({ id: 'stamp', name: 'rubber stamp', x: -1.1, y: 0.95, z: -1.1, w: 0.14, h: 0.12, d: 0.14, color: 0xa03030, grab: true });
        // shredder
        addMesh(box(0.6, 0.7, 0.45, 0x444450)).position.set(-5, 0.4, -4);
        makeProp({
          id: 'shredder', name: 'shredder slot',
          x: -5, y: 0.85, z: -4, w: 0.4, h: 0.08, d: 0.25, color: 0x222228,
          grab: false, use: 'shred',
        });
        // clock out
        makeProp({
          id: 'clockout', name: 'CLOCK OUT',
          x: 0, y: 1.4, z: 5.8, w: 0.6, h: 0.35, d: 0.1, color: 0xe04040,
          grab: false, use: 'clockout',
        });
        // meeting zone marker
        makeProp({
          id: 'meeting', name: 'meeting chair',
          x: 3, y: 0.15, z: 3.2, w: 0.6, h: 0.05, d: 0.6, color: 0x2a4060,
          grab: false, use: 'meeting',
        });
        jobState.stamped = 0;
        jobState.coffee = false;
        jobState.meetingT = 0;
      },
    },
    store: {
      title: 'Gourmet Convenience Associate',
      spawn: { x: 0, z: 5, yaw: Math.PI },
      tasks: [
        { id: 'stock', label: 'Stock 3 snacks on the shelf' },
        { id: 'scan', label: 'Scan an item at the register' },
        { id: 'bag', label: 'Put a snack in a bag' },
        { id: 'serve', label: 'Serve the customer (hand bag)' },
        { id: 'clockout', label: 'Hit CLOCK OUT' },
      ],
      build() {
        floor(16, 14, 0xe8e0d0, 0, 0);
        wall(16, 3, 0.25, 0xf5f0e8, 0, 1.5, -6.5);
        wall(16, 3, 0.25, 0xf5f0e8, 0, 1.5, 6.5);
        wall(0.25, 3, 14, 0xf5f0e8, -7.8, 1.5, 0);
        wall(0.25, 3, 14, 0xf5f0e8, 7.8, 1.5, 0);
        // shelves
        addMesh(box(4, 1.6, 0.4, 0x8a7060)).position.set(-3, 0.9, -4);
        // register counter
        addMesh(box(2.2, 0.9, 0.8, 0x5a6a7a)).position.set(3, 0.5, 1);
        addMesh(box(0.4, 0.25, 0.3, 0x222228)).position.set(3.4, 1.1, 1);
        // customer
        const cust = new THREE.Group();
        cust.add(box(0.5, 0.7, 0.3, 0x4080c0));
        cust.children[0].position.y = 1.1;
        const head = box(0.35, 0.35, 0.35, 0xffe0bd);
        head.position.y = 1.65;
        cust.add(head);
        cust.position.set(3, 0, 2.8);
        addMesh(cust);
        jobState.customer = cust;

        const snacks = [
          { id: 'chips', color: 0xe0c040 },
          { id: 'soda', color: 0xe04040 },
          { id: 'candy', color: 0xc060e0 },
          { id: 'jerky', color: 0x8a5030 },
        ];
        snacks.forEach((s, i) => {
          makeProp({
            id: s.id, name: s.id,
            x: -1 + i * 0.5, y: 0.2, z: 3,
            w: 0.22, h: 0.28, d: 0.12, color: s.color, grab: true,
          });
        });
        makeProp({
          id: 'shelf', name: 'shelf slot',
          x: -3, y: 1.2, z: -3.7, w: 1.2, h: 0.1, d: 0.35, color: 0x6a5040,
          grab: false, use: 'shelf',
        });
        makeProp({
          id: 'scanner', name: 'scanner',
          x: 3, y: 1.05, z: 0.7, w: 0.35, h: 0.08, d: 0.35, color: 0x303040,
          grab: false, use: 'scan',
        });
        makeProp({
          id: 'bag', name: 'bag',
          x: 2.3, y: 1.05, z: 1.1, w: 0.28, h: 0.08, d: 0.35, color: 0xf5f0d0,
          grab: true,
        });
        makeProp({
          id: 'customer', name: 'customer',
          x: 3, y: 1, z: 2.8, w: 0.5, h: 0.1, d: 0.5, color: 0x204060,
          grab: false, use: 'serve',
        });
        makeProp({
          id: 'clockout', name: 'CLOCK OUT',
          x: 0, y: 1.4, z: 5.8, w: 0.6, h: 0.35, d: 0.1, color: 0xe04040,
          grab: false, use: 'clockout',
        });
        jobState.stocked = 0;
        jobState.scanned = false;
        jobState.bagged = false;
        jobState.served = false;
      },
    },
    auto: {
      title: 'Auto Detail Technician',
      spawn: { x: 0, z: 6, yaw: Math.PI },
      tasks: [
        { id: 'soap', label: 'Soap the car (use sponge on car)' },
        { id: 'rinse', label: 'Rinse with hose' },
        { id: 'polish', label: 'Polish the hood' },
        { id: 'honk', label: 'Honk the horn (quality check)' },
        { id: 'clockout', label: 'Hit CLOCK OUT' },
      ],
      build() {
        floor(18, 16, 0x5a5a60, 0, 0);
        wall(18, 4, 0.3, 0x6a6a70, 0, 2, -7.5);
        wall(18, 4, 0.3, 0x6a6a70, 0, 2, 7.5);
        wall(0.3, 4, 16, 0x6a6a70, -8.8, 2, 0);
        wall(0.3, 4, 16, 0x6a6a70, 8.8, 2, 0);
        // car body
        const car = box(2.4, 0.7, 4.2, 0x3060c0);
        car.position.set(0, 0.55, -1);
        addMesh(car);
        addMesh(box(2.0, 0.55, 1.8, 0x2850a8)).position.set(0, 1.15, -0.7);
        // wheels
        for (const [wx, wz] of [[-1.1, 1.1], [1.1, 1.1], [-1.1, -2.8], [1.1, -2.8]]) {
          addMesh(box(0.3, 0.5, 0.5, 0x111118)).position.set(wx, 0.3, wz - 1);
        }
        makeProp({
          id: 'car', name: 'car body',
          x: 0, y: 0.9, z: -1, w: 2.2, h: 0.2, d: 3.5, color: 0x204080,
          grab: false, use: 'car',
        });
        makeProp({ id: 'sponge', name: 'sponge', x: 3, y: 0.25, z: 2, w: 0.28, h: 0.14, d: 0.28, color: 0xf0d040, grab: true });
        makeProp({ id: 'hose', name: 'hose nozzle', x: -3, y: 0.9, z: 1, w: 0.2, h: 0.2, d: 0.45, color: 0x4080e0, grab: true });
        makeProp({ id: 'polish', name: 'polish rag', x: 3.5, y: 0.2, z: 0, w: 0.3, h: 0.08, d: 0.3, color: 0xe080a0, grab: true });
        makeProp({
          id: 'horn', name: 'horn button',
          x: 0, y: 1.15, z: 0.5, w: 0.2, h: 0.08, d: 0.2, color: 0x222228,
          grab: false, use: 'horn',
        });
        makeProp({
          id: 'clockout', name: 'CLOCK OUT',
          x: 0, y: 1.4, z: 6.5, w: 0.6, h: 0.35, d: 0.1, color: 0xe04040,
          grab: false, use: 'clockout',
        });
        jobState.soaped = false;
        jobState.rinsed = false;
        jobState.polished = false;
        jobState.honked = false;
      },
    },
  };

  function renderTasks() {
    let cur = null;
    for (const t of tasks) {
      if (!done[t.id]) { cur = t.id; break; }
    }
    taskList.innerHTML = tasks.map((t) => {
      const cls = done[t.id] ? 'done' : t.id === cur ? 'cur' : '';
      return `<li class="${cls}">${done[t.id] ? '✓ ' : '○ '}${t.label}</li>`;
    }).join('');
  }

  function complete(id, msg, money) {
    if (done[id]) return;
    done[id] = true;
    addPay(money != null ? money : 8);
    if (msg) toast(msg);
    renderTasks();
    const left = tasks.filter((t) => !done[t.id]).length;
    if (left === 1 && !done.clockout) boss('Almost done. Clock out when finished!');
  }

  function allButClockout() {
    return tasks.every((t) => t.id === 'clockout' || done[t.id]);
  }

  function startJob(id) {
    clearWorld();
    jobId = id;
    const job = JOBS[id];
    tasks = job.tasks.slice();
    done = {};
    job.build();
    player.x = job.spawn.x;
    player.z = job.spawn.z;
    player.yaw = job.spawn.yaw;
    player.y = 1.55;
    pay = 0;
    chaos = 0;
    payEl.textContent = '0';
    chaosEl.textContent = '0';
    renderTasks();
    jobPick.classList.add('hidden');
    started = true;
    canvas.requestPointerLock();
    boss(id === 'office'
      ? 'Cubicle time! Caffeine is a performance metric.'
      : id === 'store'
        ? 'Welcome to SnackForce. Stock. Scan. Smile. Or don’t.'
        : 'That car pays the rent. Make it shiny.');
    toast('Shift started: ' + job.title, 2500);
  }

  function endShift() {
    started = false;
    document.exitPointerLock();
    const stars = Math.min(5, 1 + Math.floor(pay / 15) + (chaos > 5 ? 1 : 0));
    endMsg.textContent = `Pay: $${pay} · Chaos: ${chaos} · Rating: ${'★'.repeat(stars)}${'☆'.repeat(5 - stars)}`;
    endScreen.classList.remove('hidden');
    boss('You are… adequately obsolete. See you never. Or tomorrow.');
  }

  // ——— interaction ———
  function nearestProp(maxD) {
    maxD = maxD || 2.2;
    let best = null;
    let bestD = maxD;
    for (const p of props) {
      if (p.held) continue;
      const d = Math.hypot(p.x - player.x, (p.y - player.y), p.z - player.z);
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }

  function updatePrompt() {
    if (!started) {
      promptEl.classList.add('hidden');
      return;
    }
    if (held) {
      promptEl.innerHTML = `<kbd>E</kbd> use ${held.name} · <kbd>Q</kbd> drop`;
      promptEl.classList.remove('hidden');
      return;
    }
    const p = nearestProp();
    if (p) {
      if (p.grab) promptEl.innerHTML = `<kbd>E</kbd> grab ${p.name}`;
      else promptEl.innerHTML = `<kbd>E</kbd> ${p.name}`;
      promptEl.classList.remove('hidden');
    } else promptEl.classList.add('hidden');
  }

  function grabOrUse() {
    if (!started) return;
    if (held) {
      useHeld();
      return;
    }
    const p = nearestProp();
    if (!p) return;
    if (p.grab) {
      held = { id: p.id, name: p.name, mesh: p.mesh, prop: p };
      p.held = true;
      // reparent to camera space visually — keep in world, follow in update
      heldEl.textContent = 'Hands: ' + p.name;
      toast('Grabbed ' + p.name, 900);
      return;
    }
    // station use without grab
    useStation(p);
  }

  function dropHeld() {
    if (!held) return;
    const p = held.prop;
    p.held = false;
    p.x = player.x + Math.sin(player.yaw) * 0.8;
    p.z = player.z + Math.cos(player.yaw) * 0.8;
    p.y = 0.2;
    p.mesh.position.set(p.x, p.y, p.z);
    held = null;
    heldEl.textContent = 'Hands: empty';
    toast('Dropped', 700);
  }

  function useHeld() {
    const target = nearestProp(2.4);
    const h = held;

    if (jobId === 'office') {
      if (h.id === 'pot' && target && target.id === 'mug') {
        complete('coffee', '☕ Coffee acquired. Productivity +fake%.', 10);
        jobState.coffee = true;
        boss('Caffeine levels: legally sufficient.');
        return;
      }
      if (h.id === 'stamp' || (h.name === 'form' && target && target.id === 'stamp')) {
        // stamp form while holding form OR stamp
      }
      if ((h.name === 'form' || h.id.startsWith('form')) && target && target.id === 'stamp') {
        jobState.stamped = (jobState.stamped || 0) + 1;
        addPay(3);
        toast('STAMPED! (' + jobState.stamped + '/3)', 1000);
        if (jobState.stamped >= 3) complete('stamp', 'Forms validated by ink violence.', 12);
        return;
      }
      if (h.id === 'stamp' && target && target.name === 'form') {
        jobState.stamped = (jobState.stamped || 0) + 1;
        addPay(3);
        toast('STAMPED! (' + jobState.stamped + '/3)', 1000);
        if (jobState.stamped >= 3) complete('stamp', 'Forms validated by ink violence.', 12);
        return;
      }
      if ((h.name === 'form' || h.id.startsWith('form')) && target && target.id === 'shredder') {
        complete('shred', 'Shredded. That never existed.', 10);
        // remove form
        held.prop.held = false;
        worldRoot.remove(held.mesh);
        const idx = props.indexOf(held.prop);
        if (idx >= 0) props.splice(idx, 1);
        held = null;
        heldEl.textContent = 'Hands: empty';
        addChaos(1);
        boss('Confidentiality: delicious.');
        return;
      }
    }

    if (jobId === 'store') {
      if (target && target.id === 'shelf' && ['chips', 'soda', 'candy', 'jerky'].includes(h.id)) {
        jobState.stocked = (jobState.stocked || 0) + 1;
        // park on shelf
        h.prop.held = false;
        h.prop.x = -3.5 + jobState.stocked * 0.4;
        h.prop.y = 1.25;
        h.prop.z = -3.85;
        h.prop.mesh.position.set(h.prop.x, h.prop.y, h.prop.z);
        held = null;
        heldEl.textContent = 'Hands: empty';
        toast('Stocked ' + jobState.stocked + '/3', 900);
        if (jobState.stocked >= 3) complete('stock', 'Shelf looks… intentional.', 12);
        return;
      }
      if (target && target.id === 'scanner' && ['chips', 'soda', 'candy', 'jerky'].includes(h.id)) {
        jobState.scanned = true;
        complete('scan', 'BEEP. Item is now theoretically paid for.', 10);
        boss('Beep is my love language.');
        return;
      }
      if (h.id === 'bag' && target && ['chips', 'soda', 'candy', 'jerky'].includes(target.id)) {
        // bag on ground snack - or holding snack use on bag
      }
      if (['chips', 'soda', 'candy', 'jerky'].includes(h.id) && target && target.id === 'bag') {
        jobState.bagged = true;
        complete('bag', 'Bag secured. Customer waiting.', 8);
        return;
      }
      if ((h.id === 'bag' || jobState.bagged) && target && target.id === 'customer') {
        if (!jobState.bagged && h.id !== 'bag') {
          toast('Bag a snack first');
          return;
        }
        jobState.served = true;
        complete('serve', 'Customer leaves happier. Or loaded with chips.', 15);
        boss('5-star review: “there was a human??”');
        if (held) dropHeld();
        return;
      }
    }

    if (jobId === 'auto') {
      if (target && target.id === 'car') {
        if (h.id === 'sponge') {
          jobState.soaped = true;
          complete('soap', 'Soapy. The car is having a spa day.', 10);
          addChaos(1);
          return;
        }
        if (h.id === 'hose') {
          if (!jobState.soaped) {
            toast('Soap first!');
            return;
          }
          jobState.rinsed = true;
          complete('rinse', 'Rinsed. Water goes everywhere. Fine.', 10);
          addChaos(2);
          return;
        }
        if (h.id === 'polish') {
          if (!jobState.rinsed) {
            toast('Rinse first!');
            return;
          }
          jobState.polished = true;
          complete('polish', 'So shiny you can see your future debt.', 12);
          return;
        }
      }
    }

    toast('Try aiming at the right station…', 1200);
  }

  function useStation(p) {
    if (p.use === 'clockout') {
      if (!allButClockout()) {
        toast('Finish other tasks first!');
        boss('Clocking out early is a crime against efficiency.');
        return;
      }
      complete('clockout', 'CLOCKED OUT. Freedom protocol.', 20);
      setTimeout(endShift, 900);
      return;
    }
    if (p.use === 'meeting') {
      jobState.meetingActive = true;
      toast('Sitting in Meeting…', 1000);
      return;
    }
    if (p.use === 'horn') {
      if (!jobState.polished) {
        toast('Polish the car first!');
        return;
      }
      jobState.honked = true;
      complete('honk', 'HONK. Quality: certified loud.', 10);
      boss('Horn volume exceeds OSHA. Perfect.');
      addChaos(1);
      return;
    }
    if (p.use === 'shred') {
      toast('Put a form in the shredder (grab form, E on shredder)');
      return;
    }
    if (p.use === 'scan') {
      toast('Hold a snack and use E on the scanner');
      return;
    }
    if (p.use === 'serve') {
      toast('Hand the bag / snack to the customer with E');
      return;
    }
    if (p.use === 'car') {
      toast('Use sponge / hose / polish on the car');
      return;
    }
  }

  // ——— loop ———
  function isWalkable(x, z) {
    return x > -8.2 && x < 8.2 && z > -7 && z < 7.2;
  }

  function update(dt) {
    if (!started) return;

    const fwd = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, player.yaw, 0, 'YXZ'));
    const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, player.yaw, 0, 'YXZ'));
    let mx = 0, mz = 0;
    if (key('KeyW') || key('w') || key('ArrowUp')) { mx += fwd.x; mz += fwd.z; }
    if (key('KeyS') || key('s') || key('ArrowDown')) { mx -= fwd.x; mz -= fwd.z; }
    if (key('KeyA') || key('a') || key('ArrowLeft')) { mx -= right.x; mz -= right.z; }
    if (key('KeyD') || key('d') || key('ArrowRight')) { mx += right.x; mz += right.z; }
    const len = Math.hypot(mx, mz);
    if (len > 0) {
      mx = (mx / len) * player.speed;
      mz = (mz / len) * player.speed;
    }
    const nx = player.x + mx * dt;
    const nz = player.z + mz * dt;
    if (isWalkable(nx, player.z)) player.x = nx;
    if (isWalkable(player.x, nz)) player.z = nz;

    // auto job bounds per job slightly larger for auto
    if (jobId === 'auto') {
      player.x = clamp(player.x, -8.2, 8.2);
      player.z = clamp(player.z, -7, 7);
    }

    camera.position.set(player.x, player.y, player.z);
    camera.rotation.x = player.pitch;
    camera.rotation.y = player.yaw;

    // held item follows hands
    if (held && held.mesh) {
      const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(player.pitch * 0.5, player.yaw, 0, 'YXZ'));
      held.mesh.position.set(
        player.x + dir.x * 0.7,
        player.y - 0.15 + dir.y * 0.3,
        player.z + dir.z * 0.7
      );
      held.prop.x = held.mesh.position.x;
      held.prop.y = held.mesh.position.y;
      held.prop.z = held.mesh.position.z;
    }

    // meeting sit timer
    if (jobId === 'office' && !done.meeting) {
      const d = Math.hypot(player.x - 3, player.z - 3.2);
      if (d < 1.3) {
        jobState.meetingT = (jobState.meetingT || 0) + dt;
        heldEl.textContent = held
          ? 'Hands: ' + held.name
          : 'In meeting… ' + Math.min(5, jobState.meetingT | 0) + '/5s';
        if (jobState.meetingT >= 5) {
          complete('meeting', 'Meeting adjourned. Nothing was decided.', 10);
          boss('Synergy achieved. Somehow.');
          if (!held) heldEl.textContent = 'Hands: empty';
        }
      }
    }

    // hand anim
    const swing = Math.sin(performance.now() * 0.008) * (len > 0.1 ? 0.08 : 0.03);
    handL.rotation.x = 0.35 + swing;
    handR.rotation.x = 0.35 - swing;

    updatePrompt();
  }

  // input
  function resize() {
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / Math.max(1, innerHeight);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('click', () => {
    if (started) canvas.requestPointerLock();
  });
  document.addEventListener('pointerlockchange', () => {
    locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!locked || !started) return;
    player.yaw -= e.movementX * 0.0023;
    player.pitch -= e.movementY * 0.002;
    player.pitch = clamp(player.pitch, -1.3, 1.2);
  });

  function onKeyDown(e) {
    keys[e.code] = true;
    if (e.key) keys[e.key.toLowerCase()] = true;
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
    if (['KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(e.code)) e.preventDefault();
    if (!started) return;
    if (e.code === 'KeyE' || e.key === 'e') grabOrUse();
    if (e.code === 'KeyQ' || e.key === 'q') dropHeld();
    if (e.code === 'KeyF' || e.key === 'f') grabOrUse();
  }
  function onKeyUp(e) {
    keys[e.code] = false;
    if (e.key) keys[e.key.toLowerCase()] = false;
  }
  window.addEventListener('keydown', onKeyDown, true);
  window.addEventListener('keyup', onKeyUp, true);

  btnStart.addEventListener('click', () => {
    overlay.classList.add('hidden');
    jobPick.classList.remove('hidden');
  });
  document.querySelectorAll('.job-btn').forEach((btn) => {
    btn.addEventListener('click', () => startJob(btn.getAttribute('data-job')));
  });
  btnAgain.addEventListener('click', () => {
    endScreen.classList.add('hidden');
    jobPick.classList.remove('hidden');
    clearWorld();
  });

  // lobby default floor so not black before job
  floor(20, 20, 0x4a5568, 0, 0);

  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    update(dt);
    if (!started) {
      camera.position.set(player.x, player.y, player.z);
      camera.rotation.set(player.pitch, player.yaw, 0);
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
