# Minecraft Grass 2023 — Mini Replica


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

First-person voxel mini inspired by modern Minecraft: grass terrain, hotbar, place/mine, creative & survival, chat commands, blocky hand mining animation, and zombies.

## Play

```bash
cd projects/creative-visualizers-and-games/minecraft-grass-2023
python3 -m http.server 8772
```

Open **http://127.0.0.1:8772/**

## Controls

| | |
|--|--|
| WASD | Move |
| Mouse | Look |
| Space | Jump (or fly up in creative fly) |
| Shift | Sprint |
| LMB | Mine (hold in survival) |
| RMB | Place grass |
| 1–9 | Hotbar |
| T or / | Chat |
| F | Toggle fly (creative only) |
| C / Ctrl | Fly down |

## Chat commands

| Command | Effect |
|---------|--------|
| `/creativemode` | Creative (instant mine, infinite blocks) |
| `/survivalmode` | Survival (hearts, timed mine, inventory counts) |
| `/spawn5zombie` | Spawn 5 zombies |
| `/spawn(3)zombie` | Spawn 3 zombies |
| `/spawnzombie` | Spawn 1 zombie |
| `/help` | List commands |

## Textures

PNG files in `assets/` (nearest-neighbor, blocky):

| File | Face |
|------|------|
| `assets/grass_block_top.png` | Grass top |
| `assets/grass_block_side.png` | Grass side |
| `assets/dirt.png` | Dirt / grass bottom |
| `assets/stone.png` | Stone |

**Current grass/dirt source:** Filter Forge filter [#11635 “Minecraft Grass”](https://www.filterforge.com/filters/11635.html) by Austy51 (via your Google share link), processed into top/side/dirt faces for this prototype.

Drop different PNGs over these and hard-refresh to swap.

## Notes

- World is a 48×48 grass/dirt/stone heightmap (hotbar is **grass** only as requested)
- Blocky arm on the right swings when you mine/place
- Zombies chase you and damage you in survival
