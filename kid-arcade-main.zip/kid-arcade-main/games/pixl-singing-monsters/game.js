/**
 * Pixl Singing Monsters — 2D pixel MSM-inspired jam island
 * Each note a monster plays → +5 PixlCoins
 */
(function () {
  'use strict';

  const STEPS = 8;
  const COINS_PER_NOTE = 5;
  const SAVE_KEY = 'pixl_singing_v1';
  const SLOTS = 8; // 4x2 grid

  // note names → semitone from C4
  const NOTE = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11, R: null };

  const CATALOG = [
    {
      id: 'toot',
      name: 'Tootling',
      desc: 'Soft flute peeps',
      price: 0,
      color: '#7ec8ff',
      eye: '#1a2040',
      wave: 'triangle',
      pattern: ['C', 'R', 'E', 'R', 'G', 'R', 'E', 'R'],
      octave: 5,
    },
    {
      id: 'boop',
      name: 'Booplet',
      desc: 'Bouncy bass blips',
      price: 40,
      color: '#ff8a6a',
      eye: '#301010',
      wave: 'square',
      pattern: ['C', 'C', 'R', 'G', 'R', 'E', 'R', 'R'],
      octave: 3,
    },
    {
      id: 'chirp',
      name: 'Chirpling',
      desc: 'High sparkle chirps',
      price: 60,
      color: '#ffe066',
      eye: '#403010',
      wave: 'sine',
      pattern: ['R', 'E', 'R', 'G', 'R', 'B', 'R', 'G'],
      octave: 6,
    },
    {
      id: 'thump',
      name: 'Thumpkin',
      desc: 'Drum-like thumps',
      price: 80,
      color: '#b080ff',
      eye: '#201040',
      wave: 'sawtooth',
      pattern: ['C', 'R', 'R', 'C', 'R', 'R', 'C', 'G'],
      octave: 2,
      drum: true,
    },
    {
      id: 'wub',
      name: 'Wubster',
      desc: 'Wobbly mid groove',
      price: 100,
      color: '#6dffb0',
      eye: '#103020',
      wave: 'sawtooth',
      pattern: ['E', 'R', 'G', 'R', 'A', 'R', 'G', 'R'],
      octave: 4,
    },
    {
      id: 'honk',
      name: 'Honklo',
      desc: 'Goofy brass honks',
      price: 120,
      color: '#ff6bcb',
      eye: '#401028',
      wave: 'square',
      pattern: ['G', 'G', 'E', 'R', 'C', 'R', 'E', 'G'],
      octave: 4,
    },
    {
      id: 'plunk',
      name: 'Plunko',
      desc: 'Kalimba plinks',
      price: 150,
      color: '#9ad0ff',
      eye: '#102030',
      wave: 'triangle',
      pattern: ['C', 'E', 'G', 'B', 'G', 'E', 'C', 'R'],
      octave: 5,
    },
    {
      id: 'growl',
      name: 'Growlbit',
      desc: 'Pixel growl bass',
      price: 180,
      color: '#c07040',
      eye: '#201008',
      wave: 'sawtooth',
      pattern: ['C', 'R', 'C', 'D', 'R', 'E', 'R', 'C'],
      octave: 2,
    },
    {
      id: 'spark',
      name: 'Sparkle',
      desc: 'Arpy star dust',
      price: 220,
      color: '#fff0a0',
      eye: '#403800',
      wave: 'sine',
      pattern: ['C', 'E', 'G', 'C', 'G', 'E', 'C', 'G'],
      octave: 6,
    },
    {
      id: 'blob',
      name: 'Blobula',
      desc: 'Jelly offbeats',
      price: 260,
      color: '#80ffd0',
      eye: '#104030',
      wave: 'triangle',
      pattern: ['R', 'R', 'A', 'R', 'R', 'G', 'R', 'E'],
      octave: 4,
    },
    {
      id: 'zappy',
      name: 'Zappy',
      desc: 'Electric zaps',
      price: 300,
      color: '#60e0ff',
      eye: '#082030',
      wave: 'square',
      pattern: ['B', 'R', 'G', 'R', 'E', 'R', 'G', 'B'],
      octave: 5,
    },
    {
      id: 'crown',
      name: 'Crownoid',
      desc: 'Royal fanfare',
      price: 400,
      color: '#ffd24a',
      eye: '#403000',
      wave: 'square',
      pattern: ['C', 'E', 'G', 'C', 'B', 'G', 'E', 'C'],
      octave: 5,
    },
  ];

  const state = {
    coins: 25,
    owned: { toot: true },
    selected: 'toot',
    slots: Array(SLOTS).fill(null), // monster ids
    playing: false,
    step: 0,
    bpm: 100,
    muted: false,
  };

  let audioCtx = null;
  let master = null;
  let timer = null;
  let sprites = {};

  // ——— persistence ———
  function load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      if (typeof d.coins === 'number') state.coins = d.coins;
      if (d.owned) state.owned = d.owned;
      if (Array.isArray(d.slots) && d.slots.length === SLOTS) state.slots = d.slots;
      if (d.selected) state.selected = d.selected;
      if (d.bpm) state.bpm = d.bpm;
    } catch (_) {}
  }
  function save() {
    localStorage.setItem(
      SAVE_KEY,
      JSON.stringify({
        coins: state.coins,
        owned: state.owned,
        slots: state.slots,
        selected: state.selected,
        bpm: state.bpm,
      })
    );
  }

  // ——— audio ———
  function ensureAudio() {
    if (audioCtx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    audioCtx = new AC();
    master = audioCtx.createGain();
    master.gain.value = state.muted ? 0 : 0.22;
    master.connect(audioCtx.destination);
  }

  function freqOf(noteName, octave) {
    const semi = NOTE[noteName];
    if (semi == null) return null;
    // A4 = 440, MIDI 69
    const midi = 12 * (octave + 1) + semi; // C4 = 60 when octave=4: 12*5+0=60
    return 440 * Math.pow(2, (midi - 69) / 12);
  }

  function playTone(monster, noteName) {
    if (state.muted || noteName === 'R' || noteName == null) return;
    ensureAudio();
    if (audioCtx.state === 'suspended') audioCtx.resume();

    const t0 = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = monster.wave || 'square';

    if (monster.drum) {
      // noise-ish thump via pitch drop
      osc.frequency.setValueAtTime(120, t0);
      osc.frequency.exponentialRampToValueAtTime(40, t0 + 0.12);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.5, t0 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.18);
      osc.connect(g);
      g.connect(master);
      osc.start(t0);
      osc.stop(t0 + 0.2);
      return;
    }

    const f = freqOf(noteName, monster.octave || 4);
    if (!f) return;
    osc.frequency.setValueAtTime(f, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.35, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.28);
    osc.connect(g);
    g.connect(master);
    osc.start(t0);
    osc.stop(t0 + 0.3);
  }

  // ——— pixel sprites (canvas data URLs) ———
  function drawMonsterSprite(m, size) {
    const c = document.createElement('canvas');
    c.width = size;
    c.height = size;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    const s = size / 16;

    function px(x, y, w, h, col) {
      ctx.fillStyle = col;
      ctx.fillRect(x * s, y * s, w * s, h * s);
    }

    // body blob
    px(3, 5, 10, 8, m.color);
    px(4, 4, 8, 1, m.color);
    px(4, 13, 8, 1, shade(m.color, -30));
    // belly
    px(5, 8, 6, 4, shade(m.color, 40));
    // eyes
    px(5, 7, 2, 2, '#fff');
    px(9, 7, 2, 2, '#fff');
    px(6, 8, 1, 1, m.eye);
    px(10, 8, 1, 1, m.eye);
    // mouth
    px(7, 11, 2, 1, m.eye);
    // feet
    px(5, 14, 2, 1, shade(m.color, -40));
    px(9, 14, 2, 1, shade(m.color, -40));
    // antenna / ears vary by id hash
    const h = m.id.charCodeAt(0) % 3;
    if (h === 0) {
      px(7, 2, 2, 2, m.color);
      px(7, 1, 2, 1, '#fff');
    } else if (h === 1) {
      px(3, 3, 2, 2, m.color);
      px(11, 3, 2, 2, m.color);
    } else {
      px(4, 3, 1, 2, m.color);
      px(11, 3, 1, 2, m.color);
    }

    return c;
  }

  function shade(hex, amt) {
    const n = hex.replace('#', '');
    const num = parseInt(n.length === 3 ? n.split('').map((c) => c + c).join('') : n, 16);
    let r = (num >> 16) + amt;
    let g = ((num >> 8) & 0xff) + amt;
    let b = (num & 0xff) + amt;
    r = Math.max(0, Math.min(255, r));
    g = Math.max(0, Math.min(255, g));
    b = Math.max(0, Math.min(255, b));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  function getSprite(id) {
    if (!sprites[id]) {
      const m = CATALOG.find((x) => x.id === id);
      sprites[id] = drawMonsterSprite(m, 64);
    }
    return sprites[id];
  }

  // ——— UI refs ———
  const $ = (s) => document.querySelector(s);
  const coinsEl = $('#coins');
  const gridEl = $('#grid');
  const shopEl = $('#shop-list');
  const selectedInfo = $('#selected-info');
  const beatLights = $('#beat-lights');
  const floatLayer = $('#float-coins');

  function formatCoins(n) {
    return Math.floor(n).toLocaleString();
  }

  function updateCoins() {
    coinsEl.textContent = formatCoins(state.coins);
  }

  function floatCoin(x, y) {
    const el = document.createElement('div');
    el.className = 'floater';
    el.textContent = '+' + COINS_PER_NOTE;
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    floatLayer.appendChild(el);
    setTimeout(() => el.remove(), 950);
  }

  function monsterById(id) {
    return CATALOG.find((m) => m.id === id);
  }

  // ——— grid ———
  function renderGrid() {
    gridEl.innerHTML = '';
    for (let i = 0; i < SLOTS; i++) {
      const pad = document.createElement('div');
      const id = state.slots[i];
      pad.className = 'pad' + (id ? ' filled' : ' empty');
      pad.dataset.slot = String(i);

      if (id) {
        const m = monsterById(id);
        const img = document.createElement('canvas');
        img.width = 64;
        img.height = 64;
        img.className = 'sprite';
        img.getContext('2d').drawImage(getSprite(id), 0, 0);
        const name = document.createElement('div');
        name.className = 'mname';
        name.textContent = m.name;
        const rm = document.createElement('button');
        rm.type = 'button';
        rm.className = 'remove';
        rm.title = 'Remove to inventory (keeps owned)';
        rm.textContent = '×';
        rm.addEventListener('click', (e) => {
          e.stopPropagation();
          state.slots[i] = null;
          save();
          renderGrid();
        });
        pad.appendChild(img);
        pad.appendChild(name);
        pad.appendChild(rm);
      }

      pad.addEventListener('click', () => onPadClick(i));
      gridEl.appendChild(pad);
    }
  }

  function onPadClick(i) {
    ensureAudio();
    if (state.slots[i]) {
      // preview monster sound
      const m = monsterById(state.slots[i]);
      const n = m.pattern.find((x) => x !== 'R') || 'C';
      playTone(m, n);
      return;
    }
    if (!state.selected || !state.owned[state.selected]) {
      flashSelected('Buy / select a monster first!');
      return;
    }
    // one of each type on island? allow multiples for fun
    state.slots[i] = state.selected;
    save();
    renderGrid();
    const m = monsterById(state.selected);
    playTone(m, m.pattern.find((x) => x !== 'R') || 'C');
  }

  function flashSelected(msg) {
    selectedInfo.textContent = msg;
    selectedInfo.style.color = '#ff8a8a';
    setTimeout(() => {
      selectedInfo.style.color = '';
      updateSelectedInfo();
    }, 1200);
  }

  // ——— shop ———
  function renderShop() {
    shopEl.innerHTML = '';
    CATALOG.forEach((m) => {
      const owned = !!state.owned[m.id];
      const card = document.createElement('button');
      card.type = 'button';
      card.className =
        'shop-card' +
        (state.selected === m.id ? ' selected' : '') +
        (!owned ? ' locked' : '');

      const cv = document.createElement('canvas');
      cv.width = 48;
      cv.height = 48;
      cv.getContext('2d').drawImage(getSprite(m.id), 0, 0, 48, 48);

      const info = document.createElement('div');
      info.className = 'info';
      info.innerHTML = `<div class="name">${m.name}</div><div class="desc">${m.desc}</div>`;

      const price = document.createElement('div');
      price.className = 'price' + (owned ? ' owned' : '');
      price.textContent = owned ? 'OWNED' : m.price + ' ●';

      card.appendChild(cv);
      card.appendChild(info);
      card.appendChild(price);

      if (!owned) {
        const buy = document.createElement('button');
        buy.type = 'button';
        buy.className = 'buy-btn';
        buy.textContent =
          state.coins >= m.price ? `BUY for ${m.price} PixlCoins` : `Need ${m.price - state.coins} more`;
        buy.disabled = state.coins < m.price;
        buy.addEventListener('click', (e) => {
          e.stopPropagation();
          buyMonster(m.id);
        });
        card.appendChild(buy);
      }

      card.addEventListener('click', () => {
        if (!state.owned[m.id]) return;
        state.selected = m.id;
        save();
        renderShop();
        updateSelectedInfo();
        // preview
        ensureAudio();
        playTone(m, m.pattern.find((x) => x !== 'R') || 'C');
      });

      shopEl.appendChild(card);
    });
  }

  function buyMonster(id) {
    const m = monsterById(id);
    if (!m || state.owned[id]) return;
    if (state.coins < m.price) {
      flashSelected('Not enough PixlCoins!');
      return;
    }
    state.coins -= m.price;
    state.owned[id] = true;
    state.selected = id;
    ensureAudio();
    playTone(m, m.pattern.find((x) => x !== 'R') || 'C');
    save();
    updateCoins();
    renderShop();
    updateSelectedInfo();
  }

  function updateSelectedInfo() {
    const m = monsterById(state.selected);
    if (!m || !state.owned[state.selected]) {
      selectedInfo.textContent = 'Pick a monster you own';
      return;
    }
    selectedInfo.innerHTML = `<strong style="color:${m.color}">${m.name}</strong> ready to place · click an empty pad`;
  }

  // ——— sequencer ———
  function stepMs() {
    return (60 / state.bpm) * 1000 / 2; // 8th notes
  }

  function renderBeatLights() {
    beatLights.innerHTML = '';
    for (let i = 0; i < STEPS; i++) {
      const s = document.createElement('span');
      if (state.playing && state.step === i) s.classList.add('on');
      beatLights.appendChild(s);
    }
  }

  function tick() {
    const step = state.step;
    renderBeatLights();

    const pads = gridEl.querySelectorAll('.pad');
    pads.forEach((p) => p.classList.remove('hit'));

    state.slots.forEach((id, slotIdx) => {
      if (!id) return;
      const m = monsterById(id);
      const note = m.pattern[step % m.pattern.length];
      if (note && note !== 'R') {
        playTone(m, note);
        state.coins += COINS_PER_NOTE;
        const pad = pads[slotIdx];
        if (pad) {
          pad.classList.add('hit');
          const r = pad.getBoundingClientRect();
          floatCoin(r.left + r.width / 2 - 12, r.top + 8);
        }
      }
    });

    updateCoins();
    // cheap: refresh shop buy buttons every few coins
    if (state.step % 4 === 0) renderShop();
    save();

    state.step = (state.step + 1) % STEPS;
  }

  function startJam() {
    ensureAudio();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    if (state.playing) return;
    // need at least one monster
    if (!state.slots.some(Boolean)) {
      flashSelected('Place a monster on the island first!');
      return;
    }
    state.playing = true;
    state.step = 0;
    $('#btn-play').textContent = '♫ JAMMING…';
    tick();
    timer = setInterval(tick, stepMs());
  }

  function stopJam() {
    state.playing = false;
    if (timer) clearInterval(timer);
    timer = null;
    $('#btn-play').textContent = '▶ PLAY JAM';
    renderBeatLights();
    gridEl.querySelectorAll('.pad').forEach((p) => p.classList.remove('hit'));
  }

  function setBpm(v) {
    state.bpm = v;
    $('#bpm-label').textContent = String(v);
    if (state.playing) {
      clearInterval(timer);
      timer = setInterval(tick, stepMs());
    }
    save();
  }

  // ——— wire ———
  function init() {
    load();
    // free starter on island if empty
    if (!state.slots.some(Boolean) && state.owned.toot) {
      state.slots[0] = 'toot';
    }
    updateCoins();
    renderGrid();
    renderShop();
    updateSelectedInfo();
    renderBeatLights();
    $('#bpm').value = state.bpm;
    $('#bpm-label').textContent = String(state.bpm);

    $('#btn-play').addEventListener('click', startJam);
    $('#btn-stop').addEventListener('click', stopJam);
    $('#bpm').addEventListener('input', (e) => setBpm(+e.target.value));
    $('#btn-mute').addEventListener('click', () => {
      state.muted = !state.muted;
      $('#btn-mute').textContent = state.muted ? '🔇 Muted' : '🔊 Sound';
      if (master) master.gain.value = state.muted ? 0 : 0.22;
    });

    // unlock audio on first gesture
    window.addEventListener(
      'pointerdown',
      () => {
        ensureAudio();
        if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
      },
      { once: true }
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
