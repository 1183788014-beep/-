# Pixl Singing Monsters


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

2D **pixel** jam island inspired by *My Singing Monsters* (not affiliated).

- Place monsters on pads
- Hit **PLAY JAM** — they loop musical patterns
- **Every note = +5 PixlCoins**
- Spend coins in the **Monster Shop** (12 critters)

```bash
cd projects/creative-visualizers-and-games/pixl-singing-monsters
python3 -m http.server 8776
```

Open http://127.0.0.1:8776/
