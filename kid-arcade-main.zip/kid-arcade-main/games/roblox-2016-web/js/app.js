/* Roblox 2016 fan site — local avatar/settings, real game links */
(function () {
  'use strict';

  const STORAGE_KEY = 'rbx2016_profile_v1';

  const BRICK_COLORS = [
    { name: 'White', hex: '#F2F3F3' },
    { name: 'Light stone grey', hex: '#E5E4DF' },
    { name: 'Medium stone grey', hex: '#A3A2A5' },
    { name: 'Dark stone grey', hex: '#635F62' },
    { name: 'Black', hex: '#1B2A35' },
    { name: 'Bright red', hex: '#C4281C' },
    { name: 'Bright yellow', hex: '#F5CD30' },
    { name: 'Cool yellow', hex: '#FDEA8D' },
    { name: 'Bright blue', hex: '#0D69AC' },
    { name: 'Bright bluish green', hex: '#00A2FF' },
    { name: 'Bright green', hex: '#4B974B' },
    { name: 'Earth green', hex: '#27462D' },
    { name: 'Bright violet', hex: '#6B327C' },
    { name: 'Bright orange', hex: '#DA8541' },
    { name: 'Brown', hex: '#A05F35' },
    { name: 'Nougat', hex: '#CC8E69' },
    { name: 'Light orange', hex: '#E29B40' },
    { name: 'Pink', hex: '#FF98DC' },
    { name: 'Pastel Blue', hex: '#80BBDB' },
    { name: 'Institutional white', hex: '#F8F8F8' },
  ];

  const CATALOG = {
    hats: [
      { id: 'hat_none', name: 'None', icon: '·' },
      { id: 'hat_domino', name: 'Domino Crown', icon: '👑' },
      { id: 'hat_fedora', name: 'Teal Fedora', icon: '🎩' },
      { id: 'hat_pizza', name: 'Pizza Face', icon: '🍕' },
      { id: 'hat_sshf', name: 'SSHF', icon: '😎' },
      { id: 'hat_troll', name: 'Troll', icon: '😈' },
      { id: 'hat_duck', name: 'Ducky', icon: '🦆' },
      { id: 'hat_afro', name: 'Afro', icon: '髪型' },
    ],
    faces: [
      { id: 'face_smile', name: 'Smile', icon: '😊' },
      { id: 'face_man', name: 'Man Face', icon: '😐' },
      { id: 'face_woman', name: 'Woman Face', icon: '🙂' },
      { id: 'face_checkit', name: 'Check It', icon: '😏' },
      { id: 'face_epic', name: 'Epic Face', icon: '😜' },
      { id: 'face_angry', name: 'Angry', icon: '😠' },
    ],
    shirts: [
      { id: 'shirt_none', name: 'Default', icon: '👕' },
      { id: 'shirt_bacon', name: 'Bacon Hair Tee', icon: '🥓' },
      { id: 'shirt_guest', name: 'Guest Shirt', icon: '👤' },
      { id: 'shirt_red', name: 'Red Tee', icon: '🔴' },
      { id: 'shirt_blue', name: 'Blue Tee', icon: '🔵' },
      { id: 'shirt_build', name: 'Builderman', icon: '🔧' },
    ],
    pants: [
      { id: 'pants_default', name: 'Default', icon: '👖' },
      { id: 'pants_jeans', name: 'Jeans', icon: '🟦' },
      { id: 'pants_shorts', name: 'Shorts', icon: '🩳' },
      { id: 'pants_suit', name: 'Suit Pants', icon: '⬛' },
    ],
    gear: [
      { id: 'gear_none', name: 'None', icon: '·' },
      { id: 'gear_linked', name: 'Linked Sword', icon: '⚔️' },
      { id: 'gear_pizza', name: 'Pizza', icon: '🍕' },
      { id: 'gear_trowel', name: 'Trowel', icon: '🧱' },
      { id: 'gear_sling', name: 'Slingshot', icon: '🎯' },
    ],
  };

  const defaultProfile = () => ({
    username: 'Player' + (1000 + Math.floor(Math.random() * 9000)),
    displayName: 'Builderman Fan',
    blurb: 'Welcome to my profile! 2016 vibes only.',
    robux: 1337,
    tickets: 250,
    joinDate: '3/15/2016',
    avatar: {
      head: '#F5CD30',
      torso: '#0D69AC',
      leftArm: '#F5CD30',
      rightArm: '#F5CD30',
      leftLeg: '#4B974B',
      rightLeg: '#4B974B',
      hat: 'hat_none',
      face: 'face_smile',
      shirt: 'shirt_none',
      pants: 'pants_default',
      gear: 'gear_none',
    },
    settings: {
      email: '',
      theme: 'classic',
      privacy: 'friends',
      trade: true,
      inventory: 'everyone',
      chatFilter: true,
      music: true,
      passwordHint: '',
    },
    friends: ['Builderman', 'Telamon', 'Shedletsky', 'Guest 1337'],
  });

  function loadProfile() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultProfile();
      return Object.assign(defaultProfile(), JSON.parse(raw));
    } catch {
      return defaultProfile();
    }
  }
  function saveProfile() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  }

  let profile = loadProfile();
  let games = [];
  let activePart = 'torso';
  let settingsTab = 'account';

  // --- DOM helpers ---
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  function toast(msg) {
    const el = $('#toast');
    el.textContent = msg;
    el.classList.add('on');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => el.classList.remove('on'), 2200);
  }

  function navigate(page) {
    $$('.page').forEach((p) => p.classList.remove('active'));
    $$('.nav-link').forEach((a) => a.classList.remove('active'));
    const el = $('#page-' + page);
    if (el) el.classList.add('active');
    const link = document.querySelector(`.nav-link[data-page="${page}"]`);
    if (link) link.classList.add('active');
    const titles = {
      home: 'Home',
      games: 'Games',
      catalog: 'Catalog',
      avatar: 'Avatar',
      profile: 'Profile',
      settings: 'Settings',
    };
    $('#page-title').textContent = titles[page] || 'Roblox';
    location.hash = page;
    if (page === 'avatar' || page === 'catalog') {
      renderAvatarEditor();
      drawAvatar();
    }
    if (page === 'profile') renderProfile();
    if (page === 'settings') renderSettings();
    if (page === 'games') renderGames(games);
    if (page === 'home') renderHome();
  }

  // --- Avatar canvas R6 (draw every .r6-view on page) ---
  function drawAvatarOn(c) {
    if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);
    const a = profile.avatar;
    const scale = Math.min(W, H) / 100;
    const ox = W / 2, oy = H * 0.12;

    function block(x, y, w, h, color) {
      ctx.fillStyle = color;
      ctx.fillRect(ox + x * scale, oy + y * scale, w * scale, h * scale);
      ctx.strokeStyle = 'rgba(0,0,0,0.25)';
      ctx.lineWidth = 1;
      ctx.strokeRect(ox + x * scale + 0.5, oy + y * scale + 0.5, w * scale - 1, h * scale - 1);
    }

    block(-10, 48, 9, 20, a.leftLeg);
    block(1, 48, 9, 20, a.rightLeg);
    block(-10, 28, 20, 20, a.torso);
    block(-20, 28, 10, 20, a.leftArm);
    block(10, 28, 10, 20, a.rightArm);
    block(-10, 16, 20, 12, a.head);

    ctx.fillStyle = '#111';
    const faceY = oy + 20 * scale;
    if (a.face === 'face_angry') {
      ctx.fillRect(ox - 6 * scale, faceY, 3 * scale, 2 * scale);
      ctx.fillRect(ox + 3 * scale, faceY, 3 * scale, 2 * scale);
      ctx.fillRect(ox - 4 * scale, faceY + 5 * scale, 8 * scale, 2 * scale);
    } else if (a.face === 'face_epic') {
      ctx.fillRect(ox - 7 * scale, faceY, 4 * scale, 3 * scale);
      ctx.fillRect(ox + 3 * scale, faceY, 4 * scale, 3 * scale);
      ctx.beginPath();
      ctx.arc(ox, faceY + 6 * scale, 4 * scale, 0, Math.PI);
      ctx.fill();
    } else {
      ctx.fillRect(ox - 6 * scale, faceY, 3 * scale, 2 * scale);
      ctx.fillRect(ox + 3 * scale, faceY, 3 * scale, 2 * scale);
      ctx.beginPath();
      ctx.strokeStyle = '#111';
      ctx.lineWidth = 2;
      ctx.arc(ox, faceY + 4 * scale, 4 * scale, 0.15 * Math.PI, 0.85 * Math.PI);
      ctx.stroke();
    }
    const hat = CATALOG.hats.find((h) => h.id === a.hat);
    if (hat && hat.id !== 'hat_none') {
      ctx.font = `${Math.max(16, 16 * scale)}px serif`;
      ctx.textAlign = 'center';
      ctx.fillText(hat.icon, ox, oy + 14 * scale);
    }
    const gear = CATALOG.gear.find((g) => g.id === a.gear);
    if (gear && gear.id !== 'gear_none') {
      ctx.font = `${Math.max(14, 12 * scale)}px serif`;
      ctx.fillText(gear.icon, ox + 22 * scale, oy + 40 * scale);
    }
  }
  function drawAvatar() {
    document.querySelectorAll('canvas.r6-view').forEach(drawAvatarOn);
    document.querySelectorAll('.avatar-stage .name-tag').forEach((el) => {
      el.textContent = profile.username;
    });
  }

  // --- Games ---
  function gameCardHtml(g) {
    return `
      <div class="game-card" data-id="${g.placeId}">
        <div class="thumb" style="background-image:url('${g.thumb || ''}')">
          <span class="players">👤 ${formatPlayers(g.players)}</span>
        </div>
        <div class="meta">
          <div class="title">${esc(g.name)}</div>
          <div class="by">By ${esc(g.creator)}</div>
          <div class="likes">👍 ${g.likes}%</div>
        </div>
      </div>`;
  }
  function bindGameCards(root) {
    (root || document).querySelectorAll('.game-card').forEach((card) => {
      card.addEventListener('click', () => openGameModal(+card.dataset.id));
    });
  }
  function renderGames(list) {
    const q = ($('#game-search')?.value || '').toLowerCase();
    const genre = $('#game-genre')?.value || 'all';
    const filtered = list.filter((g) => {
      if (q && !g.name.toLowerCase().includes(q) && !g.creator.toLowerCase().includes(q)) return false;
      if (genre !== 'all' && g.genre !== genre) return false;
      return true;
    });
    // home popular + games page share class — fill the active page's grid
    const grids = [];
    const homeGrid = $('#page-home #games-grid');
    const gamesGrid = $('#page-games #games-grid');
    if ($('#page-home')?.classList.contains('active') && homeGrid) grids.push({ el: homeGrid, items: list.slice(0, 8) });
    if ($('#page-games')?.classList.contains('active') && gamesGrid) grids.push({ el: gamesGrid, items: filtered });
    // if neither, still fill games grid for first paint
    if (!grids.length && gamesGrid) grids.push({ el: gamesGrid, items: filtered });
    if (!grids.length && homeGrid) grids.push({ el: homeGrid, items: list.slice(0, 8) });
    grids.forEach(({ el, items }) => {
      el.innerHTML = items.map(gameCardHtml).join('');
      bindGameCards(el);
    });
  }

  function formatPlayers(n) {
    if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return String(n);
  }

  function openGameModal(placeId) {
    const g = games.find((x) => x.placeId === placeId);
    if (!g) return;
    const modal = $('#modal');
    $('#modal-title').textContent = g.name;
    $('#modal-by').textContent = 'By ' + g.creator + ' · ' + g.genre;
    $('#modal-desc').textContent = g.desc;
    $('#modal-hero').style.backgroundImage = g.thumb ? `url('${g.thumb}')` : '';
    const play = $('#modal-play');
    play.href = g.url;
    play.onclick = () => {
      // open real Roblox
      window.open(g.url, '_blank', 'noopener,noreferrer');
      toast('Opening real Roblox…');
    };
    const preview = $('#modal-preview');
    preview.onclick = () => {
      // "preview" = open in new tab too (real site) — or show embed note
      window.open(g.url, '_blank', 'noopener,noreferrer');
      toast('Preview → roblox.com');
    };
    modal.classList.add('on');
  }

  function renderHome() {
    // featured = first game
    const feat = games[0];
    if (feat) {
      $('#feat-thumb').style.backgroundImage = feat.thumb ? `url('${feat.thumb}')` : '';
      $('#feat-title').textContent = feat.name;
      $('#feat-desc').textContent = feat.desc;
      $('#feat-play').href = feat.url;
      $('#feat-play').onclick = (e) => {
        e.preventDefault();
        window.open(feat.url, '_blank', 'noopener,noreferrer');
      };
    }
    // continue / popular
    renderGames(games.slice(0, 8));
    const cont = $('#continue-grid');
    if (cont) {
      cont.innerHTML = games.slice(0, 4).map((g) => `
        <div class="game-card" data-id="${g.placeId}">
          <div class="thumb" style="background-image:url('${g.thumb || ''}')">
            <span class="players">👤 ${formatPlayers(g.players)}</span>
          </div>
          <div class="meta">
            <div class="title">${esc(g.name)}</div>
            <div class="by">By ${esc(g.creator)}</div>
          </div>
        </div>
      `).join('');
      cont.querySelectorAll('.game-card').forEach((card) => {
        card.addEventListener('click', () => openGameModal(+card.dataset.id));
      });
    }
    // friends feed
    const feed = $('#friend-feed');
    if (feed) {
      feed.innerHTML = profile.friends.map((f, i) => `
        <div class="feed-item">
          <div class="av" style="background:${BRICK_COLORS[i % BRICK_COLORS.length].hex}"></div>
          <div class="txt">
            <strong>${esc(f)}</strong>
            <p>${['is playing Jailbreak', 'joined a server', 'got a new hat', 'is online now'][i % 4]}</p>
          </div>
          <div class="time">${i + 1}h</div>
        </div>
      `).join('');
    }
    updateNavUser();
  }

  function renderProfile() {
    $('#prof-name').textContent = profile.username;
    $('#prof-display').textContent = profile.displayName;
    $('#prof-blurb').textContent = profile.blurb;
    $('#prof-join').textContent = profile.joinDate;
    $('#prof-robux').textContent = profile.robux.toLocaleString();
    drawAvatar();
  }

  function renderAvatarEditor() {
    const sw = $('#color-swatches');
    sw.innerHTML = BRICK_COLORS.map((c) =>
      `<button type="button" class="swatch" title="${c.name}" data-hex="${c.hex}" style="background:${c.hex}"></button>`
    ).join('');
    sw.querySelectorAll('.swatch').forEach((btn) => {
      btn.addEventListener('click', () => {
        profile.avatar[activePart] = btn.dataset.hex;
        saveProfile();
        drawAvatar();
        toast('Color applied to ' + activePart);
        highlightSwatch();
      });
    });
    highlightSwatch();

    $$('.part-tabs button').forEach((b) => {
      b.classList.toggle('active', b.dataset.part === activePart);
      b.onclick = () => {
        activePart = b.dataset.part;
        renderAvatarEditor();
        drawAvatar();
      };
    });

    // catalog items — fill every matching grid on the page
    ['hats', 'faces', 'shirts', 'pants', 'gear'].forEach((cat) => {
      const key = cat === 'hats' ? 'hat' : cat === 'faces' ? 'face' : cat === 'shirts' ? 'shirt' : cat === 'pants' ? 'pants' : 'gear';
      document.querySelectorAll('[data-items="' + cat + '"]').forEach((grid) => {
        grid.innerHTML = CATALOG[cat].map((item) => `
          <div class="item-cell ${profile.avatar[key] === item.id ? 'on' : ''}" data-cat="${key}" data-id="${item.id}">
            <div class="ico">${item.icon}</div>
            ${esc(item.name)}
          </div>
        `).join('');
        grid.querySelectorAll('.item-cell').forEach((cell) => {
          cell.addEventListener('click', () => {
            profile.avatar[cell.dataset.cat] = cell.dataset.id;
            if (cell.dataset.id === 'shirt_red') profile.avatar.torso = '#C4281C';
            if (cell.dataset.id === 'shirt_blue') profile.avatar.torso = '#0D69AC';
            if (cell.dataset.id === 'shirt_build') profile.avatar.torso = '#6B327C';
            saveProfile();
            renderAvatarEditor();
            drawAvatar();
            toast('Equipped ' + cell.textContent.trim());
          });
        });
      });
    });
  }

  function highlightSwatch() {
    const cur = profile.avatar[activePart];
    $$('#color-swatches .swatch').forEach((s) => {
      s.classList.toggle('active', s.dataset.hex.toLowerCase() === String(cur).toLowerCase());
    });
  }

  function renderSettings() {
    const body = $('#settings-body');
    if (!body) return;
    const s = profile.settings;
    if (settingsTab === 'account') {
      body.innerHTML = `
        <h2>Account Info</h2>
        <div class="form-row">
          <label>Username</label>
          <input type="text" id="set-user" value="${esc(profile.username)}" maxlength="20" />
          <div class="hint">This is how others see you on this fan site (saved locally).</div>
        </div>
        <div class="form-row">
          <label>Display Name</label>
          <input type="text" id="set-display" value="${esc(profile.displayName)}" maxlength="40" />
        </div>
        <div class="form-row">
          <label>About / Blurb</label>
          <input type="text" id="set-blurb" value="${esc(profile.blurb)}" maxlength="120" />
        </div>
        <div class="form-row">
          <label>Email (local only — not sent anywhere)</label>
          <input type="text" id="set-email" value="${esc(s.email)}" placeholder="you@example.com" />
        </div>
        <button type="button" class="btn" id="save-account">Save</button>
      `;
      $('#save-account').onclick = () => {
        profile.username = $('#set-user').value.trim() || profile.username;
        profile.displayName = $('#set-display').value.trim() || profile.displayName;
        profile.blurb = $('#set-blurb').value;
        profile.settings.email = $('#set-email').value;
        saveProfile();
        updateNavUser();
        toast('Account settings saved (local)');
      };
    } else if (settingsTab === 'privacy') {
      body.innerHTML = `
        <h2>Privacy</h2>
        <div class="form-row">
          <label>Who can chat with me?</label>
          <select id="set-privacy">
            <option value="everyone" ${s.privacy === 'everyone' ? 'selected' : ''}>Everyone</option>
            <option value="friends" ${s.privacy === 'friends' ? 'selected' : ''}>Friends</option>
            <option value="noone" ${s.privacy === 'noone' ? 'selected' : ''}>No one</option>
          </select>
        </div>
        <div class="form-row">
          <label>Inventory privacy</label>
          <select id="set-inv">
            <option value="everyone" ${s.inventory === 'everyone' ? 'selected' : ''}>Everyone</option>
            <option value="friends" ${s.inventory === 'friends' ? 'selected' : ''}>Friends</option>
            <option value="noone" ${s.inventory === 'noone' ? 'selected' : ''}>No one</option>
          </select>
        </div>
        <label class="toggle"><input type="checkbox" id="set-trade" ${s.trade ? 'checked' : ''}/> Allow trades</label>
        <label class="toggle"><input type="checkbox" id="set-filter" ${s.chatFilter ? 'checked' : ''}/> Chat filter</label>
        <button type="button" class="btn" id="save-privacy">Save Privacy</button>
      `;
      $('#save-privacy').onclick = () => {
        profile.settings.privacy = $('#set-privacy').value;
        profile.settings.inventory = $('#set-inv').value;
        profile.settings.trade = $('#set-trade').checked;
        profile.settings.chatFilter = $('#set-filter').checked;
        saveProfile();
        toast('Privacy saved');
      };
    } else if (settingsTab === 'billing') {
      body.innerHTML = `
        <h2>Billing (Simulated)</h2>
        <p style="margin-bottom:12px;color:#555">This is a fan recreation. No real purchases. Robux here is fake and local only.</p>
        <div class="form-row"><label>Fake Robux balance</label>
          <input type="text" id="set-robux" value="${profile.robux}" />
        </div>
        <button type="button" class="btn" id="save-bill">Update Balance</button>
        <button type="button" class="btn green" id="buy-fake" style="margin-left:8px">+ 400 Robux (fake)</button>
      `;
      $('#save-bill').onclick = () => {
        profile.robux = Math.max(0, parseInt($('#set-robux').value, 10) || 0);
        saveProfile();
        updateNavUser();
        toast('Fake Robux updated');
      };
      $('#buy-fake').onclick = () => {
        profile.robux += 400;
        saveProfile();
        updateNavUser();
        renderSettings();
        toast('+400 fake Robux');
      };
    } else {
      body.innerHTML = `
        <h2>Account Settings</h2>
        <label class="toggle"><input type="checkbox" id="set-music" ${s.music ? 'checked' : ''}/> Website music (nostalgia)</label>
        <div class="form-row">
          <label>Password hint (local only)</label>
          <input type="text" id="set-hint" value="${esc(s.passwordHint)}" />
        </div>
        <button type="button" class="btn" id="save-misc">Save</button>
        <button type="button" class="btn danger" id="reset-profile" style="margin-left:8px">Reset local profile</button>
      `;
      $('#save-misc').onclick = () => {
        profile.settings.music = $('#set-music').checked;
        profile.settings.passwordHint = $('#set-hint').value;
        saveProfile();
        toast('Settings saved');
      };
      $('#reset-profile').onclick = () => {
        if (confirm('Reset all local avatar & settings?')) {
          localStorage.removeItem(STORAGE_KEY);
          profile = loadProfile();
          updateNavUser();
          toast('Profile reset');
          navigate('home');
        }
      };
    }
  }

  function updateNavUser() {
    $('#nav-username').textContent = profile.username;
    $('#nav-robux').textContent = profile.robux.toLocaleString() + ' R$';
    const av = $('#nav-avatar-sm');
    if (av) av.style.background = profile.avatar.torso;
  }

  function esc(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // --- Boot ---
  async function boot() {
    try {
      const res = await fetch('js/games-data.json');
      games = await res.json();
    } catch {
      games = [];
    }

    // nav
    $$('.nav-link[data-page]').forEach((a) => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        navigate(a.dataset.page);
      });
    });
    $('#nav-search-btn')?.addEventListener('click', () => {
      navigate('games');
      const q = $('#nav-search-input').value;
      if ($('#game-search')) {
        $('#game-search').value = q;
        renderGames(games);
      }
    });
    $('#nav-search-input')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') $('#nav-search-btn').click();
    });

    $('#game-search')?.addEventListener('input', () => renderGames(games));
    $('#game-genre')?.addEventListener('change', () => renderGames(games));

    $('#modal-close')?.addEventListener('click', () => $('#modal').classList.remove('on'));
    $('#modal')?.addEventListener('click', (e) => {
      if (e.target.id === 'modal') $('#modal').classList.remove('on');
    });

    $$('.settings-nav button').forEach((b) => {
      b.addEventListener('click', () => {
        settingsTab = b.dataset.tab;
        $$('.settings-nav button').forEach((x) => x.classList.remove('active'));
        b.classList.add('active');
        renderSettings();
      });
    });

    function randomizeAvatar() {
      const parts = ['head', 'torso', 'leftArm', 'rightArm', 'leftLeg', 'rightLeg'];
      parts.forEach((p) => {
        profile.avatar[p] = BRICK_COLORS[Math.floor(Math.random() * BRICK_COLORS.length)].hex;
      });
      profile.avatar.hat = CATALOG.hats[Math.floor(Math.random() * CATALOG.hats.length)].id;
      profile.avatar.face = CATALOG.faces[Math.floor(Math.random() * CATALOG.faces.length)].id;
      saveProfile();
      renderAvatarEditor();
      drawAvatar();
      toast('Randomized avatar');
    }
    ['save-avatar', 'save-avatar-2'].forEach((id) => {
      document.getElementById(id)?.addEventListener('click', () => {
        saveProfile();
        toast('Avatar saved!');
      });
    });
    ['random-avatar', 'random-avatar-2'].forEach((id) => {
      document.getElementById(id)?.addEventListener('click', randomizeAvatar);
    });

    // Go to real roblox home
    $('#real-roblox')?.addEventListener('click', (e) => {
      e.preventDefault();
      window.open('https://www.roblox.com/home', '_blank', 'noopener,noreferrer');
    });

    updateNavUser();
    renderAvatarEditor();
    drawAvatar();

    const page = (location.hash || '#home').replace('#', '') || 'home';
    navigate(page);
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
