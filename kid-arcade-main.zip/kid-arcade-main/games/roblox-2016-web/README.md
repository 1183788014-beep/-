# Roblox 2016 Website — Fan Recreation


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

A **functional fan recreation** of the mid‑2010s Roblox website look (dark top nav, blue header, game cards, avatar, settings).

**Not affiliated with Roblox Corporation.** Avatar/settings save in `localStorage` only. Playing a game opens the **real** page on roblox.com.

## Run

```bash
cd projects/creative-visualizers-and-games/roblox-2016-web
python3 -m http.server 8773
```

Open **http://127.0.0.1:8773/**

## Features

| Page | What it does |
|------|----------------|
| **Home** | Featured game, popular games, friends feed |
| **Games** | Search/filter, click card → preview modal → **Play on Roblox** |
| **Catalog** | Hats/faces/shirts/pants/gear → equip on local R6 |
| **Avatar** | BrickColors body paint + accessories, randomize, save |
| **Profile** | Local username, blurb, fake Robux |
| **Settings** | Account, privacy, billing (fake), reset profile |

Game icons are loaded from Roblox’s public thumbnail API (`js/games-data.json`).

## Refresh game thumbs

```bash
# re-run the python snippet that built games-data.json if icons expire
```
