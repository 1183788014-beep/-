# PIXEL NOOB PLAYER

Pixel-art shell that plays the **real** Noob Song from YouTube.

**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

## The song (your link)

Your share pointed at:

**https://www.youtube.com/watch?v=8K2XQ-iwsF0** — *Roblox | Noob Song* (Jackaroo; Halo 3 noob-meme lineage)

The player embeds that video with the official **YouTube IFrame API** so you hear the **actual track**, not a fake chiptune clone.

We **don’t** rip or redistribute the audio file (copyright). Streaming via YouTube’s player is the correct way.

## Run

```bash
cd projects/creative-visualizers-and-games/pixel-noob-player
python3 -m http.server 8786 --bind 127.0.0.1
```

Open **http://127.0.0.1:8786/** → wait for load → **Play**.

Needs network access to YouTube.
