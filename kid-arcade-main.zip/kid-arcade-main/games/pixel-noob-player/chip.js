/**
 * Original 8-bit chip track — "Living Life (Pixel Noob Chip)"
 * Homemade sequence. NOT HALO's "Living Life As A Noob" (copyrighted).
 * Genre vibe only: upbeat noob / game-menu energy.
 */
(function (global) {
  'use strict';

  // BPM and structure
  const BPM = 132;
  const STEPS_PER_BEAT = 4; // 16th notes
  const BEATS_PER_BAR = 4;
  const BARS = 16; // ~29s loop
  const STEP_DUR = 60 / BPM / STEPS_PER_BEAT;
  const TOTAL_STEPS = BARS * BEATS_PER_BAR * STEPS_PER_BEAT;

  function midi(n) {
    return 440 * Math.pow(2, (n - 69) / 12);
  }

  // Scale helpers (C major / playful)
  const C2 = 36,
    D2 = 38,
    E2 = 40,
    F2 = 41,
    G2 = 43,
    A2 = 45,
    B2 = 47;
  const C3 = 48,
    D3 = 50,
    E3 = 52,
    F3 = 53,
    G3 = 55,
    A3 = 57,
    B3 = 59;
  const C4 = 60,
    D4 = 62,
    E4 = 64,
    F4 = 65,
    G4 = 67,
    A4 = 69,
    B4 = 71;
  const C5 = 72,
    D5 = 74,
    E5 = 76,
    F5 = 77,
    G5 = 79,
    A5 = 81;

  // Bass ostinato (16 steps × 4 = one "phrase" repeated with variations)
  function buildBass() {
    const phrase = [
      C2, 0, C2, 0, G2, 0, G2, 0, A2, 0, A2, 0, F2, 0, G2, 0,
    ];
    const phrase2 = [
      C2, 0, E2, 0, F2, 0, F2, 0, G2, 0, G2, 0, A2, G2, F2, E2,
    ];
    const out = [];
    for (let bar = 0; bar < BARS; bar++) {
      const p = bar % 4 === 3 ? phrase2 : phrase;
      for (let s = 0; s < 16; s++) out.push(p[s]);
    }
    return out;
  }

  // Lead — original catchy hook (not a known commercial melody)
  function buildLead() {
    // 2-bar hooks
    const a = [
      E4, 0, G4, 0, C5, 0, B4, 0, A4, 0, G4, 0, E4, 0, D4, 0,
      C4, 0, E4, 0, G4, 0, A4, 0, G4, 0, E4, 0, D4, E4, 0, 0,
    ];
    const b = [
      A4, 0, G4, 0, E4, 0, C4, 0, D4, 0, E4, 0, G4, 0, 0, 0,
      F4, 0, E4, 0, D4, 0, C4, 0, D4, 0, E4, D4, C4, 0, 0, 0,
    ];
    const c = [
      G4, 0, A4, 0, C5, 0, D5, 0, C5, 0, A4, 0, G4, E4, 0, 0,
      A4, 0, G4, 0, F4, 0, E4, 0, D4, 0, E4, 0, C4, 0, 0, 0,
    ];
    const out = [];
    const blocks = [a, a, b, b, a, c, b, a];
    for (let i = 0; i < BARS / 2; i++) {
      const blk = blocks[i % blocks.length];
      for (let s = 0; s < 32; s++) out.push(blk[s]);
    }
    // pad to TOTAL_STEPS
    while (out.length < TOTAL_STEPS) out.push(0);
    return out.slice(0, TOTAL_STEPS);
  }

  // Harmony blips
  function buildHarmony() {
    const out = new Array(TOTAL_STEPS).fill(0);
    for (let i = 0; i < TOTAL_STEPS; i++) {
      if (i % 8 === 4) out[i] = [E4, G4, A4, C5][(i >> 4) % 4];
      if (i % 16 === 12) out[i] = G4;
    }
    return out;
  }

  // Drums: 1 = kick, 2 = hat, 3 = snare
  function buildDrums() {
    const out = [];
    for (let bar = 0; bar < BARS; bar++) {
      for (let s = 0; s < 16; s++) {
        let d = 0;
        if (s % 4 === 0) d = 1; // kick
        if (s % 4 === 2) d = 3; // snare
        if (s % 2 === 1) d = d || 2; // hat
        if (bar % 4 === 3 && s === 14) d = 3; // fill
        out.push(d);
      }
    }
    return out;
  }

  const PAT = {
    bass: buildBass(),
    lead: buildLead(),
    harm: buildHarmony(),
    drums: buildDrums(),
  };

  function ChipEngine() {
    this.ctx = null;
    this.master = null;
    this.playing = false;
    this.loop = true;
    this.step = 0;
    this.nextNoteTime = 0;
    this.timer = null;
    this.startedAt = 0;
    this.pausedAt = 0;
    this.volume = 0.7;
    this.onStep = null;
    this.analyser = null;
  }

  ChipEngine.prototype._ensure = function () {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume * 0.35;
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 64;
    this.master.connect(this.analyser);
    this.analyser.connect(this.ctx.destination);
  };

  ChipEngine.prototype.setVolume = function (v) {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.master) this.master.gain.value = this.volume * 0.35;
  };

  ChipEngine.prototype.duration = function () {
    return TOTAL_STEPS * STEP_DUR;
  };

  ChipEngine.prototype.currentTime = function () {
    if (!this.ctx) return 0;
    if (!this.playing) return this.pausedAt;
    const t = (this.step / TOTAL_STEPS) * this.duration();
    return Math.min(t, this.duration());
  };

  ChipEngine.prototype._sq = function (freq, t0, dur, gain, type) {
    if (!freq || freq < 20) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type || 'square';
    o.frequency.setValueAtTime(freq, t0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.master);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  };

  ChipEngine.prototype._noise = function (t0, dur, gain, kind) {
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      data[i] = (Math.random() * 2 - 1) * (kind === 'kick' ? Math.exp(-i / (len * 0.15)) : Math.exp(-i / (len * 0.4)));
    }
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const g = this.ctx.createGain();
    const f = this.ctx.createBiquadFilter();
    if (kind === 'kick') {
      f.type = 'lowpass';
      f.frequency.value = 120;
      g.gain.value = gain * 1.4;
    } else if (kind === 'snare') {
      f.type = 'highpass';
      f.frequency.value = 1200;
      g.gain.value = gain * 0.7;
    } else {
      f.type = 'highpass';
      f.frequency.value = 6000;
      g.gain.value = gain * 0.25;
    }
    src.connect(f);
    f.connect(g);
    g.connect(this.master);
    src.start(t0);
  };

  ChipEngine.prototype._scheduleStep = function (step, t0) {
    const i = step % TOTAL_STEPS;
    const bass = PAT.bass[i];
    const lead = PAT.lead[i];
    const harm = PAT.harm[i];
    const drum = PAT.drums[i];

    if (bass) this._sq(midi(bass), t0, STEP_DUR * 0.9, 0.22, 'triangle');
    if (lead) this._sq(midi(lead), t0, STEP_DUR * 0.7, 0.12, 'square');
    if (harm) this._sq(midi(harm), t0, STEP_DUR * 0.5, 0.06, 'square');

    if (drum === 1) this._noise(t0, 0.08, 0.5, 'kick');
    if (drum === 2) this._noise(t0, 0.03, 0.25, 'hat');
    if (drum === 3) this._noise(t0, 0.1, 0.4, 'snare');

    if (this.onStep) this.onStep(i, TOTAL_STEPS);
  };

  ChipEngine.prototype._scheduler = function () {
    if (!this.playing) return;
    const look = 0.12;
    while (this.nextNoteTime < this.ctx.currentTime + look) {
      this._scheduleStep(this.step, this.nextNoteTime);
      this.nextNoteTime += STEP_DUR;
      this.step++;
      if (this.step >= TOTAL_STEPS) {
        if (this.loop) {
          this.step = 0;
        } else {
          this.stop();
          return;
        }
      }
    }
    this.timer = setTimeout(() => this._scheduler(), 25);
  };

  ChipEngine.prototype.play = async function () {
    this._ensure();
    if (this.ctx.state === 'suspended') await this.ctx.resume();
    if (this.playing) return;
    this.playing = true;
    this.nextNoteTime = this.ctx.currentTime + 0.05;
    this._scheduler();
  };

  ChipEngine.prototype.pause = function () {
    if (!this.playing) return;
    this.playing = false;
    this.pausedAt = this.currentTime();
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  };

  ChipEngine.prototype.stop = function () {
    this.playing = false;
    this.step = 0;
    this.pausedAt = 0;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    if (this.onStep) this.onStep(0, TOTAL_STEPS);
  };

  ChipEngine.prototype.seekRatio = function (r) {
    r = Math.max(0, Math.min(1, r));
    this.step = Math.floor(r * TOTAL_STEPS);
    this.pausedAt = r * this.duration();
    if (this.playing) {
      this.nextNoteTime = this.ctx.currentTime + 0.05;
    }
  };

  ChipEngine.prototype.getAnalyser = function () {
    this._ensure();
    return this.analyser;
  };

  global.PixelNoobChip = {
    ChipEngine: ChipEngine,
    TOTAL_STEPS: TOTAL_STEPS,
    duration: TOTAL_STEPS * STEP_DUR,
    title: 'Living Life (Pixel Noob Chip)',
    artist: 'Original chiptune · not the HALO recording',
  };
})(window);
