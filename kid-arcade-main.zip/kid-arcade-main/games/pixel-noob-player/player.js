/**
 * Pixel shell + YouTube IFrame API
 * Plays the real Noob Song: https://www.youtube.com/watch?v=8K2XQ-iwsF0
 */
(function () {
  'use strict';

  const VIDEO_ID = window.NOOB_VIDEO_ID || '8K2XQ-iwsF0';

  const el = {
    play: document.getElementById('btn-play'),
    stop: document.getElementById('btn-stop'),
    prev: document.getElementById('btn-prev'),
    mute: document.getElementById('btn-mute'),
    vol: document.getElementById('vol'),
    fill: document.getElementById('fill'),
    knob: document.getElementById('knob'),
    progress: document.getElementById('progress'),
    t0: document.getElementById('t0'),
    t1: document.getElementById('t1'),
    wrap: document.getElementById('yt-wrap'),
  };

  let player = null;
  let ready = false;
  let tickTimer = null;
  let seeking = false;

  function fmt(s) {
    if (!isFinite(s) || s < 0) return '0:00';
    s = Math.floor(s);
    const m = Math.floor(s / 60);
    const ss = String(s % 60).padStart(2, '0');
    return m + ':' + ss;
  }

  function setPlayingUI(on) {
    el.play.textContent = on ? '❚❚' : '▶';
    el.play.classList.toggle('on', !!on);
  }

  function updateProgress() {
    if (!player || !ready || seeking) return;
    const t = player.getCurrentTime() || 0;
    const d = player.getDuration() || 0;
    el.t0.textContent = fmt(t);
    if (d > 0) {
      el.t1.textContent = fmt(d);
      const r = Math.min(1, t / d);
      el.fill.style.width = r * 100 + '%';
      el.knob.style.left = r * 100 + '%';
    }
    const st = player.getPlayerState();
    setPlayingUI(st === YT.PlayerState.PLAYING);
  }

  function startTick() {
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = setInterval(updateProgress, 250);
  }

  // YouTube API global callback
  window.onYouTubeIframeAPIReady = function () {
    el.wrap.classList.add('loading');
    player = new YT.Player('player', {
      videoId: VIDEO_ID,
      width: '100%',
      height: '100%',
      playerVars: {
        autoplay: 0,
        controls: 1,
        rel: 0,
        modestbranding: 1,
        playsinline: 1,
        fs: 1,
        origin: location.origin,
      },
      events: {
        onReady: function (e) {
          ready = true;
          el.wrap.classList.remove('loading');
          try {
            e.target.setVolume(+el.vol.value);
          } catch (_) {}
          const d = e.target.getDuration();
          if (d) el.t1.textContent = fmt(d);
          startTick();
          // enable buttons
          [el.play, el.stop, el.prev, el.mute].forEach((b) => {
            if (b) b.disabled = false;
          });
        },
        onStateChange: function (e) {
          setPlayingUI(e.data === YT.PlayerState.PLAYING);
          if (e.data === YT.PlayerState.ENDED) {
            setPlayingUI(false);
            el.fill.style.width = '100%';
          }
        },
        onError: function () {
          el.wrap.classList.remove('loading');
          alert(
            'Could not load YouTube video. Open it directly:\nhttps://www.youtube.com/watch?v=' +
              VIDEO_ID
          );
        },
      },
    });
  };

  // If API already loaded
  if (window.YT && window.YT.Player) {
    window.onYouTubeIframeAPIReady();
  }

  el.play.addEventListener('click', function () {
    if (!player || !ready) return;
    const st = player.getPlayerState();
    if (st === YT.PlayerState.PLAYING) {
      player.pauseVideo();
      setPlayingUI(false);
    } else {
      player.playVideo();
      setPlayingUI(true);
    }
  });

  el.stop.addEventListener('click', function () {
    if (!player || !ready) return;
    player.stopVideo();
    player.seekTo(0, true);
    setPlayingUI(false);
    el.fill.style.width = '0%';
    el.knob.style.left = '0%';
    el.t0.textContent = '0:00';
  });

  el.prev.addEventListener('click', function () {
    if (!player || !ready) return;
    player.seekTo(0, true);
    player.playVideo();
    setPlayingUI(true);
  });

  el.vol.addEventListener('input', function () {
    if (!player || !ready) return;
    player.setVolume(+el.vol.value);
    if (+el.vol.value > 0) {
      player.unMute();
      el.mute.classList.remove('on');
      el.mute.textContent = 'MUTE';
    }
  });

  el.mute.addEventListener('click', function () {
    if (!player || !ready) return;
    if (player.isMuted()) {
      player.unMute();
      el.mute.classList.remove('on');
      el.mute.textContent = 'MUTE';
    } else {
      player.mute();
      el.mute.classList.add('on');
      el.mute.textContent = 'UNMUTE';
    }
  });

  el.progress.addEventListener('click', function (e) {
    if (!player || !ready) return;
    const d = player.getDuration();
    if (!d) return;
    const r = el.progress.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    seeking = true;
    player.seekTo(ratio * d, true);
    el.fill.style.width = ratio * 100 + '%';
    el.knob.style.left = ratio * 100 + '%';
    el.t0.textContent = fmt(ratio * d);
    setTimeout(function () {
      seeking = false;
    }, 300);
  });

  // Disable until ready
  [el.play, el.stop, el.prev, el.mute].forEach(function (b) {
    if (b) b.disabled = true;
  });
})();
