# CITY//COLLAPSE — AI Horror (3D)


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

First-person 3D horror: wake in a city apartment, watch AI destroy the skyline, run through lobby chaos, hide under the bed while bots steal your weird Google searches for the AI boss — then you survive alone.

## Play

```bash
cd projects/creative-visualizers-and-games/ai-city-collapse
python3 -m http.server 8771
```

Open **http://127.0.0.1:8771/**

## Controls

| | |
|--|--|
| WASD | Move |
| Mouse | Look |
| **Shift** | Sprint (**no cooldown**) |
| **E** | Interact |

## Story

1. Wake in bedroom → **E** on window → city burning under AI beams  
2. Go downstairs (stairs / walk down)  
3. Lobby: bodies, runners, **AI bots with lasers**  
4. Sprint back upstairs → **E** on bed → hide  
5. Bots steal Google weird searches → show AI boss  
6. Bots leave → **only you** → you survived  

Caught = pixel blood + AAAA-style splat → respawn and try again.
