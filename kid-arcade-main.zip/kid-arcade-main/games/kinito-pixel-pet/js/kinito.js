/**
 * Kinito Pixel Pet — egg hatch, greet, peek at apps/files/Desk Chonks
 * Inspired by KinitoPET · not affiliated · local toy
 */
(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const landing = $('#landing');
  const desk = $('#desk');
  const btnDl = $('#btn-download');
  const dlStatus = $('#dl-status');
  const logoEgg = $('#logo-egg');
  const petCanvas = $('#pet');
  const pctx = petCanvas.getContext('2d');
  const bubble = $('#bubble');
  const panel = $('#panel');
  const panelTitle = $('#panel-title');
  const panelCaption = $('#panel-caption');
  const panelList = $('#panel-list');
  const animCanvas = $('#anim');
  const actx = animCanvas.getContext('2d');
  const petRoot = $('#pet-root');

  pctx.imageSmoothingEnabled = false;
  actx.imageSmoothingEnabled = false;

  // palette
  const C = {
    outline: '#1a1030',
    body: '#5b8cff',
    bodyD: '#3a60c0',
    belly: '#c8dcff',
    eye: '#1a1030',
    shine: '#ffffff',
    cheek: '#ff8ab8',
    egg: '#f5e6c8',
    eggD: '#d4b878',
    eggS: '#fff8e8',
    crack: '#1a1030',
    pink: '#ff6bcb',
  };

  let mode = 'idle'; // idle | look | talk | hatch | files | apps | chonks
  let frame = 0;
  let speakUntil = 0;
  let hatched = false;
  let lookTarget = null; // {x,y} for eye dir -1..1

  function px(ctx, x, y, w, h, col) {
    ctx.fillStyle = col;
    ctx.fillRect(x, y, w, h);
  }

  function drawEgg(ctx, s, cracked) {
    // s = scale unit (1 = 1px in 64 grid, we draw on 128)
    const o = 32;
    // shell
    px(ctx, o + 12, o + 8, 40, 48, C.egg);
    px(ctx, o + 16, o + 4, 32, 8, C.egg);
    px(ctx, o + 20, o + 56, 24, 4, C.eggD);
    px(ctx, o + 14, o + 16, 8, 8, C.eggS);
    px(ctx, o + 18, o + 12, 6, 4, C.eggS);
    // spots
    px(ctx, o + 36, o + 20, 6, 6, C.eggD);
    px(ctx, o + 24, o + 36, 8, 6, C.eggD);
    if (cracked > 0) {
      px(ctx, o + 28, o + 20, 2, 20, C.crack);
      px(ctx, o + 26, o + 30, 8, 2, C.crack);
      px(ctx, o + 34, o + 24, 6, 2, C.crack);
    }
    if (cracked > 1) {
      // split
      px(ctx, o + 8, o + 40, 20, 16, C.eggD);
      px(ctx, o + 36, o + 42, 18, 14, C.eggD);
    }
  }

  function drawKinito(ctx, anim) {
    // 128 canvas, character ~ centered
    const ox = 32;
    const oy = 28 + (anim.bob || 0);
    const ex = anim.eyeX || 0; // -2..2
    const ey = anim.eyeY || 0;

    // shadow
    px(ctx, ox + 16, 108, 48, 6, '#00000033');

    // body
    px(ctx, ox + 14, oy + 28, 52, 40, C.body);
    px(ctx, ox + 18, oy + 24, 44, 8, C.body);
    px(ctx, ox + 18, oy + 64, 44, 6, C.bodyD);
    // belly
    px(ctx, ox + 26, oy + 40, 28, 22, C.belly);
    // antenna
    px(ctx, ox + 36, oy + 4, 4, 14, C.bodyD);
    px(ctx, ox + 32, oy + 0, 12, 10, C.pink);
    px(ctx, ox + 36, oy + 2, 4, 4, C.shine);
    // ears / side nubs
    px(ctx, ox + 8, oy + 32, 8, 14, C.body);
    px(ctx, ox + 64, oy + 32, 8, 14, C.body);
    // face plate
    px(ctx, ox + 22, oy + 30, 36, 28, C.belly);
    // eyes
    const eox = ox + 28 + ex;
    const eoy = oy + 36 + ey;
    px(ctx, eox, eoy, 8, 10, C.eye);
    px(ctx, eox + 18, eoy, 8, 10, C.eye);
    if (!anim.blink) {
      px(ctx, eox + 2, eoy + 2, 3, 3, C.shine);
      px(ctx, eox + 20, eoy + 2, 3, 3, C.shine);
    } else {
      px(ctx, eox, eoy + 4, 8, 3, C.eye);
      px(ctx, eox + 18, eoy + 4, 8, 3, C.eye);
    }
    // cheeks
    px(ctx, ox + 24, oy + 48, 6, 4, C.cheek);
    px(ctx, ox + 50, oy + 48, 6, 4, C.cheek);
    // mouth
    if (anim.talk) {
      px(ctx, ox + 36, oy + 52, 10, 6, C.eye);
      px(ctx, ox + 38, oy + 54, 6, 2, C.pink);
    } else {
      px(ctx, ox + 36, oy + 52, 10, 3, C.eye);
    }
    // arms
    const arm = anim.wave ? -4 : 0;
    px(ctx, ox + 6, oy + 44 + arm, 10, 8, C.body);
    px(ctx, ox + 64, oy + 44 - arm, 10, 8, C.body);
    // feet
    px(ctx, ox + 24, oy + 70, 12, 8, C.bodyD);
    px(ctx, ox + 44, oy + 70, 12, 8, C.bodyD);
  }

  function drawMini(ctx, kind, t) {
    ctx.clearRect(0, 0, 96, 96);
    ctx.fillStyle = '#120828';
    ctx.fillRect(0, 0, 96, 96);
    const bob = Math.sin(t * 0.01) * 2 | 0;
    if (kind === 'files') {
      // folder bounce
      px(ctx, 28, 40 + bob, 40, 28, '#e0c060');
      px(ctx, 28, 34 + bob, 18, 8, '#e0c060');
      px(ctx, 34, 48 + bob, 28, 4, '#1a1030');
      px(ctx, 34, 56 + bob, 20, 4, '#1a1030');
      // kinito peek
      px(ctx, 60, 20 + bob, 20, 18, C.body);
      px(ctx, 64, 24 + bob, 4, 5, C.eye);
      px(ctx, 72, 24 + bob, 4, 5, C.eye);
    } else if (kind === 'apps') {
      // window icons
      const cols = ['#ff6bcb', '#5ef0e0', '#ffd86b', '#8af'];
      for (let i = 0; i < 4; i++) {
        const x = 18 + (i % 2) * 32;
        const y = 22 + ((i / 2) | 0) * 32 + bob;
        px(ctx, x, y, 24, 24, cols[i]);
        px(ctx, x + 4, y + 4, 16, 3, '#1a1030');
      }
    } else if (kind === 'chonks') {
      // chunky pig-ish
      px(ctx, 28, 36 + bob, 40, 28, '#ffb0d0');
      px(ctx, 24, 40 + bob, 8, 12, '#ffb0d0');
      px(ctx, 64, 40 + bob, 8, 12, '#ffb0d0');
      px(ctx, 36, 44 + bob, 6, 6, C.eye);
      px(ctx, 52, 44 + bob, 6, 6, C.eye);
      px(ctx, 42, 54 + bob, 12, 6, '#ff80b0');
      px(ctx, 40, 28 + bob, 6, 10, '#ffb0d0');
      px(ctx, 50, 28 + bob, 6, 10, '#ffb0d0');
    } else {
      drawKinito(ctx, { bob, eyeX: Math.sin(t * 0.005) * 2 | 0, talk: true });
    }
  }

  function say(text, ms) {
    bubble.textContent = text;
    bubble.classList.remove('hidden');
    speakUntil = performance.now() + (ms || 3500);
    mode = 'talk';
  }

  function renderPet(t) {
    pctx.clearRect(0, 0, 128, 128);
    frame++;
    const blink = frame % 90 < 4;
    const bob = Math.sin(t * 0.005) * 2 | 0;
    const talk = performance.now() < speakUntil && frame % 8 < 4;

    if (!hatched) {
      const phase = hatchPhase;
      if (phase < 1) drawEgg(pctx, 1, 0);
      else if (phase < 2) drawEgg(pctx, 1, 1);
      else if (phase < 3) {
        drawEgg(pctx, 1, 2);
        // peeping
        px(pctx, 52, 48, 24, 20, C.body);
        px(pctx, 56, 54, 5, 6, C.eye);
        px(pctx, 66, 54, 5, 6, C.eye);
      } else {
        hatched = true;
        mode = 'talk';
        say('Hello! I am Kinito!', 4500);
      }
      return;
    }

    let eyeX = 0;
    let eyeY = 0;
    if (lookTarget) {
      eyeX = Math.round(lookTarget.x * 2);
      eyeY = Math.round(lookTarget.y * 2);
    } else if (mode === 'look' || mode === 'files' || mode === 'apps' || mode === 'chonks') {
      eyeX = Math.sin(t * 0.004) * 2 | 0;
      eyeY = Math.cos(t * 0.003) * 1 | 0;
    }

    drawKinito(pctx, {
      bob,
      blink: blink && !talk,
      talk: talk,
      eyeX,
      eyeY,
      wave: mode === 'talk' || mode === 'chonks',
    });

    if (performance.now() > speakUntil && mode === 'talk') {
      mode = 'idle';
      bubble.classList.add('hidden');
    }

    // panel mini anim
    if (!panel.classList.contains('hidden')) {
      const kind = mode === 'files' || mode === 'apps' || mode === 'chonks' ? mode : 'idle';
      drawMini(actx, kind, t);
    }
  }

  let hatchPhase = 0;
  let hatchTimer = null;

  function startHatch() {
    hatchPhase = 0;
    hatched = false;
    const step = () => {
      hatchPhase++;
      if (hatchPhase === 1) say('…', 800);
      if (hatchPhase === 2) say('crick…', 900);
      if (hatchPhase === 3) say('Hello! I am Kinito!', 4500);
      if (hatchPhase < 4) hatchTimer = setTimeout(step, 900);
    };
    hatchTimer = setTimeout(step, 600);
  }

  // download sequence
  btnDl.addEventListener('click', async () => {
    btnDl.disabled = true;
    const steps = [
      'Connecting to Job Corp servers… just kidding',
      'Downloading kinito_pixel.pet…',
      'Installing onto your screen…',
      'Almost there…',
    ];
    for (const s of steps) {
      dlStatus.textContent = s;
      logoEgg.textContent = s.includes('Install') ? '💾' : '🥚';
      await new Promise((r) => setTimeout(r, 550));
    }
    dlStatus.textContent = 'Done! Hatch time…';
    await new Promise((r) => setTimeout(r, 400));
    landing.classList.add('hidden');
    desk.classList.remove('hidden');
    startHatch();
  });

  // drag pet
  let drag = null;
  petRoot.addEventListener('pointerdown', (e) => {
    if (e.target.closest('#pet-bar')) return;
    drag = {
      ox: e.clientX - petRoot.offsetLeft,
      oy: e.clientY - petRoot.offsetTop,
    };
    petRoot.setPointerCapture(e.pointerId);
  });
  petRoot.addEventListener('pointermove', (e) => {
    if (!drag) return;
    petRoot.style.left = e.clientX - drag.ox + 'px';
    petRoot.style.top = e.clientY - drag.oy + 'px';
    petRoot.style.right = 'auto';
    petRoot.style.bottom = 'auto';
  });
  petRoot.addEventListener('pointerup', () => { drag = null; });

  // mouse look — eyes follow cursor when idle
  window.addEventListener('mousemove', (e) => {
    if (!hatched) return;
    const r = petCanvas.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    lookTarget = {
      x: clamp((e.clientX - cx) / 80, -1, 1),
      y: clamp((e.clientY - cy) / 80, -1, 1),
    };
  });
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  async function api(path) {
    const r = await fetch(path);
    if (!r.ok) throw new Error('server ' + r.status);
    return r.json();
  }

  function showPanel(title, caption, items, modeName) {
    mode = modeName;
    panel.classList.remove('hidden');
    panelTitle.textContent = title;
    panelCaption.textContent = caption;
    panelList.innerHTML = items.map((it) => {
      if (typeof it === 'string') return `<li>${esc(it)}</li>`;
      return `<li class="${it.cls || ''}">${esc(it.text)}</li>`;
    }).join('');
  }
  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  $('#btn-look').addEventListener('click', () => {
    mode = 'look';
    say('I see you! 👀', 2500);
  });

  $('#btn-files').addEventListener('click', async () => {
    say('Looking at your files…', 2000);
    mode = 'files';
    try {
      const d = await api('/api/files');
      const items = [];
      for (const [folder, list] of Object.entries(d.folders || {})) {
        items.push({ text: '— ' + folder + ' —', cls: 'app' });
        (list || []).slice(0, 8).forEach((name) => items.push({ text: name }));
      }
      const n = items.length;
      showPanel(
        'Kinito · files',
        n ? 'Ooh, so many treasures on disk!' : 'Hmm, quiet folders…',
        items.length ? items : ['No files visible (start with python3 serve.py)'],
        'files'
      );
      say(n ? 'I peeked at Desktop, Documents, Downloads…' : 'I need the local server to peek!', 4000);
    } catch (e) {
      showPanel('Kinito · files', 'I can’t see files without my helper.', [
        { text: 'Run: python3 serve.py', cls: 'err' },
        { text: String(e.message || e), cls: 'err' },
      ], 'files');
      say('Psst… start serve.py so I can look around!', 4000);
    }
  });

  $('#btn-apps').addEventListener('click', async () => {
    say('Checking open apps…', 2000);
    mode = 'apps';
    try {
      const d = await api('/api/apps');
      const apps = d.apps || [];
      const items = apps.slice(0, 24).map((a) => ({ text: '💻 ' + a, cls: 'app' }));
      if (d.deskChonks && d.deskChonks.running) {
        items.unshift({ text: '🐷 Desk Chonks is OPEN!', cls: 'chonk' });
      }
      showPanel(
        'Kinito · apps',
        apps.length ? `You have ${apps.length} things open!` : 'Hmm… quiet desktop?',
        items.length ? items : ['(no apps listed)'],
        'apps'
      );
      say(apps.length ? 'Busy busy! Lots of apps!' : 'Start serve.py for full app vision!', 3500);
    } catch (e) {
      showPanel('Kinito · apps', 'App vision offline.', [
        { text: 'Run: python3 serve.py', cls: 'err' },
      ], 'apps');
      say('I need serve.py to see your apps!', 3500);
    }
  });

  $('#btn-chonks').addEventListener('click', async () => {
    say('Searching for Desk Chonks…', 2000);
    mode = 'chonks';
    try {
      const d = await api('/api/chonks');
      if (d.running) {
        showPanel(
          'Kinito · Desk Chonks',
          'I FOUND THEM!! Chonky friends on the desk!',
          [
            { text: '🐷 Desk Chonks is running', cls: 'chonk' },
            { text: 'Hello little chonks!!', cls: 'chonk' },
            { text: d.hint || '', cls: 'chonk' },
          ],
          'chonks'
        );
        say('Hello Desk Chonks!! 🐷✨', 4000);
      } else {
        showPanel(
          'Kinito · Desk Chonks',
          'No chonks on screen… yet.',
          [
            { text: 'Desk Chonks is not open', cls: 'err' },
            { text: 'Open Desk Chonks and ask me again!' },
            { text: d.hint || '' },
          ],
          'chonks'
        );
        say('Open Desk Chonks and I’ll say hi!', 3500);
      }
    } catch (e) {
      showPanel('Kinito · Desk Chonks', 'Can’t check right now.', [
        { text: 'Run: python3 serve.py', cls: 'err' },
      ], 'chonks');
      say('Serve.py helps me find the chonks!', 3500);
    }
  });

  $('#btn-close').addEventListener('click', () => {
    say('Bye for now! Refresh to hatch me again.', 3000);
    setTimeout(() => {
      desk.classList.add('hidden');
      landing.classList.remove('hidden');
      btnDl.disabled = false;
      dlStatus.textContent = '';
      logoEgg.textContent = '🥚';
      hatched = false;
      hatchPhase = 0;
      panel.classList.add('hidden');
      bubble.classList.add('hidden');
    }, 1200);
  });

  $('#panel-x').addEventListener('click', () => {
    panel.classList.add('hidden');
    mode = 'idle';
  });

  function loop(t) {
    renderPet(t);
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  // optional: status ping
  fetch('/api/status').then((r) => r.json()).then(() => {
    dlStatus.textContent = 'Helper online · ready to download';
  }).catch(() => {
    dlStatus.textContent = 'Tip: python3 serve.py for apps/files/chonks';
  });
})();
