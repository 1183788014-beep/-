# Kinito Pixel Pet


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

Pixel desktop-pet toy **inspired by KinitoPET** (not affiliated).

1. Open in Safari → **DOWNLOAD**
2. Egg lands on the “desktop” and hatches  
3. **Hello! I am Kinito!**  
4. Buttons: look · files · apps · Desk Chonks  

```bash
cd projects/creative-visualizers-and-games/kinito-pixel-pet
python3 serve.py
```

http://127.0.0.1:8782/

`serve.py` lists **top-level** Desktop/Documents/Downloads/Arkhē_Grok names and open app names, and checks if **Desk Chonks** is running. No deep file reading.
