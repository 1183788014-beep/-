/**
 * Bloxy Multiplayer client — classic Roblox *vibe*, own implementation.
 * Multiplayer via WebSocket to same-origin /ws
 */
import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

const gate = document.getElementById('gate');
const hud = document.getElementById('hud');
const blocker = document.getElementById('blocker');
const canvas = document.getElementById('c');
const authForm = document.getElementById('auth-form');
const authErr = document.getElementById('auth-err');
const authGo = document.getElementById('auth-go');
const statusLine = document.getElementById('status-line');
const chatEl = document.getElementById('chat');
const chatForm = document.getElementById('chat-form');
const chatIn = document.getElementById('chat-in');
const swearWarn = document.getElementById('swear-warn');
const swearWarnBody = document.getElementById('swear-warn-body');
const swearWarnSub = document.getElementById('swear-warn-sub');
const swearWarnOk = document.getElementById('swear-warn-ok');
const jumpscare = document.getElementById('jumpscare');
const jumpscareBan = document.getElementById('jumpscare-ban');
const btnReport = document.getElementById('btn-report');
const reportPanel = document.getElementById('report-panel');
const reportList = document.getElementById('report-list');
const reportCancel = document.getElementById('report-cancel');

let authMode = 'solo'; // public: cosmetic gate → solo (no real accounts)
let ws = null;
let me = null;
let roomName = 'LOBBY';
let others = new Map(); // id -> { mesh, name, label, target }
let jumpAudioCtx = null;
let soloMode = true;

function showSwearWarning(msg, strikes, remaining) {
  if (controls?.isLocked) {
    chatOpen = true; // prevent blocker steal
    controls.unlock();
  }
  if (swearWarnBody) {
    swearWarnBody.textContent =
      msg ||
      'DO NOT SWEAR. IT IS AGAINST OUR RULES. IF YOU SWEAR 2 MORE TIMES, YOU WILL BE BANNED FOR 10 MINUTES. THIS IS SERIOUS.';
  }
  if (swearWarnSub) {
    swearWarnSub.textContent = `Strike ${strikes || 3} / 5 · ${remaining != null ? remaining : '?'} more = BAN`;
  }
  swearWarn?.classList.remove('hidden');
}

function hideSwearWarning() {
  swearWarn?.classList.add('hidden');
  chatOpen = false;
}

swearWarnOk?.addEventListener('click', () => {
  hideSwearWarning();
  setTimeout(() => controls?.lock(), 50);
});

function playJumpScareSound() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    jumpAudioCtx = jumpAudioCtx || new AC();
    const ctx = jumpAudioCtx;
    const t0 = ctx.currentTime;
    // harsh noise blast
    const len = ctx.sampleRate * 0.9;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      d[i] = (Math.random() * 2 - 1) * Math.exp(-i / (len * 0.35));
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.8, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.9);
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.setValueAtTime(800, t0);
    f.frequency.exponentialRampToValueAtTime(120, t0 + 0.5);
    src.connect(f);
    f.connect(g);
    g.connect(ctx.destination);
    src.start(t0);
    // scream-ish square
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(180, t0);
    o.frequency.exponentialRampToValueAtTime(40, t0 + 0.6);
    const g2 = ctx.createGain();
    g2.gain.setValueAtTime(0.25, t0);
    g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.7);
    o.connect(g2);
    g2.connect(ctx.destination);
    o.start(t0);
    o.stop(t0 + 0.75);
  } catch {
    /* ignore */
  }
}

let banRedeemable = false;

function showJumpscareAndBan(secondsLeft, errorMsg, redeemable) {
  hideSwearWarning();
  banRedeemable = !!redeemable;
  if (controls?.isLocked) {
    try {
      controls.unlock();
    } catch {
      /* */
    }
  }
  chatOpen = true;
  hud.classList.add('chat-open');
  jumpscare?.classList.remove('hidden');
  playJumpScareSound();
  const mins = Math.max(1, Math.ceil((secondsLeft || 600) / 60));
  if (jumpscareBan) {
    jumpscareBan.innerHTML = `BANNED — ${mins} MINUTES<br/><span>${esc(
      errorMsg || 'Refresh will not help'
    )}</span><br/><span style="color:#8f8;font-size:0.5em;display:block;margin-top:10px">Type: im sorry  → to undo ban</span>`;
  }
  // Keep connection open for apology. Focus chat after scare.
  setTimeout(() => {
    if (!banRedeemable) return;
    openChatFromBan();
  }, 1200);
}

function openChatFromBan() {
  chatOpen = true;
  hud.classList.add('chat-open');
  blocker?.classList.add('hidden');
  try {
    chatIn.focus({ preventScroll: true });
  } catch {
    chatIn?.focus();
  }
}

function clearBanUI() {
  banRedeemable = false;
  jumpscare?.classList.add('hidden');
  hideSwearWarning();
  chatOpen = false;
  hud.classList.remove('chat-open');
}

function showFalseReportWarning(message) {
  if (controls?.isLocked) {
    chatOpen = true;
    controls.unlock();
  }
  if (swearWarnBody) {
    swearWarnBody.textContent =
      message ||
      "Hey, Don't use the report section unless if someone is being rude. OK?!?!";
  }
  if (swearWarnSub) {
    swearWarnSub.textContent = 'FALSE REPORT';
  }
  const title = document.querySelector('.swear-warn-title');
  if (title) title.textContent = '⚠ HEY!';
  swearWarn?.classList.remove('hidden');
}

function hideReportPanel() {
  reportPanel?.classList.add('hidden');
}

function showReportPanel() {
  if (!reportList || !reportPanel) return;
  if (controls?.isLocked) {
    chatOpen = true;
    controls.unlock();
  }
  const names = [];
  others.forEach((o) => {
    if (o.name) names.push(o.name);
  });
  reportList.innerHTML = '';
  if (!names.length) {
    reportList.innerHTML = '<div class="empty">No other players online to report.</div>';
  } else {
    names.forEach((n) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = 'Report ' + n;
      b.addEventListener('click', () => {
        if (!ws || ws.readyState !== 1) return;
        ws.send(JSON.stringify({ type: 'report', target: n }));
        hideReportPanel();
        addChat('system', `Reporting ${n}…`);
      });
      reportList.appendChild(b);
    });
  }
  reportPanel.classList.remove('hidden');
}

function toggleReportPanel() {
  if (reportPanel?.classList.contains('hidden')) showReportPanel();
  else {
    hideReportPanel();
    chatOpen = false;
    setTimeout(() => controls?.lock(), 40);
  }
}

btnReport?.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  toggleReportPanel();
});
reportCancel?.addEventListener('click', () => {
  hideReportPanel();
  chatOpen = false;
  setTimeout(() => controls?.lock(), 40);
});

// Press R and release → open report section (not while typing in chat)
document.addEventListener(
  'keyup',
  (e) => {
    if (e.code !== 'KeyR' && e.key !== 'r' && e.key !== 'R') return;
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    // don't fire while chatting / in inputs
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || document.activeElement === chatIn) return;
    if (chatOpen && document.activeElement === chatIn) return;
    if (gate && !gate.classList.contains('hidden')) return; // still on login
    e.preventDefault();
    toggleReportPanel();
  },
  true
);

// --- cosmetic gate (public): any name → solo play; password ignored ---
document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((b) => b.classList.remove('on'));
    btn.classList.add('on');
    authMode = btn.dataset.tab || 'solo';
    if (authGo) authGo.textContent = 'Play';
    if (authErr) authErr.textContent = '';
  });
});

if (statusLine) {
  statusLine.textContent = 'Solo ready · sign-in is just for show';
}

function startSolo(username, room) {
  const name = (username || 'Guest' + ((Math.random() * 900 + 100) | 0)).slice(0, 20);
  soloMode = true;
  ws = null;
  roomName = (room || 'LOBBY').slice(0, 16);
  me = {
    id: 'local-' + Date.now().toString(36),
    name,
    x: 0,
    y: 3,
    z: 8,
  };
  startGame();
  document.getElementById('you-name').textContent = me.name;
  document.getElementById('room-tag').textContent = roomName + ' · SOLO';
  updateOnline();
  addChat('system', `Welcome ${me.name} · solo public mode (no server)`);
  addChat('system', '🍰 Explore · chat is local · password was never checked');
  addChat('system', 'WASD move · click to lock mouse · Space jump');
}

authForm.addEventListener('submit', (e) => {
  e.preventDefault();
  if (authErr) authErr.textContent = '';
  const username = document.getElementById('user').value.trim();
  // password intentionally ignored (cosmetic only)
  const room = document.getElementById('room').value.trim() || 'LOBBY';
  try {
    startSolo(username, room);
  } catch (err) {
    if (authErr) authErr.textContent = String(err.message || err);
  }
});

function connectWS(username, password, room) {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const url = `${proto}//${location.host}/ws`;
  statusLine.textContent = 'Connecting…';
  ws = new WebSocket(url);

  ws.onopen = () => {
    ws.send(
      JSON.stringify({
        type: 'join',
        username,
        password,
        room,
      })
    );
  };

  ws.onmessage = (ev) => {
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    handleNet(msg);
  };

  ws.onclose = () => {
    addChat('system', 'Disconnected from server');
    statusLine.textContent = 'Disconnected — refresh to rejoin';
  };

  ws.onerror = () => {
    authErr.textContent = 'WebSocket failed — is serve.py running?';
  };
}

function handleNet(msg) {
  switch (msg.type) {
    case 'error':
      authErr.textContent = msg.error || 'Error';
      if (msg.banned) {
        authErr.textContent = msg.error || 'You are banned.';
      }
      ws?.close();
      break;
    case 'banned':
      if (msg.jumpscare || msg.redeemable) {
        showJumpscareAndBan(msg.secondsLeft, msg.error, msg.redeemable !== false);
        addChat(
          'system',
          'Banned — type im sorry in chat to clear strikes and undo the ban!'
        );
      } else {
        banRedeemable = false;
        authErr.textContent = msg.error || 'Banned.';
        gate.classList.remove('hidden');
        hud.classList.add('hidden');
        jumpscare?.classList.add('hidden');
        try {
          ws?.close();
        } catch {
          /* */
        }
      }
      break;
    case 'ban_hint':
      addChat('system', msg.message || msg.error || 'You are banned. Type: im sorry');
      openChatFromBan();
      break;
    case 'forgiven':
      clearBanUI();
      addChat('system', msg.message || 'Apology accepted. Strikes cleared.');
      setTimeout(() => controls?.lock(), 80);
      break;
    case 'report_result':
      if (msg.falseReport) {
        addChat('system', msg.message || "Hey, Don't use the report section unless if someone is being rude. OK?!?!");
        showFalseReportWarning(msg.message);
      } else if (msg.ok) {
        addChat('system', msg.message || 'Report confirmed.');
      } else {
        addChat('system', msg.message || 'Report failed.');
      }
      hideReportPanel();
      break;
    case 'swear_warning':
      showSwearWarning(msg.message, msg.strikes, msg.remaining);
      addChat(
        'system',
        `⚠ Strike ${msg.strikes}/5 — clean chat or get banned. Type "im sorry" to clear strikes.`
      );
      break;
    case 'filter_notice':
      if (msg.strikes != null) {
        addChat(
          'system',
          `Chat filtered · strikes ${msg.strikes}/5` +
            (msg.strikes >= 3 ? ' · say "im sorry" to reset' : '')
        );
      }
      break;
    case 'welcome':
      me = msg.you;
      roomName = msg.room;
      startGame();
      (msg.players || []).forEach((p) => addOther(p));
      document.getElementById('you-name').textContent = me.name;
      document.getElementById('room-tag').textContent = roomName;
      updateOnline();
      addChat('system', `Welcome ${me.name} · room ${roomName}`);
      addChat('system', '🍰 CAKECATCH: flying cakes — press E to eat!');
      addChat('system', 'Rules: no swearing. 5 strikes = 10 min ban.');
      if (msg.cake) applyCakeState(msg.cake);
      break;
    case 'cake_sync':
      if (msg.state) applyCakeState(msg.state);
      break;
    case 'cake_eaten':
      if (msg.state) applyCakeState(msg.state);
      else if (msg.scores) {
        cakeState.scores = msg.scores;
        updateCakeHud();
      }
      if (msg.eater === me?.name) {
        // small juice
        flashCakeHud();
      }
      break;
    case 'cake_round_end':
      if (msg.state) applyCakeState(msg.state);
      showCakeWinner(msg.winner, msg.scores || {});
      addChat('system', msg.winner?.text || 'CAKECATCH round over!');
      break;
    case 'cake_round_start':
      cakeWinnerEl?.classList.add('hidden');
      if (msg.state) applyCakeState(msg.state);
      addChat('system', msg.message || '🍰 New CAKECATCH round!');
      break;
    case 'eat_result':
      if (!msg.ok && msg.error) {
        // soft miss — don't spam
      }
      break;
    case 'join':
      if (msg.player && msg.player.id !== me?.id) {
        addOther(msg.player);
        addChat('system', `${msg.player.name} joined`);
        updateOnline();
      }
      break;
    case 'leave':
      removeOther(msg.id);
      if (msg.name) addChat('system', `${msg.name} left`);
      updateOnline();
      break;
    case 'state':
      applyOtherState(msg);
      break;
    case 'chat':
      addChat(msg.name || '?', msg.text, !!msg.filtered);
      break;
  }
}

function updateOnline() {
  const n = 1 + others.size;
  document.getElementById('online').textContent = `${n} online`;
}

function addChat(who, text, filtered) {
  const line = document.createElement('div');
  line.className = 'line' + (filtered ? ' filtered' : '');
  if (who === 'system') {
    line.innerHTML = `<i style="color:#aaa">${esc(text)}</i>`;
  } else {
    const badge = filtered ? ' <span class="filt" title="Rephrased for kindness">✨</span>' : '';
    line.innerHTML = `<b>${esc(who)}</b>${badge}: ${esc(text)}`;
  }
  chatEl.appendChild(line);
  while (chatEl.children.length > 40) chatEl.firstChild.remove();
}

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

// --- Three.js world ---
let renderer, scene, camera, controls;
let playerBody; // local visual (optional - first person so mostly hidden)
let velocity = new THREE.Vector3();
let onGround = false;
const keys = {};
let lastSend = 0;
let chatOpen = false;
const clock = new THREE.Clock();
const GRAVITY = 28;
const SPEED = 12;
const JUMP = 10;

// CAKECATCH
const cakeMeshes = new Map(); // id -> Group
let cakeState = { cakes: [], scores: {}, timeLeft: 60, active: true };
let lastEatAt = 0;
const cakeTimerEl = document.getElementById('cake-timer');
const cakeScoreEl = document.getElementById('cake-score');
const cakeLeadEl = document.getElementById('cake-lead');
const cakeWinnerEl = document.getElementById('cake-winner');
const cwTitle = document.getElementById('cw-title');
const cwScores = document.getElementById('cw-scores');

function startGame() {
  gate.classList.add('hidden');
  hud.classList.remove('hidden');
  blocker.classList.remove('hidden');

  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x78b7ff);
  scene.fog = new THREE.Fog(0x78b7ff, 40, 120);

  camera = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 200);
  camera.position.set(me.x, me.y + 1.5, me.z);

  // lights
  const hemi = new THREE.HemisphereLight(0xb1e1ff, 0x88aa55, 0.85);
  scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffffff, 0.9);
  sun.position.set(30, 50, 20);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  scene.add(sun);

  buildWorld();

  // local player collision capsule origin
  playerBody = {
    pos: new THREE.Vector3(me.x, me.y, me.z),
    radius: 0.45,
    height: 2.2,
  };

  controls = new PointerLockControls(camera, document.body);
  scene.add(controls.getObject());
  controls.getObject().position.copy(playerBody.pos);
  controls.getObject().position.y += 1.5;

  blocker.addEventListener('click', () => {
    if (chatOpen) return;
    controls.lock();
  });
  controls.addEventListener('lock', () => {
    chatOpen = false;
    hud.classList.remove('chat-open');
    blocker.classList.add('hidden');
  });
  controls.addEventListener('unlock', () => {
    // If we unlocked for chat, do NOT cover the screen with the click-blocker
    if (chatOpen) {
      blocker.classList.add('hidden');
      return;
    }
    blocker.classList.remove('hidden');
  });

  function closeChat(relock) {
    chatOpen = false;
    hud.classList.remove('chat-open');
    chatIn.value = '';
    chatIn.blur();
    // clear movement keys so we don't keep walking
    for (const k of Object.keys(keys)) keys[k] = false;
    if (relock !== false) {
      // small delay so Safari finishes blur before re-lock
      setTimeout(() => {
        if (!chatOpen) controls?.lock();
      }, 30);
    }
  }

  function openChat(e) {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    if (chatOpen && document.activeElement === chatIn) return;

    chatOpen = true;
    hud.classList.add('chat-open');
    blocker.classList.add('hidden');

    // Unlock mouse so you can type (Safari needs unlock before focus)
    if (controls?.isLocked) {
      controls.unlock();
    }

    // Focus after unlock settles (Safari / pointer-lock)
    const focusIn = () => {
      try {
        chatIn.focus({ preventScroll: true });
      } catch {
        chatIn.focus();
      }
    };
    requestAnimationFrame(() => {
      focusIn();
      setTimeout(focusIn, 50);
      setTimeout(focusIn, 150);
    });
  }

  function isSlashKey(e) {
    // US: key "/" code Slash; some layouts use different key with code Slash
    return (
      e.key === '/' ||
      e.key === '÷' ||
      e.code === 'Slash' ||
      e.code === 'NumpadDivide' ||
      e.keyCode === 191
    );
  }

  // Capture phase on document so it wins over canvas / pointer-lock quirks
  document.addEventListener(
    'keydown',
    (e) => {
      // Ignore if typing in another field
      const tag = (e.target && e.target.tagName) || '';
      const typingElsewhere =
        (tag === 'INPUT' || tag === 'TEXTAREA') && e.target !== chatIn;

      if (typingElsewhere) return;

      // Already in chat box
      if (e.target === chatIn || document.activeElement === chatIn) {
        if (e.key === 'Escape') {
          e.preventDefault();
          closeChat(true);
        }
        // block game movement while chatting
        if (e.key !== 'Enter') {
          // allow normal typing; don't set keys
        }
        return;
      }

      if (isSlashKey(e) && !e.metaKey && !e.ctrlKey && !e.altKey) {
        openChat(e);
        return;
      }

      // T is also common for chat (backup if / is awkward)
      if (
        (e.key === 't' || e.key === 'T' || e.code === 'KeyT') &&
        !e.metaKey &&
        !e.ctrlKey &&
        !e.altKey
      ) {
        openChat(e);
        return;
      }

      if (e.key === 'Enter' && !e.shiftKey) {
        openChat(e);
        return;
      }

      keys[e.code] = true;
    },
    true
  );

  document.addEventListener(
    'keyup',
    (e) => {
      keys[e.code] = false;
    },
    true
  );

  window.addEventListener('resize', onResize);

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatIn.value.trim();
    if (!text) {
      closeChat(true);
      return;
    }
    // Solo / offline: local-only chat (no server)
    if (soloMode || !ws || ws.readyState !== 1) {
      if (text === '/wave' || text === 'wave') addChat('system', 'You wave');
      else addChat(me?.name || 'You', text);
      closeChat(true);
      return;
    }
    if (text === '/wave' || text === 'wave') {
      const p = sendPos();
      ws.send(
        JSON.stringify({
          type: 'state',
          emote: 'wave',
          x: p.x,
          y: p.y,
          z: p.z,
          ry: p.ry,
        })
      );
      addChat('system', 'You wave');
    } else {
      ws.send(JSON.stringify({ type: 'chat', text }));
    }
    closeChat(true);
  });

  chatIn.addEventListener('keydown', (e) => {
    // stop keys from also hitting document movement while focused
    e.stopPropagation();
    if (e.key === 'Escape') {
      e.preventDefault();
      closeChat(true);
    }
  });

  animate();
}

function buildWorld() {
  // baseplate with studs look
  const groundGeo = new THREE.BoxGeometry(80, 1, 80);
  const groundMat = new THREE.MeshLambertMaterial({ color: 0x4b974b });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.position.y = -0.5;
  ground.receiveShadow = true;
  scene.add(ground);

  // stud grid overlay
  const grid = new THREE.GridHelper(80, 40, 0x3a7a3a, 0x3a7a3a);
  grid.position.y = 0.01;
  scene.add(grid);

  // spawn pads
  const padMat = new THREE.MeshLambertMaterial({ color: 0xf5cd30 });
  for (let i = 0; i < 4; i++) {
    const pad = new THREE.Mesh(new THREE.BoxGeometry(4, 0.3, 4), padMat);
    pad.position.set((i % 2) * 10 - 5, 0.15, Math.floor(i / 2) * 10 - 5);
    pad.receiveShadow = true;
    scene.add(pad);
  }

  // classic towers / freebuild chunks
  const brickColors = [0xc4281c, 0x0d69ac, 0xf5cd30, 0x1b2a35, 0xa3a2a5];
  for (let i = 0; i < 18; i++) {
    const w = 2 + (i % 3);
    const h = 2 + (i % 5);
    const d = 2 + ((i * 2) % 3);
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(w, h, d),
      new THREE.MeshLambertMaterial({ color: brickColors[i % brickColors.length] })
    );
    mesh.position.set(
      ((i * 17) % 60) - 30,
      h / 2,
      ((i * 23) % 60) - 30
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
  }

  // kill brick pit
  const kill = new THREE.Mesh(
    new THREE.BoxGeometry(8, 0.4, 8),
    new THREE.MeshLambertMaterial({ color: 0xff0000 })
  );
  kill.position.set(18, 0.2, 18);
  kill.name = 'kill';
  scene.add(kill);

  // simple sky sun disc
  const sunMesh = new THREE.Mesh(
    new THREE.SphereGeometry(4, 16, 16),
    new THREE.MeshBasicMaterial({ color: 0xfff2aa })
  );
  sunMesh.position.set(40, 50, -30);
  scene.add(sunMesh);
}

function makeCakeMesh() {
  const g = new THREE.Group();
  // cake body
  const body = new THREE.Mesh(
    new THREE.CylinderGeometry(0.55, 0.65, 0.5, 12),
    new THREE.MeshLambertMaterial({ color: 0xffb6c8 })
  );
  body.castShadow = true;
  g.add(body);
  // frosting top
  const frost = new THREE.Mesh(
    new THREE.CylinderGeometry(0.58, 0.58, 0.18, 12),
    new THREE.MeshLambertMaterial({ color: 0xfff5fa })
  );
  frost.position.y = 0.3;
  g.add(frost);
  // cherry
  const cherry = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 8, 8),
    new THREE.MeshLambertMaterial({ color: 0xff2244 })
  );
  cherry.position.y = 0.5;
  g.add(cherry);
  // wings
  const wingMat = new THREE.MeshLambertMaterial({
    color: 0xfff8dc,
    side: THREE.DoubleSide,
  });
  const wingL = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 0.45), wingMat);
  wingL.position.set(-0.75, 0.15, 0);
  wingL.rotation.z = 0.35;
  g.add(wingL);
  const wingR = wingL.clone();
  wingR.position.x = 0.75;
  wingR.rotation.z = -0.35;
  g.add(wingR);
  g.userData = { wingL, wingR };
  return g;
}

function applyCakeState(state) {
  if (!state || !scene) return;
  cakeState = {
    cakes: state.cakes || [],
    scores: state.scores || {},
    timeLeft: state.timeLeft ?? cakeState.timeLeft,
    active: state.active !== false,
    intermission: !!state.intermission,
    winner: state.winner || null,
  };
  const ids = new Set(cakeState.cakes.map((c) => c.id));
  // remove gone
  for (const [id, mesh] of cakeMeshes) {
    if (!ids.has(id)) {
      scene.remove(mesh);
      cakeMeshes.delete(id);
    }
  }
  // add / update
  for (const c of cakeState.cakes) {
    let mesh = cakeMeshes.get(c.id);
    if (!mesh) {
      mesh = makeCakeMesh();
      scene.add(mesh);
      cakeMeshes.set(c.id, mesh);
    }
    mesh.position.set(c.x, c.y, c.z);
    mesh.userData.target = new THREE.Vector3(c.x, c.y, c.z);
    mesh.userData.phase = c.phase || 0;
  }
  updateCakeHud();
  if (cakeState.intermission && cakeState.winner) {
    showCakeWinner(cakeState.winner, cakeState.scores);
  } else if (cakeState.active) {
    cakeWinnerEl?.classList.add('hidden');
  }
}

function updateCakeHud() {
  if (cakeTimerEl) cakeTimerEl.textContent = String(cakeState.timeLeft ?? 0);
  const mine = me ? cakeState.scores[me.name] || 0 : 0;
  if (cakeScoreEl) cakeScoreEl.textContent = String(mine);
  // leader
  let bestN = '',
    bestS = -1;
  Object.entries(cakeState.scores || {}).forEach(([n, s]) => {
    if (s > bestS) {
      bestS = s;
      bestN = n;
    }
  });
  if (cakeLeadEl) {
    if (cakeState.intermission) {
      cakeLeadEl.textContent = 'Round over — next soon';
    } else if (bestS > 0) {
      cakeLeadEl.innerHTML = `Leader: <b>${esc(bestN)}</b> (${bestS}) · press <b>E</b> near a cake`;
    } else {
      cakeLeadEl.innerHTML = 'Eat flying cakes — press <b>E</b>';
    }
  }
}

function flashCakeHud() {
  const el = document.getElementById('cake-hud');
  if (!el) return;
  el.style.transform = 'translateX(-50%) scale(1.08)';
  setTimeout(() => {
    el.style.transform = 'translateX(-50%)';
  }, 120);
}

function showCakeWinner(winner, scores) {
  if (!cakeWinnerEl) return;
  cakeWinnerEl.classList.remove('hidden');
  if (cwTitle) cwTitle.textContent = winner?.text || 'Round over!';
  if (cwScores) {
    const rows = Object.entries(scores || {})
      .sort((a, b) => b[1] - a[1])
      .map(([n, s]) => {
        const isMe = me && n === me.name;
        return `<div class="${isMe ? 'me' : ''}">${esc(n)} — ${s} cake${s === 1 ? '' : 's'}</div>`;
      });
    cwScores.innerHTML = rows.join('') || '<div>No scores</div>';
  }
}

function tryEatNearestCake() {
  if (!controls || !ws || ws.readyState !== 1 || !me) return;
  if (chatOpen || !cakeState.active) return;
  const now = performance.now();
  if (now - lastEatAt < 280) return;
  lastEatAt = now;

  const obj = controls.getObject();
  const px = obj.position.x;
  const py = obj.position.y - 0.5;
  const pz = obj.position.z;

  let best = null;
  let bestD = 3.5;
  for (const c of cakeState.cakes || []) {
    const dx = c.x - px;
    const dy = c.y - py;
    const dz = c.z - pz;
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  if (!best) {
    addChat('system', 'No cake close enough — jump near one!');
    return;
  }
  ws.send(
    JSON.stringify({
      type: 'eat',
      cakeId: best.id,
      x: px,
      y: py,
      z: pz,
    })
  );
}

function makeAvatar(colorHex, name) {
  const g = new THREE.Group();
  const col = new THREE.Color(colorHex || '#0d69ac');
  const skin = new THREE.MeshLambertMaterial({ color: 0xf5cd30 }); // classic head
  const torsoM = new THREE.MeshLambertMaterial({ color: col });
  const limbM = new THREE.MeshLambertMaterial({ color: 0x1b2a35 });

  const head = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), skin);
  head.position.y = 2.1;
  head.castShadow = true;
  g.add(head);

  const torso = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 0.6), torsoM);
  torso.position.y = 1.2;
  torso.castShadow = true;
  g.add(torso);

  const legL = new THREE.Mesh(new THREE.BoxGeometry(0.45, 1.1, 0.45), limbM);
  legL.position.set(-0.3, 0.45, 0);
  g.add(legL);
  const legR = legL.clone();
  legR.position.x = 0.3;
  g.add(legR);

  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.1, 0.4), skin);
  armL.position.set(-0.85, 1.2, 0);
  g.add(armL);
  const armR = armL.clone();
  armR.position.x = 0.85;
  g.add(armR);

  // name tag
  const canvas2 = document.createElement('canvas');
  canvas2.width = 256;
  canvas2.height = 64;
  const ctx = canvas2.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.45)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#fff';
  ctx.font = 'bold 28px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText((name || 'Player').slice(0, 16), 128, 42);
  const tex = new THREE.CanvasTexture(canvas2);
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true })
  );
  sprite.scale.set(2.5, 0.6, 1);
  sprite.position.y = 2.9;
  g.add(sprite);

  g.userData = { armL, armR, head };
  return g;
}

function addOther(p) {
  if (!p || others.has(p.id)) return;
  const mesh = makeAvatar(p.color, p.name);
  mesh.position.set(p.x || 0, p.y || 0, p.z || 0);
  scene.add(mesh);
  others.set(p.id, {
    mesh,
    name: p.name,
    target: new THREE.Vector3(p.x || 0, p.y || 0, p.z || 0),
    ry: p.ry || 0,
    emote: '',
  });
}

function removeOther(id) {
  const o = others.get(id);
  if (!o) return;
  scene.remove(o.mesh);
  others.delete(id);
}

function applyOtherState(msg) {
  let o = others.get(msg.id);
  if (!o) {
    // late join state without join packet
    addOther({
      id: msg.id,
      name: 'Player',
      color: '#0d69ac',
      x: msg.x,
      y: msg.y,
      z: msg.z,
    });
    o = others.get(msg.id);
  }
  if (!o) return;
  o.target.set(msg.x, msg.y, msg.z);
  o.ry = msg.ry || 0;
  if (msg.emote) o.emote = msg.emote;
}

function sendPos() {
  const obj = controls.getObject();
  return {
    x: obj.position.x,
    y: obj.position.y - 1.5,
    z: obj.position.z,
    ry: obj.rotation.y,
  };
}

function networkSend(dt) {
  lastSend += dt;
  if (lastSend < 0.05 || !ws || ws.readyState !== 1 || !controls) return;
  lastSend = 0;
  const p = sendPos();
  // yaw from pointer-lock object
  const yaw = controls.getObject().rotation.y;
  ws.send(
    JSON.stringify({
      type: 'state',
      x: p.x,
      y: p.y,
      z: p.z,
      ry: yaw,
    })
  );
}

function onResize() {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(0.05, clock.getDelta());

  if (controls && controls.isLocked && !chatOpen) {
    // movement (disabled while chat is open)
    const forward = new THREE.Vector3();
    const right = new THREE.Vector3();
    controls.getDirection(forward);
    forward.y = 0;
    forward.normalize();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();

    const wish = new THREE.Vector3();
    if (keys['KeyW']) wish.add(forward);
    if (keys['KeyS']) wish.sub(forward);
    if (keys['KeyD']) wish.add(right);
    if (keys['KeyA']) wish.sub(right);
    if (wish.lengthSq() > 0) wish.normalize().multiplyScalar(SPEED);

    velocity.x = wish.x;
    velocity.z = wish.z;
    velocity.y -= GRAVITY * dt;

    const obj = controls.getObject();
    obj.position.x += velocity.x * dt;
    obj.position.z += velocity.z * dt;
    obj.position.y += velocity.y * dt;

    // ground
    const feet = obj.position.y - 1.5;
    if (feet <= 0) {
      obj.position.y = 1.5;
      velocity.y = 0;
      onGround = true;
    } else {
      onGround = false;
    }

    // bounds
    obj.position.x = Math.max(-38, Math.min(38, obj.position.x));
    obj.position.z = Math.max(-38, Math.min(38, obj.position.z));

    // kill brick
    if (
      obj.position.x > 14 &&
      obj.position.x < 22 &&
      obj.position.z > 14 &&
      obj.position.z < 22 &&
      feet < 0.5
    ) {
      obj.position.set(0, 3, 0);
      velocity.set(0, 0, 0);
      addChat('system', 'OOF! Kill brick — respawned');
    }

    if (keys['Space'] && onGround) {
      velocity.y = JUMP;
      onGround = false;
    }

    // E — eat cake (edge: only on key down frame is hard; use eat cooldown in tryEat)
    if (keys['KeyE']) {
      tryEatNearestCake();
      keys['KeyE'] = false; // one-shot
    }

    networkSend(dt);
  } else if (controls) {
    networkSend(dt);
  }

  // interpolate others
  const t = 1 - Math.pow(0.001, dt);
  others.forEach((o) => {
    o.mesh.position.lerp(o.target, Math.min(1, t * 12));
    o.mesh.rotation.y = o.ry;
    // simple arm wave
    if (o.emote === 'wave' && o.mesh.userData.armR) {
      o.mesh.userData.armR.rotation.z = Math.sin(performance.now() * 0.01) * 1.2;
    }
  });

  // animate cakes (wing flap + bob)
  const tnow = performance.now() * 0.001;
  cakeMeshes.forEach((mesh) => {
    if (mesh.userData.target) {
      mesh.position.lerp(mesh.userData.target, Math.min(1, t * 8));
    }
    mesh.position.y += Math.sin(tnow * 3 + (mesh.userData.phase || 0)) * 0.01;
    mesh.rotation.y += dt * 1.5;
    if (mesh.userData.wingL) {
      const flap = Math.sin(tnow * 12) * 0.5;
      mesh.userData.wingL.rotation.z = 0.35 + flap;
      mesh.userData.wingR.rotation.z = -0.35 - flap;
    }
  });

  renderer.render(scene, camera);
}
