# Bloxy Multiplayer (web)

Classic **Roblox-ish** baseplate multiplayer you can play in the **browser** — **real multiplayer** (WebSocket), not bots.

**Not affiliated with Roblox.** Own implementation / inspired-by feel only.

**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

## Run

```bash
cd projects/creative-visualizers-and-games/bloxy-multiplayer
python3 serve.py
```

Open **http://127.0.0.1:8790/**

## Test with TWO accounts (multiplayer)

1. Window A (Safari): **Create account** → e.g. `PlayerA` / password `test1` → room `LOBBY` → Join  
2. Window B (**Private/Incognito** Safari, or second browser): **Create account** → `PlayerB` / `test2` → room `LOBBY` → Join  
3. Click to lock mouse in each · walk around — you should **see the other noob**

Same room code required. Default: `LOBBY`.

Accounts are stored locally in `data/accounts.json` on this Mac (simple password hash — toy auth, not bank security).

## Controls

| Key | Action |
|-----|--------|
| Click | Lock mouse / play |
| WASD | Move |
| Space | Jump |
| Mouse | Look |
| Esc | Unlock mouse |
| Chat box | Talk to room |
| `/wave` | Wave emote |

## Stack

- Client: Three.js (CDN) + PointerLock  
- Server: Python **aiohttp** (HTTP + WebSocket)  
- Sync: position / rotation / join / leave / chat  

No Gemma / Ollama required.
