# BLOXY CLASSIC '08 — Frozen Intent

**Date:** 2026-07-27  
**Audience:** Kid WOW (classic Roblox 2008–2009 feel)  
**Tier:** 0.5 — single-file Three.js + modular polish (Euler physics)  
**Mental model:** **Model 2 — Character Facing + Camera Orbit** (classic third-person Roblox)

## Fantasy

You drop onto a studded baseplate under a bright 2008 sky. Forcefield blinks off.  
You are a blocky R6 Noob. Freebuild bricks, run a killbrick Obby, swing the Linked Sword at dummies, OOF and respawn.  
Not modern Roblox. Not Minecraft. **Plastic, studs, oof, baseplate.**

## Must-ship (first 60s WOW)

1. Instant classic plastic look (studs, sky, baseplate, R6 noob)
2. Forcefield spawn + system chat "Player has joined"
3. Buttery third-person orbit + WASD + jump
4. Hotbar tools: Build / Delete / Paint / Sword
5. Place colorful studded bricks that snap to grid
6. Visible Obby entrance + first jumps
7. Wandering R6 NPCs with chat bubbles
8. Linked Sword swing + hit spark + oof death
9. Respawn at checkpoint / spawn
10. Web Audio place / swing / oof

## Tracks

| Track | Target |
|-------|--------|
| Effect | Kid says "this is like old Roblox" in first minute |
| Mechanism | Model 2 face-move; AABB vs parts; stud grid snap |
| Product | Single openable folder + `python3 -m http.server` |

## Explicit non-goals (this hour)

- Multiplayer networking
- Real Roblox IP / assets / audio rips
- Infinite voxel world
- Rapier character controller
- Avatar editor depth (shirts/pants catalog)

## Provenance

- Inspired-by classic Roblox (2008–9) UX/feel; **own implementation**
- Substrate: Arkhē ONE-SHOT 3D GENESIS + voxel-realm patterns
- No cloned Roblox client code
