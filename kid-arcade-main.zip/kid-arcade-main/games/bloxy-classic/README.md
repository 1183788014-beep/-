# BLOXY CLASSIC '08


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

A kid-wow **classic Roblox 2008–2009** style browser game: studded baseplate, R6 noob, freebuild, killbrick Obby, Linked Sword, OOF.

**Inspired-by** early Roblox feel — **own implementation** (no Roblox client assets, audio rips, or code).

## Play (right now)

```bash
cd projects/creative-visualizers-and-games/bloxy-classic-08
# Serves the game + proxies chat to local Ollama
python3 serve.py
```

Open: **http://127.0.0.1:8768/**

Requires **Ollama** running on this Mac. Default chat brain: **`gemma4-e2b:latest`** (fast).  
Override: `BLOXY_MODEL=mistral:latest python3 serve.py`

Green dot on the chat bar = local model ready.

### Local chat friends (on-device)

| Who | How |
|-----|-----|
| **Buildy** (main) | type normally |
| Builderman | `@builderman hi` |
| Noob_2008 | `@noob what's the obby?` |
| Guest 1337 | `@guest secret?` |
| Telamon | `@telamon build tips` |

## Controls

| Input | Action |
|-------|--------|
| Click | Lock mouse / start |
| WASD | Move (camera-relative) |
| Mouse | Orbit camera (pivot = **head**) |
| Space | Jump |
| 1–4 | Build / Delete / Paint / Sword |
| LMB | Use tool (hold to spray build/paint) |
| RMB | Always delete (user bricks) |
| Scroll / Q E | Brick color |
| `/` or Enter | Open chat → local **Buildy** (Gemma e2b) |
| Esc | Close chat / free cursor |
| R | Reset character (OOF) |

## What's in the world

- **Spawn** forcefield + classic join chat
- **Obby** ahead (yellow stairs, red banner, killbricks, cyan checkpoints, gold finish)
- **House** showcase freebuild
- **Gray freebuild pad** for your towers
- **R6 NPCs** with chat bubbles (sword them — they oof and respawn)
- Hotbar, health, checkpoints, score, Web Audio SFX

## Architecture

| Item | Choice |
|------|--------|
| Tier | 0.5 single-file Three.js r134 |
| Mental model | **Model 2** — Character Facing + Camera Orbit |
| Physics | Euler + AABB + step-up |
| Provenance | Arkhē genesis shell + voxel-realm patterns + classic Roblox UX memory |

See `FROZEN_INTENT.md`.

## Craft notes / negatives fixed in-session

- **Ship-blocker:** `playerAABB` declared `hh` but used `hz` → black play screen every frame (menu still rendered). Fixed to `half`.
- Face yaw inverted (moonwalk) → local +Z face convention
- Checkpoints/win non-collidable → standable
- Place pop-in no longer shrinks AABB
- Obby in default look direction (+Z) with path arrows + banner
- Soft-shadow maps disabled (black-screen risk on some GPUs)
- Design agent palette + critic agent patch order applied

## Agents used

1. Plan/Juice constraint pack (classic 08–09 numbers)
2. Play-logic critic (face, solids, pop AABB, compass)
3. Lead iterate → ship screenshot `qa-ship.png`

## Next tweaks (if more time)

1. Footstep ticks + richer oof sample  
2. More freebuild stamps / starter kits  
3. Sibling local multiplayer (split keyboard)
