# 3AM KNOCK — Verity Horror


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

First-person horror mini-game. You wake at 3:00 AM, answer a knock, sleep, “normal” morning (broken PC + fridge), eat breakfast, the sky breaks into eternal night, then **Verity** (yellow smiling skinwalker) chases you through the neighborhood.

## Play

```bash
cd projects/creative-visualizers-and-games/verity-3am-knock
python3 -m http.server 8770
```

Open **http://127.0.0.1:8770/**

## Controls

| Key | Action |
|-----|--------|
| WASD | Move |
| Mouse | Look |
| **E** | Interact (door, bed, breakfast, PC, fridge) |
| **Shift** | Sprint (stamina bar in chase) |
| R | Restart after win/death (optional) |

## Story beats

1. **3:00 AM** — wake in bedroom  
2. **Knock** — open front door → nobody  
3. **Sleep** — interact with bed  
4. **Morning** — PC broken, fridge broken (you don’t mind)  
5. **Breakfast** — eat → day/night stutters → **night forever**  
6. **Knock again** — open door → **chase**  
7. **Escape** the EXIT GATE at the end of the road → win  
8. **Caught** → pixelated **AAAA** jumpscare → respawn into chase  

## Assets

- `assets/verity-monster-art.jpg` — chase + jumpscare (from verity-1d-line)
- `assets/verity-sphere-art.jpg` — optional bedside prop

## Architecture

| | |
|--|--|
| View | First-person (camera-as-body) |
| Stack | Three.js r134, single HTML |
| Physics | AABB vs house colliders + road bounds |
| Audio | Web Audio knocks, chase pulse, scare |

Inspired-by Verity / ThatMob ARG aesthetics; **own implementation**.
