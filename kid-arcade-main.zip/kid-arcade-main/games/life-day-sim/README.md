# Day Life Sim


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

First-person **one-day life sim** (~**20 real minutes** → 7 AM–7 PM).

## Flow

1. Wake up  
2. Wash face (sink)  
3. Fridge → food  
4. Plate food on table  
5. Sit / eat (`E`)  
6. Drink water  
7. Walk out the **front door** → **street** → **gym** door · work out **20 seconds** on the mat  
8. Walk home the same way → **computer** until **7 PM**  
   - Tasks app  
   - Code with AI  
   - `tmux attach -t tgrok`  
   - Ask tgrok  
9. Alarm → bed → **day complete**

```bash
cd projects/creative-visualizers-and-games/life-day-sim
python3 -m http.server 8780
```

Open http://127.0.0.1:8780/
