/**
 * Day Life Sim — wake → wash → eat → gym → work (computer) → sleep
 * ~20 real minutes from morning to 7pm night.
 */
(function () {
  'use strict';

  // ——— Day clock: 20 real minutes = 7:00 AM → 7:00 PM (12 in-game hours) ———
  const DAY_MS = 20 * 60 * 1000;
  const START_MIN = 7 * 60; // 7:00 AM
  const END_MIN = 19 * 60; // 7:00 PM
  const SPAN_MIN = END_MIN - START_MIN; // 720 minutes in-game over 20 real min

  const TASKS = [
    { id: 'wake', label: 'Wake up (you did!)' },
    { id: 'wash', label: 'Wash face at the sink' },
    { id: 'fridge', label: 'Get food from the fridge' },
    { id: 'plate', label: 'Put food on the plate at the table' },
    { id: 'eat', label: 'Sit & eat (E on chair / plate)' },
    { id: 'water', label: 'Drink water' },
    { id: 'gym', label: 'Walk to the gym (street) & work out 20s' },
    { id: 'home', label: 'Walk home from the gym' },
    { id: 'work', label: 'Work on the computer until 7 PM' },
    { id: 'sleep', label: 'Go to bed when the alarm rings' },
  ];

  const WORK_ITEMS = [
    { id: 'w_tasks', label: 'Open Tasks app & review queue' },
    { id: 'w_code', label: 'Write code with AI assist (Code app)' },
    { id: 'w_tmux', label: 'tmux attach -t tgrok' },
    { id: 'w_ai', label: 'Ask tgrok AI one coding question' },
  ];

  // DOM
  const canvas = document.getElementById('c');
  const clockEl = document.getElementById('clock');
  const phaseEl = document.getElementById('phase');
  const dayBar = document.getElementById('day-bar');
  const realLeft = document.getElementById('real-left');
  const taskList = document.getElementById('task-list');
  const promptEl = document.getElementById('prompt');
  const toastEl = document.getElementById('toast');
  const heldEl = document.getElementById('held');
  const overlay = document.getElementById('overlay');
  const endScreen = document.getElementById('end-screen');
  const btnStart = document.getElementById('btn-start');
  const btnReplay = document.getElementById('btn-replay');
  const computer = document.getElementById('computer');
  const pcClose = document.getElementById('pc-close');
  const pcAlert = document.getElementById('pc-alert');
  const workTasksEl = document.getElementById('work-tasks');
  const workProgress = document.getElementById('work-progress');
  const codeView = document.getElementById('code-view');
  const btnWriteCode = document.getElementById('btn-write-code');
  const codeStatus = document.getElementById('code-status');
  const term = document.getElementById('term');
  const termInput = document.getElementById('term-input');
  const termRun = document.getElementById('term-run');
  const aiLog = document.getElementById('ai-log');
  const aiInput = document.getElementById('ai-input');
  const aiSend = document.getElementById('ai-send');
  const endMsg = document.getElementById('end-msg');

  // Three
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.setClearColor(0x87b0d0, 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x87b0d0, 18, 70);

  const camera = new THREE.PerspectiveCamera(72, 1, 0.06, 120);
  camera.rotation.order = 'YXZ';

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  scene.add(new THREE.HemisphereLight(0xc8e0ff, 0x4a4030, 0.45));
  const sun = new THREE.DirectionalLight(0xfff2dd, 0.75);
  sun.position.set(6, 12, 4);
  scene.add(sun);
  const lamp = new THREE.PointLight(0xffe0b0, 0.6, 14, 2);
  lamp.position.set(0, 2.6, 0);
  scene.add(lamp);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function mat(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function box(w, h, d, c) {
    return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c));
  }

  // ——— player (spawn standing next to bed) ———
  const player = {
    x: -3.0,
    y: 1.55,
    z: -3.8,
    vx: 0,
    vz: 0,
    yaw: Math.PI * 0.5, // face into the room (toward +X / center)
    pitch: 0,
    speed: 6.5,
    radius: 0.22,
  };
  let locked = false;
  let started = false;
  let finished = false;
  // track both KeyboardEvent.code and .key (Safari / layouts)
  const keys = Object.create(null);
  function keyDown(name) {
    if (!name) return false;
    return !!(keys[name] || keys[name.toLowerCase()] || keys[name.toUpperCase()]);
  }
  function wantMove() {
    return (
      keyDown('KeyW') || keyDown('w') || keyDown('ArrowUp') ||
      keyDown('KeyS') || keyDown('s') || keyDown('ArrowDown') ||
      keyDown('KeyA') || keyDown('a') || keyDown('ArrowLeft') ||
      keyDown('KeyD') || keyDown('d') || keyDown('ArrowRight')
    );
  }
  let dayStart = 0;
  let alarmFired = false;

  // inventory / state
  let held = null; // food id
  let foodOnPlate = false;
  let washed = false;
  let ate = false;
  let drank = false;
  let gymProgress = 0; // seconds working out
  let gymDone = false;
  let atGym = false; // room flag via door
  let inHome = true;
  let workDone = {};
  let codeLines = 0;
  let tmuxAttached = false;
  let aiAsked = false;
  let computerOpen = false;
  let taskDone = { wake: true };

  // interactables
  const spots = []; // { id, x, y, z, r, label, mesh? }

  function addSpot(id, x, y, z, r, label) {
    spots.push({ id, x, y, z, r: r || 1.2, label });
  }

  // Visual mesh only (no collision) — walking uses room bounds, not furniture AABBs
  function prop(mesh) {
    scene.add(mesh);
    return mesh;
  }
  function wall(w, h, d, c, x, y, z) {
    const m = box(w, h, d, c);
    m.position.set(x, y, z);
    scene.add(m);
    return m;
  }

  // ——— build rooms: HOME → open door → STREET → open door → GYM (all walkable) ———
  function buildWorld() {
    // HOME floor
    const floor = box(13.5, 0.15, 12, 0xc4a882);
    floor.position.set(-0.25, -0.05, 0);
    scene.add(floor);

    // STREET floor (asphalt + sidewalk strip)
    const street = box(10, 0.12, 18, 0x3a3a42);
    street.position.set(11.5, -0.06, 0);
    scene.add(street);
    const sidewalk = box(10, 0.1, 3.2, 0x9a9aa0);
    sidewalk.position.set(11.5, -0.04, 0);
    scene.add(sidewalk);
    // street markings
    for (let i = 0; i < 5; i++) {
      const line = box(1.2, 0.02, 0.18, 0xf0e080);
      line.position.set(8.5 + i * 1.8, 0.02, 0);
      scene.add(line);
    }
    // trees / posts on street
    for (const [tx, tz] of [[9, 4.5], [12, -5], [15, 5], [10, -4]]) {
      const trunk = box(0.25, 1.8, 0.25, 0x5a3a20);
      trunk.position.set(tx, 0.9, tz);
      scene.add(trunk);
      const leaves = new THREE.Mesh(new THREE.SphereGeometry(0.9, 8, 8), mat(0x2d8a3a));
      leaves.position.set(tx, 2.1, tz);
      scene.add(leaves);
    }

    // HOME walls — east wall has OPEN doorway (gap |z| < 1.15)
    const wallC = 0xece6dc;
    wall(13.5, 3, 0.2, wallC, -0.25, 1.5, -5.9);
    wall(13.5, 3, 0.2, wallC, -0.25, 1.5, 5.9);
    wall(0.2, 3, 12, wallC, -6.9, 1.5, 0);
    // east wall split (doorway at z≈0, width ~2.3)
    wall(0.25, 3, 3.7, wallC, 6.5, 1.5, -3.85);
    wall(0.25, 3, 3.7, wallC, 6.5, 1.5, 3.85);
    // door frame (open — walk through, no E)
    wall(0.12, 2.3, 0.15, 0x5a3a22, 6.5, 1.15, -1.2);
    wall(0.12, 2.3, 0.15, 0x5a3a22, 6.5, 1.15, 1.2);
    wall(0.12, 0.2, 2.5, 0x5a3a22, 6.5, 2.4, 0); // lintel
    // welcome mat in doorway
    const matHome = box(1.0, 0.04, 1.6, 0x4a3040);
    matHome.position.set(6.2, 0.03, 0);
    scene.add(matHome);

    // ceiling home only
    const ceil = box(13.5, 0.1, 12, 0xf5f0e8);
    ceil.position.set(-0.25, 3.05, 0);
    scene.add(ceil);

    // bed (spawn stands beside it at -3, -3.8)
    const bed = box(2.2, 0.4, 1.4, 0x5a7ab0);
    bed.position.set(-4.8, 0.35, -3.8);
    prop(bed);
    const pillow = box(0.6, 0.15, 0.5, 0xf0f0f8);
    pillow.position.set(-5.5, 0.65, -3.8);
    scene.add(pillow);
    addSpot('bed', -4.8, 0.5, -3.8, 1.6, 'Bed — sleep');

    // sink / bathroom corner
    const sinkBase = box(1.0, 0.85, 0.55, 0xd8dce0);
    sinkBase.position.set(-5.5, 0.45, 4.5);
    prop(sinkBase);
    const basin = box(0.7, 0.12, 0.4, 0xa8c8e0);
    basin.position.set(-5.5, 0.95, 4.5);
    scene.add(basin);
    const faucet = box(0.08, 0.25, 0.08, 0x888890);
    faucet.position.set(-5.5, 1.15, 4.35);
    scene.add(faucet);
    addSpot('sink', -5.5, 1, 4.5, 1.4, 'Sink — wash face');

    // fridge
    const fridge = box(0.95, 1.9, 0.8, 0xe8ecf0);
    fridge.position.set(-2.2, 0.95, 4.6);
    prop(fridge);
    const handle = box(0.06, 0.35, 0.06, 0x666670);
    handle.position.set(-1.8, 1.1, 4.95);
    scene.add(handle);
    addSpot('fridge', -2.2, 1, 4.2, 1.4, 'Fridge — grab food');

    // table + plate + chair
    const table = box(1.5, 0.1, 1.0, 0x8b5a2b);
    table.position.set(0.5, 0.78, 1.5);
    prop(table);
    for (const [lx, lz] of [[-0.55, -0.35], [0.55, -0.35], [-0.55, 0.35], [0.55, 0.35]]) {
      const leg = box(0.08, 0.78, 0.08, 0x6b4018);
      leg.position.set(0.5 + lx, 0.39, 1.5 + lz);
      prop(leg);
    }
    const plate = box(0.35, 0.04, 0.35, 0xf5f5f5);
    plate.position.set(0.5, 0.86, 1.5);
    plate.name = 'plate';
    scene.add(plate);
    addSpot('plate', 0.5, 0.9, 1.5, 1.35, 'Table / plate');

    const chair = box(0.5, 0.55, 0.5, 0x5a4030);
    chair.position.set(0.5, 0.35, 2.5);
    prop(chair);
    addSpot('chair', 0.5, 0.5, 2.4, 1.3, 'Chair — sit & eat');

    // water glass
    const glass = box(0.12, 0.22, 0.12, 0xa0d0ff);
    glass.position.set(1.0, 0.95, 1.5);
    scene.add(glass);
    addSpot('water', 1.0, 0.95, 1.5, 1.2, 'Water glass — drink');

    // computer desk
    const desk = box(1.4, 0.1, 0.7, 0x3a2a20);
    desk.position.set(4.2, 0.78, -3.8);
    prop(desk);
    const mon = box(0.7, 0.45, 0.06, 0x222228);
    mon.position.set(4.2, 1.2, -4.0);
    scene.add(mon);
    const screen = box(0.6, 0.35, 0.02, 0x4080c0);
    screen.position.set(4.2, 1.2, -3.96);
    scene.add(screen);
    const kb = box(0.45, 0.03, 0.18, 0x1a1a20);
    kb.position.set(4.2, 0.86, -3.7);
    scene.add(kb);
    addSpot('computer', 4.2, 1, -3.5, 1.5, 'Computer — work');

    // couch decoration
    const couch = box(2.4, 0.55, 0.9, 0x4a6a50);
    couch.position.set(2.5, 0.4, 4.2);
    prop(couch);

    // ——— GYM building (further +X, open west door from street) ———
    const gymFloor = box(10, 0.15, 11, 0x2e2e36);
    gymFloor.position.set(18.5, -0.05, 0);
    scene.add(gymFloor);
    // gym walls — west wall open doorway |z|<1.15
    wall(10, 3.2, 0.25, 0x4a4a55, 18.5, 1.6, -5.4);
    wall(10, 3.2, 0.25, 0x4a4a55, 18.5, 1.6, 5.4);
    wall(0.25, 3.2, 11, 0x4a4a55, 23.4, 1.6, 0); // back wall
    wall(0.25, 3.2, 3.9, 0x4a4a55, 13.6, 1.6, -3.55);
    wall(0.25, 3.2, 3.9, 0x4a4a55, 13.6, 1.6, 3.55);
    // gym door frame (open walk-through)
    wall(0.14, 2.4, 0.16, 0x333340, 13.6, 1.2, -1.2);
    wall(0.14, 2.4, 0.16, 0x333340, 13.6, 1.2, 1.2);
    wall(0.14, 0.22, 2.5, 0x333340, 13.6, 2.5, 0);
    // GYM sign
    const sign = box(2.2, 0.55, 0.1, 0xe05040);
    sign.position.set(13.7, 2.7, 0);
    scene.add(sign);

    // gym mats / equipment
    const matGym = box(2.4, 0.08, 1.2, 0x1a1a22);
    matGym.position.set(18, 0.08, 0);
    scene.add(matGym);
    const matGym2 = box(2.0, 0.08, 1.0, 0x222230);
    matGym2.position.set(18, 0.08, 2.2);
    scene.add(matGym2);
    const rack = box(1.6, 1.4, 0.4, 0x555560);
    rack.position.set(20.5, 0.75, -2.5);
    prop(rack);
    addSpot('gym', 18, 0.5, 0, 2.0, 'Gym mat — hold E to work out 20s');

    // rug
    const rug = box(3, 0.04, 2, 0xb05050);
    rug.position.set(0, 0.03, 0);
    scene.add(rug);

    // window light
    const win = box(1.6, 1.1, 0.08, 0x88c8ff);
    win.position.set(0, 1.9, -5.78);
    scene.add(win);
  }
  buildWorld();

  // food mesh when held / on plate
  let foodMesh = null;
  function clearFoodMesh() {
    if (foodMesh) {
      scene.remove(foodMesh);
      foodMesh = null;
    }
  }
  function showFoodOnPlate(kind) {
    clearFoodMesh();
    const colors = {
      apple: 0xe05050,
      banana: 0xffe040,
      carrot: 0xf08030,
      sandwich: 0xe8c080,
      salad: 0x50a050,
    };
    foodMesh = box(0.22, 0.1, 0.22, colors[kind] || 0xe05050);
    foodMesh.position.set(0.5, 0.95, 1.5);
    scene.add(foodMesh);
  }

  // ——— day time ———
  function dayProgress() {
    if (!started) return 0;
    return clamp((performance.now() - dayStart) / DAY_MS, 0, 1);
  }
  function gameMinutes() {
    return START_MIN + dayProgress() * SPAN_MIN;
  }
  function formatClock(mins) {
    const m = Math.floor(mins) % (24 * 60);
    let h = Math.floor(m / 60);
    const mi = Math.floor(m % 60);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return h12 + ':' + String(mi).padStart(2, '0') + ' ' + ampm;
  }
  function phaseName(mins) {
    if (mins < 11 * 60) return 'Morning';
    if (mins < 14 * 60) return 'Noon / Afternoon';
    if (mins < 17 * 60) return 'Afternoon';
    if (mins < END_MIN) return 'Evening';
    return 'Night';
  }

  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), ms || 2200);
  }

  function currentTaskId() {
    for (const t of TASKS) {
      if (!taskDone[t.id]) return t.id;
    }
    return null;
  }

  function renderTasks() {
    const cur = currentTaskId();
    taskList.innerHTML = TASKS.map((t, i) => {
      const done = !!taskDone[t.id];
      const cls = done ? 'done' : t.id === cur ? 'current' : '';
      return `<li class="${cls}"><span class="n">${i + 1}.</span><span>${t.label}</span></li>`;
    }).join('');
  }

  function complete(id, msg) {
    if (taskDone[id]) return;
    // enforce order loosely for early tasks
    taskDone[id] = true;
    if (msg) toast(msg);
    renderTasks();
    // phase toasts
    if (id === 'gym') {
      toast('Nice work. Head home — it\'s basically noon.', 2800);
    }
    if (id === 'home') {
      toast('Afternoon: use the computer to work until 7 PM.', 3000);
    }
  }

  function canDo(id) {
    // sequential for morning chain
    const order = ['wake', 'wash', 'fridge', 'plate', 'eat', 'water', 'gym', 'home', 'work', 'sleep'];
    const idx = order.indexOf(id);
    if (idx <= 0) return true;
    // work can start after home
    if (id === 'work') return taskDone.home;
    if (id === 'sleep') return taskDone.work || alarmFired;
    // require previous
    for (let i = 0; i < idx; i++) {
      if (!taskDone[order[i]]) return false;
    }
    return true;
  }

  // ——— interactions ———
  function nearestSpot() {
    let best = null;
    let bestD = 1e9;
    for (const s of spots) {
      // hide home interactables while far on street/gym
      if (player.x > 7.5 && ['sink', 'fridge', 'plate', 'chair', 'water', 'bed', 'computer'].includes(s.id)) {
        continue;
      }
      // gym mat only useful in gym
      if (s.id === 'gym' && player.x < 13) continue;
      const d = Math.hypot(s.x - player.x, s.z - player.z);
      if (d < s.r && d < bestD) {
        bestD = d;
        best = s;
      }
    }
    return best;
  }

  function updatePrompt() {
    if (computerOpen || finished) {
      promptEl.classList.add('hidden');
      return;
    }
    const s = nearestSpot();
    if (!s) {
      promptEl.classList.add('hidden');
      return;
    }
    promptEl.innerHTML = `<kbd>E</kbd> ${s.label}`;
    promptEl.classList.remove('hidden');
  }

  function interact() {
    if (computerOpen || finished) return;
    const s = nearestSpot();
    if (!s) return;

    if (s.id === 'sink') {
      if (!canDo('wash') && !taskDone.wash) {
        toast('Wake up first… you already did. Try the sink.');
      }
      washed = true;
      complete('wash', 'Face washed. Fresh.');
      return;
    }

    if (s.id === 'fridge') {
      if (!taskDone.wash) {
        toast('Wash your face first.');
        return;
      }
      const foods = ['apple', 'banana', 'carrot', 'sandwich', 'salad'];
      held = foods[(Math.random() * foods.length) | 0];
      heldEl.textContent = 'Holding: ' + held;
      complete('fridge', 'Grabbed ' + held + ' from the fridge.');
      return;
    }

    if (s.id === 'plate') {
      if (!held) {
        toast(foodOnPlate ? 'Food is already on the plate.' : 'Get food from the fridge first.');
        return;
      }
      foodOnPlate = true;
      showFoodOnPlate(held);
      heldEl.textContent = '';
      complete('plate', 'Plated the ' + held + '. Sit to eat.');
      held = null;
      return;
    }

    if (s.id === 'chair' || (s.id === 'plate' && foodOnPlate)) {
      if (!foodOnPlate) {
        toast('Put food on the plate first.');
        return;
      }
      if (!taskDone.plate) complete('plate');
      ate = true;
      clearFoodMesh();
      foodOnPlate = false;
      complete('eat', 'Om nom. Now drink water.');
      return;
    }

    if (s.id === 'water') {
      if (!taskDone.eat) {
        toast('Eat breakfast first.');
        return;
      }
      drank = true;
      complete('water', 'Hydrated. Walk out the front door → street → gym.');
      return;
    }

    // Doors are walk-through only (no E teleport)

    if (s.id === 'gym') {
      if (!taskDone.water) {
        toast('Finish morning routine first, then come work out.');
        return;
      }
      if (gymDone) {
        toast('Workout done. Walk home via the street.');
        return;
      }
      toast('Working out… keep holding E for 20s');
      return;
    }

    if (s.id === 'computer') {
      if (!taskDone.home && !taskDone.gym) {
        toast('Gym first, walk home, then work.');
        return;
      }
      if (!taskDone.home) {
        toast('Walk home from the gym first (out the gym door → street → house).');
        return;
      }
      openComputer();
      return;
    }

    if (s.id === 'bed') {
      if (!alarmFired && !taskDone.work) {
        toast('Too early — work until the 7 PM alarm.');
        return;
      }
      finishDay();
      return;
    }
  }

  // gym hold progress
  let gymHolding = false;

  // ——— computer ———
  const codeSnippets = [
    '# day_sim.py — ship something today\n',
    'def morning_routine():\n    wash_face()\n    eat_breakfast()\n    hydrate()\n\n',
    'def train(minutes=20):\n    """Gym block."""\n    for _ in range(minutes):\n        squat(); breathe()\n\n',
    'def work_session():\n    tmux_attach("tgrok")\n    code_with_ai()\n    ship()\n\n',
    'if __name__ == "__main__":\n    morning_routine()\n    train()\n    work_session()\n    sleep()\n',
  ];

  function openComputer() {
    computerOpen = true;
    computer.classList.remove('hidden');
    document.exitPointerLock();
    locked = false;
    markWork('w_tasks');
    if (!taskDone.home) complete('home');
    // work task starts
    if (!taskDone.work) {
      // not complete until alarm + work items OR just work items before sleep
    }
    refreshWorkUI();
    if (alarmFired) pcAlert.classList.remove('hidden');
  }

  function closeComputer() {
    computerOpen = false;
    computer.classList.add('hidden');
    if (started && !finished) canvas.requestPointerLock();
  }

  function markWork(id) {
    if (workDone[id]) return;
    workDone[id] = true;
    refreshWorkUI();
    maybeCompleteWork();
  }

  function refreshWorkUI() {
    const n = WORK_ITEMS.filter((w) => workDone[w.id]).length;
    workProgress.textContent = n + '/' + WORK_ITEMS.length;
    workTasksEl.innerHTML = WORK_ITEMS.map((w) => {
      return `<li class="${workDone[w.id] ? 'done' : ''}">${workDone[w.id] ? '✓ ' : '○ '}${w.label}</li>`;
    }).join('');
  }

  function maybeCompleteWork() {
    const all = WORK_ITEMS.every((w) => workDone[w.id]);
    if (all && !taskDone.work) {
      complete('work', 'Work queue cleared. When it\'s 7 PM, sleep.');
    }
    // also allow work complete at 7pm even if partial if they stayed
    if (alarmFired && !taskDone.work && Object.keys(workDone).length >= 2) {
      complete('work', 'Good enough for today. Go to bed!');
    }
  }

  function finishDay() {
    finished = true;
    complete('sleep', 'Lights out.');
    closeComputer();
    document.exitPointerLock();
    endMsg.textContent =
      'You washed, ate, trained, coded, attached tmux tgrok, and slept. Day complete.';
    endScreen.classList.remove('hidden');
  }

  /**
   * Continuous walkable map:
   *  HOME (x < 6.5) --open door--> STREET (6.5..13.6) --open door--> GYM (x > 13.6)
   */
  function isWalkable(x, z) {
    // HOME interior
    if (x >= -6.4 && x <= 6.55 && z >= -5.4 && z <= 5.4) return true;
    // HOME doorway pocket (open door)
    if (x >= 6.0 && x <= 7.2 && z >= -1.15 && z <= 1.15) return true;
    // STREET (outside)
    if (x >= 6.5 && x <= 13.7 && z >= -7.5 && z <= 7.5) return true;
    // GYM doorway
    if (x >= 13.2 && x <= 14.3 && z >= -1.15 && z <= 1.15) return true;
    // GYM interior
    if (x >= 13.7 && x <= 23.0 && z >= -5.0 && z <= 5.0) return true;
    return false;
  }

  function syncRoomFlags() {
    if (player.x >= 14.0) {
      inHome = false;
      atGym = true;
    } else if (player.x <= 6.4) {
      inHome = true;
      atGym = false;
    } else {
      // street
      inHome = false;
      atGym = false;
    }
  }

  function updatePlayer(dt) {
    if (computerOpen || finished) return;

    const fwd = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, player.yaw, 0, 'YXZ'));
    const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, player.yaw, 0, 'YXZ'));
    let mx = 0;
    let mz = 0;
    if (keyDown('KeyW') || keyDown('w') || keyDown('ArrowUp')) { mx += fwd.x; mz += fwd.z; }
    if (keyDown('KeyS') || keyDown('s') || keyDown('ArrowDown')) { mx -= fwd.x; mz -= fwd.z; }
    if (keyDown('KeyA') || keyDown('a') || keyDown('ArrowLeft')) { mx -= right.x; mz -= right.z; }
    if (keyDown('KeyD') || keyDown('d') || keyDown('ArrowRight')) { mx += right.x; mz += right.z; }

    const len = Math.hypot(mx, mz);
    if (len > 1e-6) {
      mx = (mx / len) * player.speed;
      mz = (mz / len) * player.speed;
    } else {
      mx = 0;
      mz = 0;
    }

    player.vx = mx;
    player.vz = mz;
    // axis-separated so you can slide through doorways
    const nx = player.x + player.vx * dt;
    const nz = player.z + player.vz * dt;
    if (isWalkable(nx, player.z)) player.x = nx;
    if (isWalkable(player.x, nz)) player.z = nz;

    syncRoomFlags();
    // walking home after gym counts as return
    if (inHome && taskDone.gym && !taskDone.home) {
      complete('home', 'Back home. Afternoon work at the computer.');
    }
    // soft tip when first step onto street after water
    if (taskDone.water && !taskDone.gym && player.x > 7 && player.x < 8 && !updatePlayer._streetTip) {
      updatePlayer._streetTip = true;
      toast('Street — keep walking forward to the red GYM entrance.', 2800);
    }

    camera.position.set(player.x, player.y, player.z);
    camera.rotation.x = player.pitch;
    camera.rotation.y = player.yaw;

    // gym workout while near gym and holding E
    const nearGym = nearestSpot() && nearestSpot().id === 'gym';
    if (nearGym && (keyDown('KeyE') || keyDown('e') || keyDown('Space')) && !gymDone && taskDone.water) {
      gymProgress += dt;
      heldEl.textContent = 'Working out… ' + Math.min(20, gymProgress | 0) + '/20s';
      if (gymProgress >= 20) {
        gymDone = true;
        heldEl.textContent = '';
        complete('gym', '20s workout complete! Walk home via the street.');
      }
    }

    updatePrompt();
  }

  function updateDay() {
    if (!started || finished) return;
    const p = dayProgress();
    const mins = gameMinutes();
    clockEl.textContent = formatClock(mins);
    phaseEl.textContent = phaseName(mins);
    dayBar.style.width = (p * 100).toFixed(2) + '%';
    const left = Math.max(0, DAY_MS - (performance.now() - dayStart));
    const sec = Math.ceil(left / 1000);
    const mm = String(Math.floor(sec / 60)).padStart(2, '0');
    const ss = String(sec % 60).padStart(2, '0');
    realLeft.textContent = mm + ':' + ss + ' until night';

    // noon-ish message once after gym path - skip

    // sky color by time
    const t = p;
    const col = new THREE.Color().setHSL(0.58 - t * 0.08, 0.35, 0.55 - t * 0.2);
    renderer.setClearColor(col.getHex(), 1);
    scene.fog.color.copy(col);
    // warmer evening lamp
    lamp.intensity = 0.4 + t * 0.8;

    if (mins >= END_MIN && !alarmFired) {
      alarmFired = true;
      pcAlert.classList.remove('hidden');
      toast('⏰ 7:00 PM — Sleep alarm! Go to bed.', 4000);
      if (computerOpen) {
        // already open
      }
      maybeCompleteWork();
      if (!taskDone.work) {
        // force-complete work if they at least opened computer
        if (Object.keys(workDone).length > 0) complete('work', 'Shift over. Bedtime.');
      }
    }

    // soft end if they never sleep after alarm + 45s
    if (alarmFired && p >= 1 && !finished) {
      // keep waiting for bed
      realLeft.textContent = 'NIGHT — go to bed!';
    }
  }

  // ——— input ———
  function resize() {
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / Math.max(1, innerHeight);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('click', () => {
    if (started && !finished && !computerOpen) canvas.requestPointerLock();
  });
  document.addEventListener('pointerlockchange', () => {
    locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!locked || computerOpen) return;
    player.yaw -= e.movementX * 0.0022;
    player.pitch -= e.movementY * 0.002;
    player.pitch = clamp(player.pitch, -1.3, 1.2);
  });
  function onKeyDown(e) {
    keys[e.code] = true;
    if (e.key) {
      keys[e.key] = true;
      keys[e.key.toLowerCase()] = true;
    }
    const t = e.target;
    const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    if (computerOpen && typing) return;

    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
      e.preventDefault();
    }
    // keep movement keys from scrolling / specials
    if (['KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(e.code)) e.preventDefault();

    if (!started || finished) return;
    if ((e.code === 'KeyE' || e.key === 'e' || e.key === 'E') && !computerOpen) {
      const s = nearestSpot();
      if (s) interact();
    }
    if (e.code === 'Escape' && computerOpen) closeComputer();
  }
  function onKeyUp(e) {
    keys[e.code] = false;
    if (e.key) {
      keys[e.key] = false;
      keys[e.key.toLowerCase()] = false;
    }
  }
  window.addEventListener('keydown', onKeyDown, true);
  window.addEventListener('keyup', onKeyUp, true);
  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('keyup', onKeyUp, true);

  // computer UI
  document.querySelectorAll('.app-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.app-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.app-panel').forEach((p) => p.classList.add('hidden'));
      const app = btn.getAttribute('data-app');
      document.getElementById('app-' + app).classList.remove('hidden');
      if (app === 'tasks') markWork('w_tasks');
    });
  });

  btnWriteCode.addEventListener('click', () => {
    if (codeLines >= codeSnippets.length) {
      codeStatus.textContent = 'File complete. Nice.';
      markWork('w_code');
      return;
    }
    codeView.textContent += codeSnippets[codeLines];
    codeLines++;
    codeStatus.textContent = 'AI suggested block ' + codeLines + '/' + codeSnippets.length;
    if (codeLines >= 2) markWork('w_code');
  });

  function termPrint(html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    term.appendChild(d);
    term.scrollTop = term.scrollHeight;
  }

  function runTerm() {
    const cmd = termInput.value.trim();
    if (!cmd) return;
    termPrint('<span style="color:#8f8">$ ' + cmd.replace(/</g, '&lt;') + '</span>');
    termInput.value = '';
    const c = cmd.toLowerCase();
    if (c === 'tmux attach -t tgrok' || c === 'tmux a -t tgrok' || c === 'tmux attach tgrok') {
      termPrint('[attached] session tgrok');
      termPrint('tgrok 1:zsh* 2:nvim 3:logs');
      termPrint('(press to detach — not needed in sim)');
      tmuxAttached = true;
      markWork('w_tmux');
      toast('tmux attached to tgrok ✓');
    } else if (c === 'tmux ls' || c === 'tmux list-sessions') {
      termPrint('tgrok: 1 windows (created today)');
    } else if (c === 'help') {
      termPrint('try: tmux ls · tmux attach -t tgrok');
    } else if (c === 'clear') {
      term.innerHTML = '';
    } else {
      termPrint('<span class="dim">command not found (sim). try tmux attach -t tgrok</span>');
    }
  }
  termRun.addEventListener('click', runTerm);
  termInput.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') runTerm();
  });

  const AI_REPLIES = [
    'tgrok: Sure — extract morning_routine() and keep side effects out of main. Ship small PRs.',
    'tgrok: For the gym timer, accumulate dt while the player holds interact; complete at 20s.',
    'tgrok: Use a single task graph with canDo(prev) so the day stays ordered.',
    'tgrok: tmux session tgrok looks good. Keep editor + logs in panes 2 and 3.',
  ];
  function sendAi() {
    const q = aiInput.value.trim();
    if (!q) return;
    const you = document.createElement('div');
    you.className = 'msg you';
    you.textContent = 'You: ' + q;
    aiLog.appendChild(you);
    aiInput.value = '';
    const bot = document.createElement('div');
    bot.className = 'msg bot';
    bot.textContent = AI_REPLIES[(Math.random() * AI_REPLIES.length) | 0];
    aiLog.appendChild(bot);
    aiLog.scrollTop = aiLog.scrollHeight;
    aiAsked = true;
    markWork('w_ai');
  }
  aiSend.addEventListener('click', sendAi);
  aiInput.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter') sendAi();
  });

  pcClose.addEventListener('click', closeComputer);

  btnStart.addEventListener('click', () => {
    started = true;
    dayStart = performance.now();
    // force spawn next to bed every start
    player.x = -3.0;
    player.y = 1.55;
    player.z = -3.8;
    player.yaw = Math.PI * 0.5;
    player.pitch = 0;
    player.vx = 0;
    player.vz = 0;
    overlay.classList.add('hidden');
    canvas.tabIndex = 0;
    canvas.focus();
    // pointer lock optional — movement works without it
    try { canvas.requestPointerLock(); } catch (_) {}
    renderTasks();
    refreshWorkUI();
    toast('You woke up by the bed. WASD walk · click look · E interact', 3500);
  });

  canvas.tabIndex = 0;
  canvas.style.outline = 'none';

  btnReplay.addEventListener('click', () => location.reload());

  // bootstrap UI
  renderTasks();
  refreshWorkUI();
  codeView.textContent = '';

  // loop
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (started && !finished) {
      updatePlayer(dt);
      updateDay();
    } else if (!started) {
      camera.position.set(player.x, player.y, player.z);
      camera.rotation.set(player.pitch, player.yaw, 0);
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
