// Rec Room Arkhe — multi-bot ambient chat (public: KidArcadeChat presets + optional voice)
(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const chatLog = $('#chat-log');
  const chatInput = $('#chat-input');
  const chatSend = $('#chat-send');
  const aiStatus = $('#ai-status');
  const ptt = $('#ptt');
  const playerList = $('#player-list');
  const roomTitle = $('#room-title');
  const roomSub = $('#room-sub');
  const originalsList = $('#originals-list');
  const roomsList = $('#rooms-list');

  const BOTS = [
    { id: 'RecBot', cls: 'bot', color: '#ff6bcb', persona: 'recbot' },
    { id: 'Player2', cls: 'p2', color: '#a88bff', persona: 'chonks' },
    { id: 'Squadmate', cls: 'sq', color: '#1ec8c8', persona: 'kinito' },
  ];

  let world = null;
  let currentRoom = null;
  let history = []; // user ↔ RecBot direct chat
  let roomLog = []; // {who, text} for ambient context
  let lastBotReply = '';
  let ttsOn = true;
  let ambientOn = true;
  let listening = false;
  let busyUser = false;
  let busyAmbient = false;
  let recognition = null;
  let ambientTimer = null;
  let lastSpeaker = '';
  let micReady = false;
  let speechUnlocked = false;
  let pendingTranscript = '';
  let currentUtterance = null; // must retain ref or browsers GC + silent fail
  let ttsResumeTimer = null;
  let pttMode = 'hold'; // hold | toggle
  let SpeechRecCtor = null;
  let wantListen = false; // fixes pointerup-before-mic-ready race

  function chat(who, text, cls) {
    const d = document.createElement('div');
    d.className = 'chat-line';
    d.innerHTML = `<span class="who ${cls || ''}">${escapeHtml(who)}</span>${escapeHtml(text)}`;
    chatLog.appendChild(d);
    chatLog.scrollTop = chatLog.scrollHeight;
    while (chatLog.children.length > 50) chatLog.removeChild(chatLog.firstChild);
    if (who !== 'System' && text !== '…') {
      roomLog.push({ who, text });
      if (roomLog.length > 24) roomLog.splice(0, roomLog.length - 24);
    }
  }
  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function pickVoice() {
    if (!window.speechSynthesis) return null;
    const voices = speechSynthesis.getVoices() || [];
    return (
      voices.find((x) => /samantha|karen|moira|google us english|microsoft aria|zira/i.test(x.name)) ||
      voices.find((x) => /^en[-_]?us/i.test(x.lang)) ||
      voices.find((x) => /^en/i.test(x.lang)) ||
      voices[0] ||
      null
    );
  }

  function unlockSpeech() {
    // Browsers block TTS until a user gesture; also Chrome pauses synth in long sessions
    speechUnlocked = true;
    if (!window.speechSynthesis) return;
    try {
      // silent unlock utterance
      const u = new SpeechSynthesisUtterance(' ');
      u.volume = 0;
      u.rate = 2;
      currentUtterance = u;
      speechSynthesis.speak(u);
      speechSynthesis.cancel();
    } catch (_) {}
  }

  function speak(text) {
    if (!ttsOn || !window.speechSynthesis || !text) return;
    const clean = String(text).replace(/\s+/g, ' ').trim().slice(0, 400);
    if (!clean) return;

    // Chrome bug: synth gets stuck paused
    try {
      if (speechSynthesis.paused) speechSynthesis.resume();
    } catch (_) {}

    try { speechSynthesis.cancel(); } catch (_) {}

    // small delay after cancel so Safari actually queues the next line
    const run = () => {
      const u = new SpeechSynthesisUtterance(clean);
      currentUtterance = u; // prevent GC drop
      u.rate = 1.02;
      u.pitch = 1.05;
      u.volume = 1;
      u.lang = 'en-US';
      const v = pickVoice();
      if (v) {
        u.voice = v;
        u.lang = v.lang || 'en-US';
      }
      u.onerror = (ev) => {
        console.warn('[rec] TTS error', ev.error);
        chat('System', `Voice (TTS) error: ${ev.error || 'unknown'}`, 'sys');
      };
      try {
        speechSynthesis.speak(u);
        // Chrome long-utterance pause bug — nudge resume
        if (ttsResumeTimer) clearInterval(ttsResumeTimer);
        ttsResumeTimer = setInterval(() => {
          try {
            if (speechSynthesis.speaking && speechSynthesis.paused) speechSynthesis.resume();
            if (!speechSynthesis.speaking) clearInterval(ttsResumeTimer);
          } catch (_) {
            clearInterval(ttsResumeTimer);
          }
        }, 250);
      } catch (e) {
        chat('System', `TTS failed: ${e.message || e}`, 'sys');
      }
    };

    // voices often empty on first call — wait once
    if (!(speechSynthesis.getVoices() || []).length) {
      const once = () => {
        speechSynthesis.removeEventListener('voiceschanged', once);
        setTimeout(run, 40);
      };
      speechSynthesis.addEventListener('voiceschanged', once);
      setTimeout(run, 200); // fallback
    } else {
      setTimeout(run, 50);
    }
  }

  function refreshStatus() {
    const has = !!(window.KidArcadeChat && typeof window.KidArcadeChat.chat === 'function');
    if (has) {
      aiStatus.textContent = ambientOn
        ? 'Bots live · offline presets'
        : 'Ambient off · presets ready';
      aiStatus.className = 'status ok';
    } else {
      aiStatus.textContent = 'Chat pack missing — type may be limited';
      aiStatus.className = 'status warn';
    }
  }

  function personaForSpeaker(speaker) {
    const bot = BOTS.find((b) => b.id === speaker);
    return (bot && bot.persona) || 'recbot';
  }

  async function callBot({ message, speaker, ambient, historySlice }) {
    const persona = personaForSpeaker(speaker || 'RecBot');
    const prompt = ambient
      ? 'Say a short silly room comment (1 sentence). Kid-safe.'
      : message || 'hi';

    // Preferred: shared KidArcadeChat (Pages-safe)
    if (window.KidArcadeChat && typeof window.KidArcadeChat.chat === 'function') {
      const d = await window.KidArcadeChat.chat({
        persona,
        message: prompt,
        history: historySlice || [],
      });
      if (d && d.ok && d.reply) {
        return {
          ok: true,
          reply: String(d.reply).replace(/\n+/g, ' ').trim(),
          model: d.model || 'preset:' + persona,
        };
      }
    }

    // Tiny inline fallbacks if presets failed to load
    const local = {
      recbot: [
        'Hey! Rec Center is open — what should we do?',
        'Nice! I’m RecBot, always here for a quick chat.',
        'Walk around and say hi — I answer offline too.',
      ],
      chonks: ['squeak! desk chonk energy!', 'we live for snacks and vibes'],
      kinito: ['Hello! I am a helpful squadmate!', 'That sounds fun — let’s go!'],
    };
    const pool = local[persona] || local.recbot;
    return {
      ok: true,
      reply: pool[(Math.random() * pool.length) | 0],
      model: 'preset-inline:' + persona,
    };
  }

  async function askBot(message) {
    if (busyUser || !message.trim()) return;
    busyUser = true;
    // pause ambient so it doesn't compete with voice turn
    if (ambientTimer) clearTimeout(ambientTimer);
    chat('You', message, 'me');
    history.push({ role: 'user', content: message });
    chat('RecBot', '…', 'bot');
    const pending = chatLog.lastChild;
    try {
      const d = await callBot({
        message,
        speaker: 'RecBot',
        ambient: false,
        historySlice: history.slice(0, -1),
        speakReply: true,
      });
      lastBotReply = d.reply;
      history.push({ role: 'assistant', content: d.reply });
      if (history.length > 16) history.splice(0, history.length - 16);
      pending.innerHTML = `<span class="who bot">RecBot</span>${escapeHtml(d.reply)}`;
      // avoid double roomLog (chat() already logged "…" then we replace — push real reply)
      roomLog.push({ who: 'RecBot', text: d.reply });
      if (roomLog.length > 24) roomLog.splice(0, roomLog.length - 24);
      // always speak RecBot reply for voice chat
      speak(d.reply);
      lastSpeaker = 'RecBot';
      if (d.model) {
        aiStatus.textContent = `RecBot voice · ${d.model}`;
        aiStatus.className = 'status ok';
      }
      // other bots sometimes chime in after user (text only)
      if (Math.random() < 0.45) {
        setTimeout(() => ambientTick(true), 1200);
      } else {
        scheduleAmbient();
      }
    } catch (e) {
      pending.innerHTML = `<span class="who sys">System</span>${escapeHtml(String(e.message || e))}`;
      scheduleAmbient();
    }
    busyUser = false;
  }

  function pickBot(preferNotLast) {
    const pool = BOTS.filter((b) => !preferNotLast || b.id !== lastSpeaker);
    const list = pool.length ? pool : BOTS;
    return list[Math.floor(Math.random() * list.length)];
  }

  async function ambientTick(force) {
    if (!ambientOn || busyAmbient || busyUser) return;
    if (!force && document.hidden) return;
    busyAmbient = true;
    const bot = pickBot(true);
    const cls = bot.cls;
    chat(bot.id, '…', cls);
    const pending = chatLog.lastChild;
    try {
      const d = await callBot({
        message: 'ambient',
        speaker: bot.id,
        ambient: true,
      });
      const reply = (d.reply || '').replace(/\n+/g, ' ').trim() || '…';
      pending.innerHTML = `<span class="who ${cls}">${escapeHtml(bot.id)}</span>${escapeHtml(reply)}`;
      roomLog.push({ who: bot.id, text: reply });
      lastSpeaker = bot.id;
      // no TTS spam for ambient — text only
    } catch (e) {
      pending.innerHTML = `<span class="who sys">System</span>bot lag: ${escapeHtml(String(e.message || e).slice(0, 80))}`;
    }
    busyAmbient = false;
    scheduleAmbient();
  }

  function scheduleAmbient() {
    if (ambientTimer) clearTimeout(ambientTimer);
    if (!ambientOn) return;
    // 6–14s between bot lines so room feels alive without flooding
    const ms = 6000 + Math.random() * 8000;
    ambientTimer = setTimeout(() => ambientTick(false), ms);
  }

  function createRecognition() {
    if (!SpeechRecCtor) return null;
    const rec = new SpeechRecCtor();
    rec.lang = 'en-US';
    rec.interimResults = true;
    rec.continuous = true; // hold-to-talk: collect until release
    rec.maxAlternatives = 1;

    rec.onstart = () => {
      listening = true;
      ptt.classList.add('listening');
      ptt.textContent = pttMode === 'toggle' ? 'Listening… click to send' : 'Listening… release to send';
      aiStatus.textContent = 'Mic live — speak now';
      aiStatus.className = 'status ok';
    };

    rec.onresult = (ev) => {
      let finalChunk = '';
      let interim = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const t = ev.results[i][0].transcript;
        if (ev.results[i].isFinal) finalChunk += t;
        else interim += t;
      }
      if (finalChunk) pendingTranscript = (pendingTranscript + ' ' + finalChunk).trim();
      const preview = (pendingTranscript + (interim ? ' ' + interim : '')).trim();
      if (preview) {
        ptt.textContent = preview.slice(0, 42) + (preview.length > 42 ? '…' : '');
      }
    };

    rec.onerror = (ev) => {
      // Browsers (esp. Safari) often emit noisy technical strings like
      // "The string did not match the expected pattern." — keep chat fun.
      const err = String((ev && ev.error) || (ev && ev.message) || 'error');
      const soft =
        /pattern|network|aborted|no-speech|audio-capture|language|not-allowed|service-not-allowed|bad-grammar/i.test(
          err
        );
      if (err === 'not-allowed' || err === 'service-not-allowed') {
        chat('System', 'Mic blocked — allow microphone, or just type chat (always works).', 'sys');
        aiStatus.textContent = 'Mic permission denied · type instead';
        aiStatus.className = 'status warn';
      } else if (err === 'no-speech') {
        aiStatus.textContent = 'No speech heard — hold longer, or type chat';
        aiStatus.className = 'status warn';
      } else if (err !== 'aborted') {
        if (soft) {
          aiStatus.textContent = 'Voice glitch — type chat works fine';
          aiStatus.className = 'status warn';
        } else {
          chat('System', 'Voice hiccup — use the text box to talk.', 'sys');
          aiStatus.textContent = 'Type chat ready';
          aiStatus.className = 'status warn';
        }
      }
      listening = false;
      ptt.classList.remove('listening');
      ptt.textContent = 'Hold to talk (or V)';
    };

    rec.onend = () => {
      const hadSession = listening || wantListen;
      listening = false;
      wantListen = false;
      ptt.classList.remove('listening');
      ptt.textContent = 'Hold to talk (or V)';
      const text = pendingTranscript.trim();
      pendingTranscript = '';
      if (hadSession && text) {
        askBot(text);
      } else if (hadSession && !text) {
        aiStatus.textContent = 'Didn’t catch that — hold pink button ~2s and speak';
        aiStatus.className = 'status warn';
      }
      // Chrome: instance often dies after end — recreate next time
      recognition = null;
    };

    return rec;
  }

  async function ensureMic() {
    if (micReady) return true;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      chat('System', 'No mic API in this browser. Try Chrome, or type chat.', 'sys');
      return false;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // release tracks — we only needed permission; SpeechRecognition uses mic itself
      stream.getTracks().forEach((t) => t.stop());
      micReady = true;
      return true;
    } catch (e) {
      chat('System', 'Mic permission denied. Enable microphone for localhost, then reload.', 'sys');
      aiStatus.textContent = 'Mic permission needed';
      aiStatus.className = 'status warn';
      return false;
    }
  }

  function setupSpeech() {
    SpeechRecCtor = window.SpeechRecognition || window.webkitSpeechRecognition || null;
    if (!SpeechRecCtor) {
      ptt.textContent = 'Voice N/A in this browser — use Chrome or type';
      ptt.disabled = true;
      chat('System', 'Speech recognition missing (Safari often lacks it). Use Google Chrome for voice, or type chat. TTS may still work.', 'sys');
      return;
    }
    // warm voices list
    if (window.speechSynthesis) {
      speechSynthesis.getVoices();
      speechSynthesis.addEventListener('voiceschanged', () => pickVoice());
    }
    ptt.title = 'Hold and speak, then release to send to RecBot';
  }

  async function startListen() {
    unlockSpeech();
    if (!SpeechRecCtor || busyUser) return;
    if (listening || wantListen) return;
    wantListen = true;
    pendingTranscript = '';
    ptt.classList.add('listening');
    ptt.textContent = 'Starting mic…';

    const ok = await ensureMic();
    if (!wantListen) return; // released during permission prompt
    if (!ok) {
      wantListen = false;
      ptt.classList.remove('listening');
      ptt.textContent = 'Hold to talk (or V)';
      return;
    }

    try {
      if (recognition) {
        try { recognition.abort(); } catch (_) {}
        recognition = null;
      }
      recognition = createRecognition();
      recognition.start();
    } catch (e) {
      try {
        recognition = createRecognition();
        recognition.start();
      } catch (e2) {
        chat('System', `Could not start mic: ${e2.message || e2}`, 'sys');
        wantListen = false;
        listening = false;
        ptt.classList.remove('listening');
        ptt.textContent = 'Hold to talk (or V)';
      }
    }
  }

  function stopListen() {
    wantListen = false;
    const rec = recognition;
    if (!rec) {
      listening = false;
      ptt.classList.remove('listening');
      ptt.textContent = 'Hold to talk (or V)';
      return;
    }
    // brief delay so final STT chunks land, but only stop THIS session
    setTimeout(() => {
      if (recognition !== rec) return;
      try { rec.stop(); } catch (_) {
        try { rec.abort(); } catch (_) {}
      }
    }, 200);
  }

  async function toggleListen() {
    if (listening || wantListen) stopListen();
    else await startListen();
  }

  function renderRoomLists() {
    const all = window.REC_ROOMS;
    originalsList.innerHTML = all.originals.map(roomCard).join('');
    roomsList.innerHTML = all.customs.map(roomCard).join('');
    document.querySelectorAll('.room-card').forEach((el) => {
      el.addEventListener('click', () => joinRoom(el.dataset.id));
    });
  }

  function roomCard(r) {
    return `<div class="room-card" data-id="${r.id}">
      <div class="name">${escapeHtml(r.name)}</div>
      <div class="meta">${escapeHtml(r.players)} · ${escapeHtml(r.blurb.slice(0, 48))}…</div>
      <span class="tag ${r.kind === 'original' ? 'original' : ''}">${escapeHtml(r.tag)}</span>
    </div>`;
  }

  function findRoom(id) {
    const all = [...window.REC_ROOMS.originals, ...window.REC_ROOMS.customs];
    return all.find((r) => r.id === id);
  }

  function setPlayers() {
    playerList.innerHTML = `
      <div class="player-chip"><span class="dot"></span> You</div>
      <div class="player-chip"><span class="dot bot"></span> RecBot (AI)</div>
      <div class="player-chip"><span class="dot p2"></span> Player2 (AI)</div>
      <div class="player-chip"><span class="dot sq"></span> Squadmate (AI)</div>
    `;
  }

  function joinRoom(id) {
    const room = findRoom(id);
    if (!room || !world) return;
    currentRoom = room;
    world.loadRoom(room);
    roomTitle.textContent = room.name;
    roomSub.textContent = room.blurb;
    document.querySelectorAll('.room-card').forEach((el) => {
      el.classList.toggle('active', el.dataset.id === id);
    });
    setPlayers();
    roomLog = [];
    history = [];
    lastSpeaker = '';
    chat('System', `Joined ${room.name}. Bots chat offline (presets) — type anytime.`, 'sys');
    // kick ambient conversation after short delay
    setTimeout(() => ambientTick(true), 700);
    scheduleAmbient();
  }

  function wireUi() {
    chatSend.addEventListener('click', () => {
      unlockSpeech();
      const t = chatInput.value.trim();
      chatInput.value = '';
      if (t) askBot(t);
    });
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        unlockSpeech();
        chatSend.click();
      }
    });

    // V = push-to-talk (ignore key-repeat)
    window.addEventListener('keydown', (e) => {
      if (e.code === 'KeyT' && document.activeElement !== chatInput && !e.repeat) {
        e.preventDefault();
        chatInput.focus();
      }
      if (e.code === 'KeyV' && document.activeElement !== chatInput && !e.repeat) {
        e.preventDefault();
        startListen();
      }
    });
    window.addEventListener('keyup', (e) => {
      if (e.code === 'KeyV') {
        e.preventDefault();
        stopListen();
      }
    });
    // if pointer lock steals focus, still stop on blur of window
    window.addEventListener('blur', () => {
      if (listening) stopListen();
    });

    // Hold-to-talk on button (pointer events more reliable than mouseleave cancel)
    ptt.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      ptt.setPointerCapture?.(e.pointerId);
      unlockSpeech();
      startListen();
    });
    ptt.addEventListener('pointerup', (e) => {
      e.preventDefault();
      stopListen();
    });
    ptt.addEventListener('pointercancel', () => stopListen());
    // double-click toggles continuous listen (helps when hold is awkward)
    ptt.addEventListener('dblclick', (e) => {
      e.preventDefault();
      pttMode = 'toggle';
      toggleListen();
    });

    $('#btn-speak-last').addEventListener('click', () => {
      unlockSpeech();
      if (lastBotReply) speak(lastBotReply);
      else chat('System', 'No RecBot line to replay yet — talk first.', 'sys');
    });
    $('#btn-mute-tts').addEventListener('click', () => {
      ttsOn = !ttsOn;
      $('#btn-mute-tts').textContent = ttsOn ? 'TTS on' : 'TTS muted';
      if (!ttsOn) {
        try { speechSynthesis.cancel(); } catch (_) {}
      } else {
        unlockSpeech();
        if (lastBotReply) speak(lastBotReply);
      }
    });

    // Test AI voice button
    const testBtn = $('#btn-test-voice');
    if (testBtn) {
      testBtn.addEventListener('click', async () => {
        unlockSpeech();
        chat('System', 'Testing RecBot voice…', 'sys');
        speak('Hey! RecBot voice check. If you can hear me, voice chat is working.');
        try {
          const d = await callBot({
            message: 'Say a super short hello for a voice test.',
            speaker: 'RecBot',
            ambient: false,
          });
          lastBotReply = d.reply;
          chat('RecBot', d.reply, 'bot');
          speak(d.reply);
        } catch (e) {
          chat('System', String(e.message || e), 'sys');
        }
      });
    }

    // ambient toggle
    const ambBtn = $('#btn-ambient');
    if (ambBtn) {
      ambBtn.addEventListener('click', () => {
        ambientOn = !ambientOn;
        ambBtn.textContent = ambientOn ? 'Bots chatting' : 'Bots paused';
        ambBtn.classList.toggle('ghost', !ambientOn);
        if (ambientOn) {
          scheduleAmbient();
          ambientTick(true);
        } else if (ambientTimer) {
          clearTimeout(ambientTimer);
        }
        refreshStatus();
      });
    }

    $('#btn-focus').addEventListener('click', () => world && world.setPointerLock());
    $('#btn-invite').addEventListener('click', () => {
      navigator.clipboard?.writeText(location.href);
      chat('System', 'Invite link copied (local demo — share the URL).', 'sys');
    });
    $('#btn-create-room').addEventListener('click', () => {
      const name = prompt('Room name?', 'My Cool Room');
      if (!name) return;
      const id = 'custom-' + Date.now();
      const room = {
        id,
        name,
        kind: 'custom',
        tag: 'Room',
        players: 'You',
        blurb: 'Custom room you just made.',
        theme: {
          floor: 0x2a2048,
          wall: 0x4a3080,
          accent: 0xff88cc,
          sky: 0x180828,
        },
      };
      window.REC_ROOMS.customs.unshift(room);
      renderRoomLists();
      joinRoom(id);
    });
  }

  window.addEventListener('DOMContentLoaded', () => {
    setupSpeech();
    wireUi();
    renderRoomLists();
    refreshStatus();
    world = window.RecWorld.create(document.getElementById('c'));
    joinRoom('rec-center');
    chat('System', 'Welcome! RecBot, Player2 & Squadmate chat offline. Type anytime — hold V only if voice works.', 'sys');
    setInterval(refreshStatus, 30000);
  });
})();
