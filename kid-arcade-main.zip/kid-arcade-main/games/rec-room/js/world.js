// Three.js first-person rec room world
window.RecWorld = (function () {
  'use strict';

  function getForward(pitch, yaw) {
    return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(pitch, yaw, 0, 'YXZ'));
  }
  function getRight(pitch, yaw) {
    return new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(pitch, yaw, 0, 'YXZ'));
  }
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function create(canvas) {
    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    renderer.setSize(canvas.clientWidth || innerWidth, canvas.clientHeight || innerHeight, false);
    renderer.setClearColor(0x1a1040, 1);

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x1a1040, 12, 55);
    const camera = new THREE.PerspectiveCamera(70, 1, 0.08, 120);
    camera.rotation.order = 'YXZ';

    const amb = new THREE.AmbientLight(0xffffff, 0.55);
    scene.add(amb);
    const hemi = new THREE.HemisphereLight(0xc8b0ff, 0x302040, 0.6);
    scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffe8ff, 0.7);
    key.position.set(8, 14, 6);
    scene.add(key);
    const accent = new THREE.PointLight(0x1ec8c8, 1.2, 25, 2);
    accent.position.set(0, 3, 0);
    scene.add(accent);

    let roomRoot = new THREE.Group();
    scene.add(roomRoot);
    const colliders = [];
    const npcs = [];

    const player = {
      x: 0, y: 1.5, z: 4,
      speed: 5.5,
      sprint: 9,
      radius: 0.3,
    };
    let yaw = 0, pitch = 0;
    let locked = false;
    const keys = {};
    let roomId = 'rec-center';

    function mat(c) {
      return new THREE.MeshLambertMaterial({ color: c });
    }
    function box(w, h, d, x, y, z, color, solid) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(color));
      m.position.set(x, y, z);
      roomRoot.add(m);
      if (solid !== false) {
        m.updateMatrixWorld(true);
        const b = new THREE.Box3().setFromObject(m);
        colliders.push({ min: b.min.clone(), max: b.max.clone() });
      }
      return m;
    }

    function clearRoom() {
      while (roomRoot.children.length) roomRoot.remove(roomRoot.children[0]);
      colliders.length = 0;
      npcs.forEach((n) => scene.remove(n.mesh));
      npcs.length = 0;
    }

    function makeNpc(name, color, x, z) {
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.7, 4, 8), mat(color));
      body.position.y = 1.0;
      // fallback if CapsuleGeometry missing in r134
      if (!body.geometry || !THREE.CapsuleGeometry) {
        const body2 = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.1, 0.35), mat(color));
        body2.position.y = 1.0;
        g.add(body2);
      } else g.add(body);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 12), mat(0xffe0b0));
      head.position.y = 1.75;
      g.add(head);
      // name sprite-ish
      g.position.set(x, 0, z);
      scene.add(g);
      npcs.push({
        mesh: g,
        name,
        baseX: x,
        baseZ: z,
        t: Math.random() * 10,
        color,
      });
      return g;
    }

    // r134 may not have CapsuleGeometry - use boxes only
    function makeNpcSafe(name, color, x, z) {
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.0, 0.35), mat(color));
      body.position.y = 1.0;
      const head = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.45, 0.45), mat(0xffe0b0));
      head.position.y = 1.7;
      const legL = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.55, 0.2), mat(color));
      legL.position.set(-0.15, 0.3, 0);
      const legR = legL.clone(); legR.position.x = 0.15;
      g.add(body, head, legL, legR);
      g.position.set(x, 0, z);
      roomRoot.add(g);
      npcs.push({ mesh: g, name, baseX: x, baseZ: z, t: Math.random() * 10, color, legL, legR });
      return g;
    }

    function loadRoom(room) {
      clearRoom();
      roomId = room.id;
      const t = room.theme || {};
      const floorC = t.floor ?? 0x3a2f5c;
      const wallC = t.wall ?? 0x5a4a90;
      const accentC = t.accent ?? 0x1ec8c8;
      const skyC = t.sky ?? 0x1a1040;
      scene.background = new THREE.Color(skyC);
      scene.fog.color.setHex(skyC);
      accent.color.setHex(accentC);

      // floor + ceiling
      box(24, 0.3, 24, 0, -0.15, 0, floorC, false);
      box(24, 0.2, 24, 0, 5.2, 0, 0x1a1030, false);
      // walls
      box(24, 5, 0.4, 0, 2.5, -12, wallC, true);
      box(24, 5, 0.4, 0, 2.5, 12, wallC, true);
      box(0.4, 5, 24, -12, 2.5, 0, wallC, true);
      box(0.4, 5, 24, 12, 2.5, 0, wallC, true);
      // door gap front - skip full wall, use sides
      // platforms / furniture
      box(4, 0.4, 4, 0, 0.2, -6, accentC, false);
      box(1.5, 1.2, 1.5, -5, 0.6, 4, 0x4a3a70, true);
      box(1.5, 1.2, 1.5, 5, 0.6, 4, 0x4a3a70, true);
      // stage
      box(8, 0.5, 3, 0, 0.25, 8, 0x2a2048, true);
      // neon strips
      for (let i = -3; i <= 3; i++) {
        const n = new THREE.Mesh(
          new THREE.BoxGeometry(0.15, 0.15, 8),
          new THREE.MeshBasicMaterial({ color: accentC })
        );
        n.position.set(i * 2.5, 0.05, 0);
        roomRoot.add(n);
      }
      // floating orbs
      for (let i = 0; i < 6; i++) {
        const o = new THREE.Mesh(
          new THREE.SphereGeometry(0.25, 12, 12),
          new THREE.MeshBasicMaterial({ color: accentC })
        );
        o.position.set((Math.random() - 0.5) * 10, 2 + Math.random() * 2, (Math.random() - 0.5) * 10);
        o.userData.bob = Math.random() * 10;
        roomRoot.add(o);
      }

      // RecBot + buddy NPCs
      makeNpcSafe('RecBot', 0xff6bcb, 2, -4);
      makeNpcSafe('Player2', 0x6c3ce0, -3, 2);
      makeNpcSafe('Squadmate', 0x1ec8c8, 4, 3);

      // room-specific props
      if (room.id === 'paintball') {
        for (let i = 0; i < 8; i++) {
          box(1.2, 1.4, 1.2, (i % 4 - 1.5) * 3, 0.7, (i < 4 ? -2 : 2), 0x2a5030, true);
        }
      }
      if (room.id === 'quest-isle') {
        box(6, 1, 6, 0, 0.5, 0, 0x4a7a30, false);
        const tree = new THREE.Mesh(new THREE.ConeGeometry(1.2, 3, 8), mat(0x2a6a20));
        tree.position.set(-4, 2, -3);
        roomRoot.add(tree);
      }
      if (room.id === 'dance-club' || room.id === 'charades') {
        for (let i = 0; i < 12; i++) {
          const light = new THREE.PointLight(accentC, 0.4, 8, 2);
          light.position.set(Math.sin(i) * 5, 3, Math.cos(i) * 5);
          roomRoot.add(light);
        }
      }

      player.x = 0;
      player.z = 5;
      player.y = 1.5;
      yaw = Math.PI;
      pitch = 0;
    }

    function overlaps(a, b) {
      return a.min.x < b.max.x && a.max.x > b.min.x &&
        a.min.y < b.max.y && a.max.y > b.min.y &&
        a.min.z < b.max.z && a.max.z > b.min.z;
    }
    function tryMove(dx, dz) {
      const r = player.radius;
      const nx = player.x + dx;
      const nz = player.z + dz;
      const boxX = {
        min: new THREE.Vector3(nx - r, 0.4, player.z - r),
        max: new THREE.Vector3(nx + r, 1.7, player.z + r),
      };
      let hit = false;
      for (const c of colliders) {
        if (overlaps(boxX, c)) { hit = true; break; }
      }
      if (!hit) player.x = nx;
      const boxZ = {
        min: new THREE.Vector3(player.x - r, 0.4, nz - r),
        max: new THREE.Vector3(player.x + r, 1.7, nz + r),
      };
      hit = false;
      for (const c of colliders) {
        if (overlaps(boxZ, c)) { hit = true; break; }
      }
      if (!hit) player.z = nz;
      player.x = clamp(player.x, -11, 11);
      player.z = clamp(player.z, -11, 11);
    }

    function resize() {
      const w = canvas.clientWidth || canvas.parentElement.clientWidth || innerWidth;
      const h = canvas.clientHeight || canvas.parentElement.clientHeight || innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
    }

    window.addEventListener('resize', resize);
    canvas.addEventListener('click', () => canvas.requestPointerLock());
    document.addEventListener('pointerlockchange', () => {
      locked = document.pointerLockElement === canvas;
    });
    document.addEventListener('mousemove', (e) => {
      if (!locked) return;
      yaw -= e.movementX * 0.0022;
      pitch -= e.movementY * 0.0022;
      pitch = clamp(pitch, -1.3, 1.3);
    });
    window.addEventListener('keydown', (e) => { keys[e.code] = true; });
    window.addEventListener('keyup', (e) => { keys[e.code] = false; });

    let last = performance.now();
    function frame(now) {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;

      if (locked) {
        const sprint = keys['ShiftLeft'] || keys['ShiftRight'];
        const spd = sprint ? player.sprint : player.speed;
        const fwd = getForward(0, yaw);
        const right = getRight(0, yaw);
        let mx = 0, mz = 0;
        if (keys['KeyW']) { mx += fwd.x; mz += fwd.z; }
        if (keys['KeyS']) { mx -= fwd.x; mz -= fwd.z; }
        if (keys['KeyA']) { mx -= right.x; mz -= right.z; }
        if (keys['KeyD']) { mx += right.x; mz += right.z; }
        const len = Math.hypot(mx, mz);
        if (len > 0) {
          mx /= len; mz /= len;
          tryMove(mx * spd * dt, mz * spd * dt);
        }
      }

      // NPC idle wander
      npcs.forEach((n) => {
        n.t += dt;
        n.mesh.position.x = n.baseX + Math.sin(n.t * 0.7) * 1.2;
        n.mesh.position.z = n.baseZ + Math.cos(n.t * 0.5) * 1.2;
        n.mesh.rotation.y = Math.atan2(
          player.x - n.mesh.position.x,
          player.z - n.mesh.position.z
        );
        if (n.legL) {
          n.legL.rotation.x = Math.sin(n.t * 5) * 0.4;
          n.legR.rotation.x = -Math.sin(n.t * 5) * 0.4;
        }
      });
      // bob orbs
      roomRoot.children.forEach((c) => {
        if (c.userData && c.userData.bob != null) {
          c.position.y = 2 + Math.sin(now * 0.002 + c.userData.bob) * 0.4;
        }
      });

      camera.position.set(player.x, player.y, player.z);
      camera.rotation.x = pitch;
      camera.rotation.y = yaw;
      renderer.render(scene, camera);
      requestAnimationFrame(frame);
    }

    resize();
    requestAnimationFrame(frame);

    return {
      loadRoom,
      resize,
      get locked() { return locked; },
      setPointerLock() { canvas.requestPointerLock(); },
      get keys() { return keys; },
    };
  }

  return { create };
})();
