# Rec Center (Arkhe) — Rec Room–inspired


**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

Browser **Rec Room–style** hangout: 3D rooms, **Rec Room Originals**, custom rooms, text chat, and **voice chat with an AI buddy (RecBot)**.

**Not affiliated with Rec Room / Meta / Against Gravity.**

## Run (required for AI)

```bash
cd projects/creative-visualizers-and-games/rec-room-arkhe

# Optional but recommended — Gemini
export GEMINI_API_KEY="your-key-here"
# or: cp .env.example .env  &&  edit .env

python3 serve.py
```

Open **http://127.0.0.1:8775/**

### API status

| Backend | When |
|---------|------|
| **Gemini** | `GEMINI_API_KEY` or `GOOGLE_API_KEY` in env / `.env`, or paste key in the UI (browser only) |
| **Ollama fallback** | No Gemini key — uses local `gemma4-e2b:latest` if Ollama is running |

**You had not previously stored a Gemini key** in this workspace (only an xAI key was found for other projects). Paste a Gemini key in the right panel or set `GEMINI_API_KEY`.

## Features

- **3D first-person** rooms (WASD + mouse + sprint)
- **Originals:** Rec Center, Charades, Paintball, Quest Isle, Maker Pen Lab
- **Custom rooms** + “Create Room”
- **Room chat** (text)
- **Voice → RecBot:** hold **V** or the pink button (Web Speech API → Gemini/Ollama → TTS)
- Player list, invite link copy, watch-menu style buttons

## Get a Gemini key

1. https://aistudio.google.com/apikey  
2. `export GEMINI_API_KEY=...` then restart `serve.py`  
   **or** paste into the UI field and hit **Save**
