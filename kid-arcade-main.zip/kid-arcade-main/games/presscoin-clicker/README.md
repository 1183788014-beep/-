# Click Me! — Presscoins

Starts pure white. After **5 seconds**, a **click me!** button appears.

**Session:** part of the **2026-07-28 kids arcade** co-design run (family / kids as lead + co-ideators). Public-safe note: `../sessions/2026-07-28-kids-arcade/`. Named family credits stay in gitignored `CREDITS.LOCAL.md` only — **do not put children’s real names on GitHub.**

## Story + loop

1. First click → *Hey, how did you get here?*
2. Then → *Um.. Nevermind. Just keep clicking…*
3. Upgrades shop unlocks under the button
4. **20 clicks** unlocks the **DVD** upgrade (more Presscoins + bouncing DVDs)
5. Spend **Presscoins** on confetti, rainbow, mega button, helper finger, and more

## Run

```bash
cd projects/creative-visualizers-and-games/presscoin-clicker
python3 -m http.server 8785 --bind 127.0.0.1
```

Open **http://127.0.0.1:8785/**
