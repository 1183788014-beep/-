/**
 * Click Me! / Presscoins — kid-friendly clicker
 * Session: 2026-07-28 kids arcade (public-safe credit only)
 */
(function () {
  'use strict';

  const DELAY_MS = 5000;
  const DVD_CLICKS = 20;

  const el = {
    btn: document.getElementById('main-btn'),
    story: document.getElementById('story'),
    upgrades: document.getElementById('upgrades'),
    shop: document.getElementById('shop'),
    hud: document.getElementById('hud'),
    coins: document.getElementById('coins'),
    clicks: document.getElementById('clicks'),
    perClick: document.getElementById('per-click'),
    toast: document.getElementById('toast'),
    dvdLayer: document.getElementById('dvd-layer'),
    world: document.getElementById('world'),
    canvas: document.getElementById('fx'),
    waitHint: document.getElementById('wait-hint'),
  };

  if (!el.btn) {
    console.error('[presscoin] main button missing');
    return;
  }

  const state = {
    phase: 'wait', // wait | ready | first | dialogue | play
    clicks: 0,
    coins: 0,
    basePerClick: 1,
    dvdOwned: false,
    owned: {},
    particles: [],
    dvds: [],
    confetti: false,
    rainbow: false,
    megaBtn: false,
    night: false,
    shake: 0,
  };

  // Shop: unlock after dialogue. DVD requires 20 clicks (story).
  const SHOP = [
    {
      id: 'dvd',
      name: '📀 DVD Upgrade',
      desc: 'Bouncing logo + bonus Presscoins every click!',
      cost: 0,
      clickReq: DVD_CLICKS,
      once: true,
      onBuy() {
        state.dvdOwned = true;
        state.basePerClick += 2;
        spawnDvd();
        el.dvdLayer.classList.remove('hidden');
        toast('DVD unlocked! More Presscoins per click');
      },
    },
    {
      id: 'double',
      name: '✨ Double Click',
      desc: '+3 Presscoins per click (stackable-ish energy)',
      cost: 15,
      once: false,
      max: 5,
      onBuy() {
        state.basePerClick += 3;
        toast('+3 per click!');
      },
    },
    {
      id: 'confetti',
      name: '🎉 Confetti Party',
      desc: 'Every click sprays colorful bits',
      cost: 25,
      once: true,
      onBuy() {
        state.confetti = true;
        toast('Confetti mode ON');
      },
    },
    {
      id: 'rainbow',
      name: '🌈 Rainbow World',
      desc: 'The whole page cycles colors',
      cost: 40,
      once: true,
      onBuy() {
        state.rainbow = true;
        document.body.classList.add('rainbow');
        toast('Rainbow engaged');
      },
    },
    {
      id: 'mega',
      name: '🚀 Mega Button',
      desc: 'Glowy button · +5 per click',
      cost: 60,
      once: true,
      onBuy() {
        state.megaBtn = true;
        state.basePerClick += 5;
        el.btn.classList.add('mega');
        toast('MEGA button!');
      },
    },
    {
      id: 'night',
      name: '🌙 Soft Night',
      desc: 'Dark cozy mode (still fun)',
      cost: 20,
      once: true,
      onBuy() {
        state.night = true;
        el.world.classList.add('soft-night');
        toast('Lights down…');
      },
    },
    {
      id: 'multidvd',
      name: '📀📀 Extra DVDs',
      desc: 'More bouncing logos · +2 per click',
      cost: 50,
      once: false,
      max: 4,
      needs: 'dvd',
      onBuy() {
        state.basePerClick += 2;
        spawnDvd();
        toast('Another DVD!');
      },
    },
    {
      id: 'jackpot',
      name: '💰 Lucky Jackpot',
      desc: '10% chance for 10× coins on a click',
      cost: 80,
      once: true,
      onBuy() {
        state.owned.jackpot = true;
        toast('Feeling lucky…');
      },
    },
    {
      id: 'autoclick',
      name: '🤖 Helper Finger',
      desc: 'Auto-clicks once per second',
      cost: 120,
      once: true,
      onBuy() {
        setInterval(() => {
          if (state.phase === 'play') doClick(true);
        }, 1000);
        toast('Helper finger hired');
      },
    },
  ];

  function perClick() {
    let n = state.basePerClick;
    if (state.dvdOwned) n += 0; // already in basePerClick
    return n;
  }

  function toast(msg) {
    el.toast.classList.remove('hidden');
    el.toast.textContent = msg;
    el.toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => {
      el.toast.classList.remove('show');
    }, 2200);
  }

  function updateHud() {
    el.coins.textContent = Math.floor(state.coins);
    el.clicks.textContent = state.clicks;
    el.perClick.textContent = perClick();
    renderShop();
  }

  function setStory(html, show) {
    el.story.innerHTML = html;
    if (show) el.story.classList.add('show');
    else el.story.classList.remove('show');
  }

  function wait(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  async function firstClickSequence() {
    state.phase = 'dialogue';
    el.btn.disabled = true;
    el.hud.classList.remove('hidden');

    setStory('<span class="line">Hey, how did you get here?</span>', true);
    await wait(2200);

    setStory(
      '<span class="line">Hey, how did you get here?</span>' +
        '<span class="line whisper">Um.. Nevermind. Just keep clicking the button to get more fun upgrades.</span>',
      true
    );
    await wait(2800);

    el.upgrades.classList.remove('hidden');
    requestAnimationFrame(() => el.upgrades.classList.add('show'));
    state.phase = 'play';
    el.btn.disabled = false;
    toast('Upgrades unlocked — keep clicking!');
    updateHud();
  }

  function doClick(isAuto) {
    if (state.phase === 'ready') {
      state.phase = 'first';
      state.clicks = 1;
      state.coins += 1;
      popBtn();
      burst(el.btn);
      updateHud();
      firstClickSequence();
      return;
    }
    if (state.phase !== 'play') return;

    state.clicks += 1;
    let gain = perClick();
    if (state.owned.jackpot && Math.random() < 0.1) {
      gain *= 10;
      if (!isAuto) toast('JACKPOT ×10!');
    }
    state.coins += gain;
    if (!isAuto) {
      popBtn();
      burst(el.btn);
    }
    if (state.confetti) confettiBurst();
    if (state.clicks === DVD_CLICKS && !state.dvdOwned) {
      toast('20 clicks! DVD upgrade is ready in the shop ↓');
    }
    updateHud();
  }

  function popBtn() {
    el.btn.classList.remove('pop');
    void el.btn.offsetWidth;
    el.btn.classList.add('pop');
  }

  function canBuy(item) {
    if (item.needs && !state.owned[item.needs] && !(item.needs === 'dvd' && state.dvdOwned)) {
      return false;
    }
    if (item.clickReq && state.clicks < item.clickReq) return false;
    if (item.once && state.owned[item.id]) return false;
    if (item.max && (state.owned[item.id] || 0) >= item.max) return false;
    if (item.cost > state.coins) return false;
    return true;
  }

  function buy(item) {
    if (!canBuy(item)) return;
    state.coins -= item.cost;
    if (item.once) state.owned[item.id] = true;
    else state.owned[item.id] = (state.owned[item.id] || 0) + 1;
    if (item.id === 'dvd') state.owned.dvd = true;
    item.onBuy();
    updateHud();
  }

  function renderShop() {
    el.shop.innerHTML = SHOP.map((item) => {
      const ownedCount = state.owned[item.id] || 0;
      const fullyOwned = item.once
        ? !!state.owned[item.id] || (item.id === 'dvd' && state.dvdOwned)
        : item.max && ownedCount >= item.max;
      const lockedClick = item.clickReq && state.clicks < item.clickReq;
      const lockedNeed =
        item.needs && !state.owned[item.needs] && !(item.needs === 'dvd' && state.dvdOwned);
      const locked = lockedClick || lockedNeed;
      const affordable = !fullyOwned && !locked && state.coins >= item.cost;

      let req = '';
      if (lockedClick) req = `Need ${item.clickReq} clicks (${state.clicks}/${item.clickReq})`;
      else if (lockedNeed) req = 'Needs DVD first';
      else if (item.max && !item.once) req = `Owned ${ownedCount}/${item.max}`;

      let priceLabel = item.cost === 0 && item.clickReq ? 'FREE after 20 clicks' : `${item.cost} ¢`;
      if (fullyOwned) priceLabel = 'Owned ✓';

      const classes = [
        'card',
        fullyOwned ? 'owned' : '',
        locked ? 'locked' : '',
        affordable ? 'affordable' : '',
      ]
        .filter(Boolean)
        .join(' ');

      return `
        <article class="${classes}" data-id="${item.id}">
          <h3>${item.name}${!item.once && ownedCount ? ` ×${ownedCount}` : ''}</h3>
          <button type="button" class="buy ${fullyOwned ? 'owned-label' : ''}" data-buy="${item.id}"
            ${fullyOwned || locked || state.coins < item.cost ? 'disabled' : ''}>
            ${priceLabel}
          </button>
          <p>${item.desc}</p>
          ${req ? `<div class="req">${req}</div>` : '<div class="req"></div>'}
        </article>`;
    }).join('');

    el.shop.querySelectorAll('[data-buy]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const item = SHOP.find((s) => s.id === btn.dataset.buy);
        if (item) buy(item);
      });
    });
  }

  /* ----- DVD bounce ----- */
  function spawnDvd() {
    const colors = ['#ff2d55', '#5b8cff', '#30d158', '#ffd60a', '#bf5af2', '#ff9f0a'];
    const d = document.createElement('div');
    d.className = 'dvd';
    d.textContent = 'DVD';
    d.style.color = colors[state.dvds.length % colors.length];
    const node = {
      el: d,
      x: 40 + Math.random() * 200,
      y: 40 + Math.random() * 120,
      vx: (2 + Math.random() * 2) * (Math.random() < 0.5 ? 1 : -1),
      vy: (2 + Math.random() * 2) * (Math.random() < 0.5 ? 1 : -1),
    };
    el.dvdLayer.appendChild(d);
    state.dvds.push(node);
  }

  function tickDvds() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    state.dvds.forEach((d) => {
      d.x += d.vx;
      d.y += d.vy;
      const bw = d.el.offsetWidth || 60;
      const bh = d.el.offsetHeight || 30;
      if (d.x <= 0) {
        d.x = 0;
        d.vx = Math.abs(d.vx);
        d.el.style.color = randomColor();
      }
      if (d.y <= 0) {
        d.y = 0;
        d.vy = Math.abs(d.vy);
        d.el.style.color = randomColor();
      }
      if (d.x + bw >= w) {
        d.x = w - bw;
        d.vx = -Math.abs(d.vx);
        d.el.style.color = randomColor();
      }
      if (d.y + bh >= h) {
        d.y = h - bh;
        d.vy = -Math.abs(d.vy);
        d.el.style.color = randomColor();
      }
      d.el.style.transform = `translate(${d.x}px, ${d.y}px)`;
    });
  }

  function randomColor() {
    const c = ['#ff2d55', '#5b8cff', '#30d158', '#ffd60a', '#bf5af2', '#ff9f0a', '#64d2ff'];
    return c[(Math.random() * c.length) | 0];
  }

  /* ----- particles / confetti ----- */
  const ctx = el.canvas ? el.canvas.getContext('2d') : null;
  function resize() {
    if (!el.canvas) return;
    el.canvas.width = window.innerWidth;
    el.canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();

  function burst(button) {
    const r = button.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    for (let i = 0; i < 14; i++) {
      const a = (Math.PI * 2 * i) / 14 + Math.random() * 0.3;
      const sp = 2 + Math.random() * 5;
      state.particles.push({
        x: cx,
        y: cy,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 1,
        life: 1,
        color: randomColor(),
        r: 3 + Math.random() * 3,
      });
    }
  }

  function confettiBurst() {
    for (let i = 0; i < 18; i++) {
      state.particles.push({
        x: Math.random() * el.canvas.width,
        y: -10,
        vx: (Math.random() - 0.5) * 4,
        vy: 2 + Math.random() * 4,
        life: 1,
        color: randomColor(),
        r: 2 + Math.random() * 4,
        confetti: true,
      });
    }
  }

  function tickParticles() {
    if (!ctx || !el.canvas) return;
    ctx.clearRect(0, 0, el.canvas.width, el.canvas.height);
    state.particles = state.particles.filter((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.12;
      p.life -= 0.02;
      if (p.life <= 0) return false;
      ctx.globalAlpha = Math.max(0, p.life);
      ctx.fillStyle = p.color;
      if (p.confetti) {
        ctx.fillRect(p.x, p.y, p.r * 2, p.r);
      } else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      return true;
    });
    ctx.globalAlpha = 1;
  }

  function loop() {
    tickDvds();
    tickParticles();
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  /* ----- boot ----- */
  function showButton() {
    state.phase = 'ready';
    if (el.waitHint) el.waitHint.classList.add('gone');
    el.btn.classList.remove('hidden');
    el.btn.classList.add('visible');
    el.btn.disabled = false;
    el.btn.style.display = 'inline-block';
    el.btn.style.background = '#0a84ff';
    el.btn.style.color = '#ffffff';
    el.btn.style.opacity = '1';
    el.btn.removeAttribute('disabled');
  }

  el.btn.addEventListener('click', (e) => {
    e.preventDefault();
    doClick(false);
  });

  // White screen… then bright blue button
  setTimeout(showButton, DELAY_MS);
  // Safety: if something blocked the timer, still show after 6s
  setTimeout(() => {
    if (state.phase === 'wait') showButton();
  }, DELAY_MS + 1000);
})();
