# Origin / fork map

Public pack paths → **canon** paths on the workstation.  
Canon is for local / family experiments. **Do not edit canon solely to ship public** — copy into this pack and clean here.

| Public path | Canon path (local; may differ) | Public deltas (summary) |
|-------------|--------------------------------|-------------------------|
| `apps/phone-simulator/` | `projects/creative-visualizers-and-games/phone-simulator/` | Static Pages shell; Messages → chat presets (not required `serve.py` + Ollama); game deep-links → relative `apps/*` / sibling paths; no family-only ports as sole launch path |
| `apps/mac-simulator/` | `projects/creative-visualizers-and-games/mac-simulator/` | Same pattern: static shell, preset Messages, relative Games launcher; Dock toys that need private backends stay disabled or stubbed |
| `apps/i-am-bird/` | `projects/creative-visualizers-and-games/i-am-bird-arkhe/` | Blood / gore juice → stars / soft hit VFX; family-safe copy; static-only |
| `apps/i-am-monkey/` | `projects/creative-visualizers-and-games/i-am-monkey-arkhe/` | Blood assets / gore juice → stars / sparks; elephant chat → `shared/chat-presets.js` + `elephant.json`; optional Ollama only via window flags |
| `shared/chat-presets.js` | *(new for public; inspired by local Gemma Messages / pet chat)* | Pages-first offline brain; keyword + fallback personas |
| `shared/chat-presets/*.json` | *(new packs; tone inspired by local personas)* | elephant, kinito, chonks, bossbot, mom, assistant, siri — no model weights, no API keys |
| `shared/mobile-controls.js` + `.css` | *(new for public)* | Touch stick + buttons + desktop keyboard merge for games |
| `index.html` | *(lobby; public-only)* | Emulators / Games / About navigation for Pages visitors |

## Rules

1. **Canon remains experimental.** Local Ollama, blood juice, LAN ports, Electron wrappers, etc. may stay there.  
2. **Public copies may remove or replace** gore, server deps, and non-portable links.  
3. When adding a public app, **add a row here** in the same PR/change set as the lobby card.  
4. If public and canon diverge heavily, note the delta in the app’s own `README.md` (public-safe language only).  
5. **Never** put children’s real names, ages, location, or tokens in this map or linked public files.

## Status snapshot

| Public app | In pack |
|------------|---------|
| **Mac standalone** (`mac/`) | Yes — Pages root experience; games open in-window |
| Phone Simulator | Yes — Arcade lists full `games/` catalog |
| Games folder | Yes — 16 titles under `games/` |
| Shared chat presets | Yes — elephant, kinito, chonks, bossbot, mom, assistant, siri |

### Games under `games/`

bloxy-classic, i-am-bird, i-am-monkey, i-am-cat, job-sim, life-day-sim, minecraft-grass, presscoin-clicker, pixel-noob-player, pixl-singing-monsters, roblox-2016-web, kinito-pixel-pet, verity-3am-knock, ai-city-collapse, bloxy-multiplayer, rec-room.

**Mac Pages URL:** deploy / open `mac/` so the site boots straight into the desktop.
