# Mac Simulator

**Kid-made · family co-design · Grok Build**

Browser **macOS-inspired** desktop. Opens straight into the **Games** library.  
Every title plays **inside** a Mac window. Messages uses offline chat presets.

| | |
|--|--|
| **Play** | https://ai-fam-coders.github.io/mac-simulator/ |
| **Full arcade lobby** | https://ai-fam-coders.github.io/kid-arcade/ |
| **Source** | https://github.com/AI-Fam-Coders/mac-simulator |

Not affiliated with Apple.

## Features

- Boot → **Games** library (click a title to play in-window)
- Finder defaults to **Games** folder (no dead Recents)
- Dock: Games, Finder, Messages, Safari, …
- Messages: Kinito, Desk Chonks, BossBot, Assistant — **offline presets**
- Touch / compact layout on phones and iPads

## Privacy

No real names, ages, or location. Credit: **the kids** · **family co-design**.

## Local

```bash
python3 -m http.server 8801 --bind 127.0.0.1
# open http://127.0.0.1:8801/
```

This folder is self-contained (`index.html` + `games/` + `shared/`).

## Optional Ollama (advanced)

```js
window.KID_ARCADE_OLLAMA_URL = 'http://127.0.0.1:11434';
window.KID_ARCADE_PREFER_OLLAMA = true;
```

Default remains presets so anyone can play.
