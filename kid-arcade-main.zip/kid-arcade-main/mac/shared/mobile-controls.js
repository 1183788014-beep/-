/**
 * KidArcadeControls — shared mobile + desktop input kit (static Pages).
 * Left stick, right-drag look, action buttons, keyboard merge.
 */
(function (global) {
  'use strict';

  const CSS_HREF_CANDIDATES = [
    '../../shared/mobile-controls.css',
    '../shared/mobile-controls.css',
    'shared/mobile-controls.css',
    '/shared/mobile-controls.css',
  ];

  let mounted = false;
  let opts = {};
  let root = null;
  let stickEl = null;
  let knobEl = null;
  let lookEl = null;
  let actionsEl = null;
  let visible = false;
  let forceVisible = false;
  let touchMode = false;

  // Continuous axes
  let stickX = 0;
  let stickY = 0; // screen: up = -1 preferred for "forward feel"; we map in getState
  let lookDx = 0;
  let lookDy = 0;

  // Keys + actions
  const keys = Object.create(null);
  const held = Object.create(null); // action id → bool
  const edge = Object.create(null); // action id → true until read

  // Stick tracking
  let stickPointerId = null;
  let stickCx = 0;
  let stickCy = 0;
  let stickRadius = 48;

  // Look tracking
  let lookPointerId = null;
  let lookLastX = 0;
  let lookLastY = 0;
  let lookActive = false;

  // Chat focus → disable look drag
  let chatFocused = false;
  let focusHandler = null;
  let blurHandler = null;
  let mqHandler = null;

  function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
  }

  function isEditable(el) {
    if (!el || el === document.body) return false;
    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
    if (el.isContentEditable) return true;
    return false;
  }

  function detectTouchMode() {
    try {
      if (opts.force) return true;
      if (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0) return true;
      if ('ontouchstart' in global) return true;
      if (global.matchMedia) {
        if (matchMedia('(pointer: coarse)').matches) return true;
        if (matchMedia('(max-width: 900px)').matches) return true;
      }
    } catch (_) {
      /* ignore */
    }
    return false;
  }

  function ensureCss() {
    if (document.getElementById('kid-arcade-controls-css')) return;
    const link = document.createElement('link');
    link.id = 'kid-arcade-controls-css';
    link.rel = 'stylesheet';
    // Prefer path relative to this script
    let href = CSS_HREF_CANDIDATES[0];
    try {
      if (document.currentScript && document.currentScript.src) {
        href = document.currentScript.src.replace(/\/[^/]*$/, '/mobile-controls.css');
      }
    } catch (_) {
      /* fall through */
    }
    link.href = href;
    document.head.appendChild(link);
    // Fallback inject if link 404s later — also inject minimal critical CSS inline
    if (!document.getElementById('kid-arcade-controls-inline')) {
      const s = document.createElement('style');
      s.id = 'kid-arcade-controls-inline';
      s.textContent =
        '#kid-arcade-controls{position:fixed;inset:0;z-index:15;pointer-events:none;touch-action:none}' +
        '#kid-arcade-controls.kac-hidden{display:none!important}' +
        '#kac-look{position:absolute;top:0;right:0;width:55%;height:70%;pointer-events:auto;touch-action:none}' +
        '#kac-look.kac-look-off{pointer-events:none}' +
        '#kac-stick{position:absolute;left:12px;bottom:18px;width:128px;height:128px;pointer-events:auto;touch-action:none}' +
        '#kac-stick-base{position:absolute;inset:0;border-radius:50%;background:rgba(12,16,28,.42);border:2px solid rgba(255,255,255,.28)}' +
        '#kac-stick-knob{position:absolute;left:50%;top:50%;width:54px;height:54px;margin:-27px 0 0 -27px;border-radius:50%;background:rgba(255,255,255,.38);border:2px solid rgba(255,255,255,.55)}' +
        '#kac-actions{position:absolute;right:10px;bottom:16px;display:flex;flex-wrap:wrap-reverse;justify-content:flex-end;gap:10px;max-width:48vw;pointer-events:auto}' +
        '.kac-btn{min-width:64px;min-height:64px;border-radius:50%;border:2px solid rgba(255,255,255,.35);background:rgba(16,22,36,.55);color:#fff;font:800 12px system-ui;cursor:pointer;touch-action:none}' +
        'canvas#c{touch-action:none}';
      document.head.appendChild(s);
    }
  }

  function buildDom() {
    root = document.createElement('div');
    root.id = 'kid-arcade-controls';
    root.className = 'kac-hidden';
    root.setAttribute('aria-hidden', 'true');

    lookEl = document.createElement('div');
    lookEl.id = 'kac-look';
    lookEl.setAttribute('aria-label', 'Look drag');

    stickEl = document.createElement('div');
    stickEl.id = 'kac-stick';
    const base = document.createElement('div');
    base.id = 'kac-stick-base';
    knobEl = document.createElement('div');
    knobEl.id = 'kac-stick-knob';
    stickEl.appendChild(base);
    stickEl.appendChild(knobEl);

    actionsEl = document.createElement('div');
    actionsEl.id = 'kac-actions';

    const actions = opts.actions || [];
    actions.forEach((a) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'kac-btn' + (a.small ? ' kac-sm' : '');
      btn.dataset.id = a.id;
      btn.textContent = a.label || a.id;
      if (a.title) btn.title = a.title;
      bindActionButton(btn, a.id);
      actionsEl.appendChild(btn);
    });

    root.appendChild(lookEl);
    root.appendChild(stickEl);
    root.appendChild(actionsEl);

    const parent = opts.parent || document.body;
    parent.appendChild(root);
  }

  function setKnob(nx, ny) {
    // nx,ny in [-1,1]; visual offset within stick
    const max = stickRadius * 0.72;
    knobEl.style.transform = 'translate(' + nx * max + 'px,' + ny * max + 'px)';
  }

  function resetStick() {
    stickPointerId = null;
    stickX = 0;
    stickY = 0;
    setKnob(0, 0);
  }

  function updateStickFromPoint(clientX, clientY) {
    const dx = clientX - stickCx;
    const dy = clientY - stickCy;
    const len = Math.hypot(dx, dy) || 1;
    const capped = Math.min(len, stickRadius) / stickRadius;
    const nx = (dx / len) * capped;
    const ny = (dy / len) * capped;
    stickX = nx;
    stickY = ny;
    setKnob(nx, ny);
  }

  function onStickDown(e) {
    if (e.button != null && e.button !== 0) return;
    e.preventDefault();
    e.stopPropagation();
    const t = e.changedTouches ? e.changedTouches[0] : e;
    const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
    if (stickPointerId != null && stickPointerId !== id) return;
    stickPointerId = id;
    const rect = stickEl.getBoundingClientRect();
    stickCx = rect.left + rect.width / 2;
    stickCy = rect.top + rect.height / 2;
    stickRadius = Math.min(rect.width, rect.height) * 0.42;
    updateStickFromPoint(t.clientX, t.clientY);
    if (stickEl.setPointerCapture && e.pointerId != null) {
      try {
        stickEl.setPointerCapture(e.pointerId);
      } catch (_) {
        /* ignore */
      }
    }
  }

  function onStickMove(e) {
    if (stickPointerId == null) return;
    const list = e.changedTouches || [e];
    for (let i = 0; i < list.length; i++) {
      const t = list[i];
      const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
      if (id !== stickPointerId && stickPointerId !== 'mouse') continue;
      e.preventDefault();
      updateStickFromPoint(t.clientX, t.clientY);
      break;
    }
  }

  function onStickUp(e) {
    if (stickPointerId == null) return;
    const list = e.changedTouches || [e];
    for (let i = 0; i < list.length; i++) {
      const t = list[i];
      const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
      if (id === stickPointerId || stickPointerId === 'mouse') {
        resetStick();
        break;
      }
    }
  }

  function bindStick() {
    // Prefer pointer events; touch fallback for older WebViews
    stickEl.addEventListener('pointerdown', onStickDown);
    stickEl.addEventListener('pointermove', onStickMove);
    stickEl.addEventListener('pointerup', onStickUp);
    stickEl.addEventListener('pointercancel', onStickUp);
    stickEl.addEventListener('touchstart', onStickDown, { passive: false });
    stickEl.addEventListener('touchmove', onStickMove, { passive: false });
    stickEl.addEventListener('touchend', onStickUp, { passive: false });
    stickEl.addEventListener('touchcancel', onStickUp, { passive: false });
  }

  function onLookDown(e) {
    if (chatFocused || !visible) return;
    if (e.target && (e.target.closest && (e.target.closest('.kac-btn') || e.target.closest('#kac-stick')))) return;
    if (e.button != null && e.button !== 0) return;
    // Don't steal if clicking editable / chat
    if (isEditable(e.target)) return;
    e.preventDefault();
    const t = e.changedTouches ? e.changedTouches[0] : e;
    const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
    lookPointerId = id;
    lookLastX = t.clientX;
    lookLastY = t.clientY;
    lookActive = true;
    if (lookEl.setPointerCapture && e.pointerId != null) {
      try {
        lookEl.setPointerCapture(e.pointerId);
      } catch (_) {
        /* ignore */
      }
    }
  }

  function onLookMove(e) {
    if (!lookActive || chatFocused) return;
    const list = e.changedTouches || [e];
    for (let i = 0; i < list.length; i++) {
      const t = list[i];
      const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
      if (id !== lookPointerId && lookPointerId !== 'mouse') continue;
      e.preventDefault();
      const sens = opts.lookSensitivity != null ? opts.lookSensitivity : 1;
      lookDx += (t.clientX - lookLastX) * sens;
      lookDy += (t.clientY - lookLastY) * sens;
      lookLastX = t.clientX;
      lookLastY = t.clientY;
      break;
    }
  }

  function onLookUp(e) {
    if (!lookActive) return;
    const list = e.changedTouches || [e];
    for (let i = 0; i < list.length; i++) {
      const t = list[i];
      const id = t.pointerId != null ? t.pointerId : t.identifier != null ? t.identifier : 'mouse';
      if (id === lookPointerId || lookPointerId === 'mouse') {
        lookActive = false;
        lookPointerId = null;
        break;
      }
    }
  }

  function bindLook() {
    lookEl.addEventListener('pointerdown', onLookDown);
    lookEl.addEventListener('pointermove', onLookMove);
    lookEl.addEventListener('pointerup', onLookUp);
    lookEl.addEventListener('pointercancel', onLookUp);
    lookEl.addEventListener('touchstart', onLookDown, { passive: false });
    lookEl.addEventListener('touchmove', onLookMove, { passive: false });
    lookEl.addEventListener('touchend', onLookUp, { passive: false });
    lookEl.addEventListener('touchcancel', onLookUp, { passive: false });
  }

  function hasAction(id) {
    const acts = opts.actions || [];
    for (let i = 0; i < acts.length; i++) {
      if (acts[i] && acts[i].id === id) return true;
    }
    return false;
  }

  function pressAction(id) {
    held[id] = true;
    edge[id] = true;
    const btn = actionsEl && actionsEl.querySelector('[data-id="' + id + '"]');
    if (btn) btn.classList.add('kac-down');
    if (typeof opts.onAction === 'function') {
      try {
        opts.onAction(id, true);
      } catch (_) {
        /* game bug */
      }
    }
  }

  function releaseAction(id) {
    held[id] = false;
    const btn = actionsEl && actionsEl.querySelector('[data-id="' + id + '"]');
    if (btn) btn.classList.remove('kac-down');
    if (typeof opts.onAction === 'function') {
      try {
        opts.onAction(id, false);
      } catch (_) {
        /* game bug */
      }
    }
  }

  function bindActionButton(btn, id) {
    const down = (e) => {
      e.preventDefault();
      e.stopPropagation();
      pressAction(id);
      if (btn.setPointerCapture && e.pointerId != null) {
        try {
          btn.setPointerCapture(e.pointerId);
        } catch (_) {
          /* ignore */
        }
      }
    };
    const up = (e) => {
      e.preventDefault();
      e.stopPropagation();
      releaseAction(id);
    };
    btn.addEventListener('pointerdown', down);
    btn.addEventListener('pointerup', up);
    btn.addEventListener('pointercancel', up);
    btn.addEventListener('pointerleave', (e) => {
      if (held[id]) releaseAction(id);
    });
    // Prevent context menu on long-press
    btn.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  function onKeyDown(e) {
    if (isEditable(e.target)) return;
    keys[e.code] = true;
    // Map common keys → action edges for pollers
    if (e.code === 'Space') {
      e.preventDefault();
      if (!held.jump) pressAction('jump');
    }
    if (e.code === 'KeyF') {
      // Prefer punch if that button exists, else primary
      if (hasAction('punch')) {
        if (!held.punch) pressAction('punch');
      } else if (!held.primary) {
        pressAction('primary');
      }
    }
    if (e.code === 'KeyP') {
      if (hasAction('poop')) {
        if (!held.poop) pressAction('poop');
      } else if (!held.secondary) {
        pressAction('secondary');
      }
    }
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
      if (hasAction('boost')) {
        if (!held.boost) pressAction('boost');
      } else if (hasAction('fly')) {
        if (!held.fly) pressAction('fly');
      } else if (!held.boost) {
        pressAction('boost');
      }
    }
    if (e.code === 'KeyV') {
      if (!held.grab) pressAction('grab');
    }
    if (e.code === 'KeyQ') {
      if (!held.up) pressAction('up');
    }
    if (e.code === 'KeyE' && !(opts.reserveKeyE)) {
      if (!held.down) pressAction('down');
    }
  }

  function onKeyUp(e) {
    keys[e.code] = false;
    if (e.code === 'Space') releaseAction('jump');
    if (e.code === 'KeyF') {
      if (held.punch) releaseAction('punch');
      if (held.primary) releaseAction('primary');
    }
    if (e.code === 'KeyP') {
      if (held.poop) releaseAction('poop');
      if (held.secondary) releaseAction('secondary');
    }
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
      if (!keys.ShiftLeft && !keys.ShiftRight) {
        if (held.boost) releaseAction('boost');
        if (held.fly) releaseAction('fly');
      }
    }
    if (e.code === 'KeyV') releaseAction('grab');
    if (e.code === 'KeyQ') releaseAction('up');
    if (e.code === 'KeyE' && !(opts.reserveKeyE)) releaseAction('down');
  }

  function bindKeyboard() {
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
  }

  function unbindKeyboard() {
    window.removeEventListener('keydown', onKeyDown);
    window.removeEventListener('keyup', onKeyUp);
  }

  function updateChatFocus() {
    chatFocused = isEditable(document.activeElement);
    if (lookEl) {
      lookEl.classList.toggle('kac-look-off', chatFocused);
    }
    if (chatFocused) {
      lookActive = false;
      lookPointerId = null;
    }
  }

  function bindFocusWatch() {
    focusHandler = () => updateChatFocus();
    blurHandler = () => setTimeout(updateChatFocus, 0);
    document.addEventListener('focusin', focusHandler, true);
    document.addEventListener('focusout', blurHandler, true);
  }

  function unbindFocusWatch() {
    if (focusHandler) document.removeEventListener('focusin', focusHandler, true);
    if (blurHandler) document.removeEventListener('focusout', blurHandler, true);
    focusHandler = blurHandler = null;
  }

  function refreshMode() {
    touchMode = detectTouchMode();
    if (forceVisible || touchMode) setVisible(true);
    else if (!opts.alwaysShow) setVisible(false);
  }

  function setVisible(v) {
    visible = !!v;
    if (!root) return;
    root.classList.toggle('kac-hidden', !visible);
    root.setAttribute('aria-hidden', visible ? 'false' : 'true');
  }

  function getState() {
    // move: stick + keys. Convention for games:
    // moveX: -1 left … +1 right (strafe)
    // moveZ: -1 forward … +1 back (matches Three.js camera forward often -Z)
    let moveX = stickX;
    let moveZ = stickY; // stick down (+Y screen) = back (+Z wish)
    // Invert Y so stick up = forward (-Z)
    moveZ = stickY; // raw stickY: up is negative in screen coords when we set ny = dy/len
    // stickY is negative when dragging up → we want forward = negative moveZ
    // so moveZ = stickY already (up → neg → forward). Good.

    if (keys.KeyA || keys.ArrowLeft) moveX -= 1;
    if (keys.KeyD || keys.ArrowRight) moveX += 1;
    if (keys.KeyW || keys.ArrowUp) moveZ -= 1;
    if (keys.KeyS || keys.ArrowDown) moveZ += 1;

    // clamp magnitude to 1 for stick+key combo
    moveX = clamp(moveX, -1, 1);
    moveZ = clamp(moveZ, -1, 1);
    const mlen = Math.hypot(moveX, moveZ);
    if (mlen > 1) {
      moveX /= mlen;
      moveZ /= mlen;
    }

    const dx = lookDx;
    const dy = lookDy;
    lookDx = 0;
    lookDy = 0;

    // Snapshot edges then clear
    const just = Object.create(null);
    for (const k of Object.keys(edge)) {
      if (edge[k]) {
        just[k] = true;
        edge[k] = false;
      }
    }

    return {
      moveX: moveX,
      moveZ: moveZ,
      lookDx: dx,
      lookDy: dy,
      jump: !!(held.jump || keys.Space),
      punch: !!(held.punch || held.primary || keys.KeyF),
      primary: !!(held.primary || held.punch || keys.KeyF),
      secondary: !!(held.secondary || held.poop || keys.KeyP),
      boost: !!(held.boost || held.fly || keys.ShiftLeft || keys.ShiftRight),
      fly: !!(held.fly || held.boost || keys.ShiftLeft || keys.ShiftRight),
      grab: !!(held.grab || keys.KeyV),
      up: !!(held.up || keys.KeyQ),
      down: !!(held.down || (keys.KeyE && !opts.reserveKeyE)),
      keys: keys,
      held: held,
      just: just,
      chatFocused: chatFocused,
    };
  }

  function destroy() {
    if (!mounted) return;
    unbindKeyboard();
    unbindFocusWatch();
    if (mqHandler && global.matchMedia) {
      try {
        matchMedia('(pointer: coarse)').removeEventListener('change', mqHandler);
        matchMedia('(max-width: 900px)').removeEventListener('change', mqHandler);
      } catch (_) {
        /* older Safari */
      }
    }
    mqHandler = null;
    if (root && root.parentNode) root.parentNode.removeChild(root);
    root = stickEl = knobEl = lookEl = actionsEl = null;
    stickPointerId = null;
    lookPointerId = null;
    stickX = stickY = lookDx = lookDy = 0;
    for (const k of Object.keys(keys)) delete keys[k];
    for (const k of Object.keys(held)) delete held[k];
    for (const k of Object.keys(edge)) delete edge[k];
    mounted = false;
    visible = false;
  }

  function mount(options) {
    if (mounted) destroy();
    opts = options || {};
    forceVisible = !!opts.force || !!opts.alwaysShow;
    ensureCss();
    buildDom();
    bindStick();
    bindLook();
    bindKeyboard();
    bindFocusWatch();
    mounted = true;

    touchMode = detectTouchMode();
    if (forceVisible || touchMode || opts.alwaysShow) setVisible(true);
    else setVisible(false);

    // React to orientation / coarse pointer changes
    mqHandler = () => refreshMode();
    try {
      if (global.matchMedia) {
        matchMedia('(pointer: coarse)').addEventListener('change', mqHandler);
        matchMedia('(max-width: 900px)').addEventListener('change', mqHandler);
      }
    } catch (_) {
      /* ignore */
    }

    updateChatFocus();
    return api;
  }

  function isTouchMode() {
    return touchMode || detectTouchMode();
  }

  /** Soft pointer-lock helper: no-ops safely on touch / unsupported. */
  function tryPointerLock(el) {
    if (isTouchMode()) return false;
    if (!el || !el.requestPointerLock) return false;
    try {
      const p = el.requestPointerLock();
      if (p && typeof p.catch === 'function') p.catch(function () {});
      return true;
    } catch (_) {
      return false;
    }
  }

  const api = {
    mount: mount,
    getState: getState,
    destroy: destroy,
    setVisible: setVisible,
    isTouchMode: isTouchMode,
    tryPointerLock: tryPointerLock,
  };

  global.KidArcadeControls = api;
})(typeof window !== 'undefined' ? window : this);
