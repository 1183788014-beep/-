# Chat presets (Pages-friendly)

Static **persona packs** for Phone/Mac Messages and games. No Ollama required.

## Layout

```
shared/
  chat-presets.js          # KidArcadeChat API
  chat-presets/
    elephant.json
    kinito.json
    chonks.json
    bossbot.json
    mom.json
    assistant.json
    siri.json              # Mac sim contact id (assistant-like)
    README.md
```

## JSON shape

```json
{
  "persona": "kinito",
  "name": "Kinito",
  "system": "short kid-safe system line for optional Ollama",
  "fallback": ["…", "…"],
  "keywords": {
    "hello|hi|hey": ["…", "…"],
    "game|play|fun": ["…", "…"]
  }
}
```

| Field | Notes |
|-------|--------|
| `persona` | id (filename without `.json`) |
| `name` | Display name |
| `system` | Used only if optional Ollama is enabled |
| `fallback` | ≥8 short lines; random when no keyword hits |
| `keywords` | Regex alternation keys; each value ≥2 reply strings |

**Tone:** playful, kid-safe, 1–3 sentences, **no markdown** in replies, no real names/ages/locations.

## API (`KidArcadeChat`)

```js
// Primary
await KidArcadeChat.chat({ persona: 'kinito', message: 'hi', history: [] });
// → { ok: true, reply: '…', model: 'preset:kinito', contact: 'kinito' }

await KidArcadeChat.loadPersona('chonks'); // caches pack JSON
KidArcadeChat.listPersonas();              // ['elephant','kinito',…]
KidArcadeChat.replySync('kinito', 'hi');   // sync match if pack already loaded, else null
```

Script tag (from an app under `apps/<name>/`):

```html
<script src="../../shared/chat-presets.js"></script>
```

Path resolution tries the script directory first, then relative paths from the page URL so **GitHub Pages project sites** (`/owner/repo/...`) work without hard-coded origin roots.

## Optional Ollama (devs / local only)

**Default for strangers:** always presets (instant, offline).

To prefer local Gemma/Ollama when available:

```js
window.KID_ARCADE_OLLAMA_URL = 'http://127.0.0.1:11434';
window.KID_ARCADE_PREFER_OLLAMA = true;          // required — URL alone is not enough
window.KID_ARCADE_OLLAMA_MODEL = 'gemma4-e2b:latest'; // optional
```

If prefer-Ollama is set and the request fails, presets are used. Never throws.

## Add a persona

1. Copy an existing JSON file in this folder.
2. Set `persona` to the new id (lowercase, `a-z0-9_-`).
3. Write ≥8 `fallback` lines and ≥8 `keywords` patterns (2+ replies each).
4. Add the id to `PERSONA_IDS` in `../chat-presets.js`.
5. Call `KidArcadeChat.chat({ persona: 'your-id', message })` from the UI.

## Safety

- No secrets, no real family identity.
- Pure static files — safe for GitHub Pages.
- Canon games under `creative-visualizers-and-games/` stay untouched; this pack is public-safe only.
