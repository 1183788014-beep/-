/**
 * KidArcadeChat — GitHub Pages–friendly chat (no Ollama required).
 *
 * Default: keyword/fallback presets (instant, offline-safe).
 * Optional Ollama only when BOTH are set:
 *   window.KID_ARCADE_OLLAMA_URL = 'http://127.0.0.1:11434'
 *   window.KID_ARCADE_PREFER_OLLAMA = true
 * Optional model: window.KID_ARCADE_OLLAMA_MODEL (default gemma4-e2b:latest)
 */
(function (global) {
  'use strict';

  const CACHE = {};

  /** Known persona ids shipped with the pack (static list). */
  const PERSONA_IDS = [
    'elephant',
    'kinito',
    'chonks',
    'bossbot',
    'mom',
    'assistant',
    'siri',
    'recbot',
  ];

  const INLINE_FALLBACK = {
    fallback: [
      'Hello! (preset offline)',
      'I am here — try saying hi!',
      'Beep. Friendly mode active.',
      'Ask me something fun!',
    ],
    keywords: {
      'hello|hi|hey': ['Hi there!', 'Hello!'],
    },
  };

  function scriptBase() {
    try {
      if (typeof document !== 'undefined' && document.currentScript && document.currentScript.src) {
        return document.currentScript.src.replace(/\/[^/]*$/, '/');
      }
    } catch (_) {
      /* ignore */
    }
    return '';
  }

  const SCRIPT_BASE = scriptBase();

  function listPersonas() {
    return PERSONA_IDS.slice();
  }

  function pick(arr) {
    if (!arr || !arr.length) return '…';
    return arr[(Math.random() * arr.length) | 0];
  }

  function matchReply(pack, message) {
    const msg = String(message || '').toLowerCase();
    const kws = (pack && pack.keywords) || {};
    const keys = Object.keys(kws);
    for (let i = 0; i < keys.length; i++) {
      const pattern = keys[i];
      try {
        const re = new RegExp('\\b(?:' + pattern + ')\\b', 'i');
        if (re.test(msg)) return pick(kws[pattern]);
      } catch (_) {
        /* bad pattern — skip */
      }
    }
    return pick((pack && (pack.fallback || pack.lines)) || INLINE_FALLBACK.fallback);
  }

  /**
   * Build candidate URLs that work on:
   * - local http.server at pack root
   * - apps/* nested pages
   * - GitHub Pages project sites (/owner/repo/...)
   */
  function personaUrlCandidates(key) {
    const rel = 'chat-presets/' + key + '.json';
    const sharedRel = 'shared/chat-presets/' + key + '.json';
    const out = [];
    const seen = Object.create(null);

    function add(u) {
      if (!u || seen[u]) return;
      seen[u] = true;
      out.push(u);
    }

    // 1) Beside chat-presets.js (most reliable when script tag is correct)
    if (SCRIPT_BASE) {
      add(SCRIPT_BASE + rel);
      // If somehow loaded from inside chat-presets/, still try parent
      if (SCRIPT_BASE.indexOf('chat-presets') >= 0) {
        add(SCRIPT_BASE.replace(/chat-presets\/?$/, '') + rel);
      }
    }

    // 2) Resolve against document URL (Pages project paths keep the repo prefix)
    try {
      const href = (typeof location !== 'undefined' && location.href) || '';
      if (href) {
        add(new URL('../../' + sharedRel, href).href);
        add(new URL('../' + sharedRel, href).href);
        add(new URL(sharedRel, href).href);
        add(new URL('./' + sharedRel, href).href);
        // Same folder layout if page is at shared/
        add(new URL(rel, href).href);
      }
    } catch (_) {
      /* ignore */
    }

    // 3) Plain relative strings (same-origin fetch)
    add('../../shared/chat-presets/' + key + '.json');
    add('../shared/chat-presets/' + key + '.json');
    add('shared/chat-presets/' + key + '.json');
    add('./shared/chat-presets/' + key + '.json');
    add('chat-presets/' + key + '.json');

    // 4) Repo-root style only as last resorts (breaks on project Pages if used alone)
    try {
      if (typeof location !== 'undefined' && location.origin) {
        const path = location.pathname || '/';
        // Strip trailing file segment
        const dir = path.replace(/\/[^/]*$/, '/');
        // Walk up a few directories looking for /shared/chat-presets/
        let cur = dir;
        for (let depth = 0; depth < 6; depth++) {
          add(location.origin + cur + sharedRel);
          if (cur === '/' || !cur) break;
          cur = cur.replace(/[^/]+\/$/, '');
          if (!cur) cur = '/';
        }
      }
    } catch (_) {
      /* ignore */
    }

    return out;
  }

  async function loadPersona(persona) {
    const key = String(persona || 'elephant')
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '');
    if (CACHE[key]) return CACHE[key];

    const tries = personaUrlCandidates(key);
    for (let i = 0; i < tries.length; i++) {
      try {
        const r = await fetch(tries[i], { cache: 'no-store' });
        if (r && r.ok) {
          const data = await r.json();
          if (data && (data.fallback || data.keywords || data.system)) {
            CACHE[key] = data;
            return CACHE[key];
          }
        }
      } catch (_) {
        /* next */
      }
    }

    CACHE[key] = {
      persona: key,
      name: key,
      system: 'Friendly kid-safe character. Short replies. No markdown.',
      fallback: INLINE_FALLBACK.fallback.slice(),
      keywords: Object.assign({}, INLINE_FALLBACK.keywords),
    };
    return CACHE[key];
  }

  /**
   * Synchronous keyword match against an already-loaded pack.
   * Returns null if pack missing; never throws.
   */
  function replySync(personaOrPack, message) {
    try {
      let pack = personaOrPack;
      if (typeof personaOrPack === 'string') {
        const key = personaOrPack.toLowerCase();
        pack = CACHE[key];
        if (!pack) return null;
      }
      if (!pack) return null;
      return matchReply(pack, message);
    } catch (_) {
      return null;
    }
  }

  async function tryOllama(persona, message, history, pack) {
    const host = global.KID_ARCADE_OLLAMA_URL || global.OLLAMA_URL;
    const prefer =
      global.KID_ARCADE_PREFER_OLLAMA === true ||
      global.KID_ARCADE_PREFER_OLLAMA === 'true' ||
      global.KID_ARCADE_PREFER_OLLAMA === 1;
    if (!host || !prefer) return null;
    try {
      const model = global.KID_ARCADE_OLLAMA_MODEL || 'gemma4-e2b:latest';
      const system =
        (pack && pack.system) ||
        'You are a friendly kid-safe character. Short replies. No markdown.';
      const messages = [{ role: 'system', content: system }];
      (history || []).slice(-8).forEach((h) => {
        if (h && h.role && h.content) {
          messages.push({ role: h.role, content: String(h.content).slice(0, 400) });
        }
      });
      messages.push({ role: 'user', content: String(message || '').slice(0, 500) });
      const r = await fetch(String(host).replace(/\/$/, '') + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          stream: false,
          think: false,
          messages,
          options: { num_predict: 80, temperature: 0.9 },
        }),
      });
      if (!r.ok) return null;
      const d = await r.json();
      const text = ((d && d.message) || {}).content || '';
      const trimmed = String(text).trim();
      if (!trimmed) return null;
      return { ok: true, reply: trimmed.slice(0, 500), model: 'ollama:' + model, contact: persona };
    } catch (_) {
      return null;
    }
  }

  async function chat(opts) {
    try {
      opts = opts || {};
      const persona = String(opts.persona || 'elephant').toLowerCase();
      const message = opts.message || '';
      const history = opts.history || [];
      const pack = await loadPersona(persona);

      // Optional Ollama only when explicitly preferred; presets remain default.
      const ollama = await tryOllama(persona, message, history, pack);
      if (ollama && ollama.reply) return ollama;

      const reply = matchReply(pack, message);
      return {
        ok: true,
        reply: reply || 'Hello!',
        model: 'preset:' + persona,
        contact: persona,
      };
    } catch (_) {
      return {
        ok: true,
        reply: pick(INLINE_FALLBACK.fallback),
        model: 'preset:inline',
        contact: (opts && opts.persona) || 'unknown',
      };
    }
  }

  global.KidArcadeChat = {
    chat,
    loadPersona,
    listPersonas,
    replySync,
    /** @deprecated alias — same as listPersonas */
    personas: listPersonas,
  };
})(typeof window !== 'undefined' ? window : globalThis);
