/**
 * iPhone Simulator — public Kid Arcade fork (GitHub Pages static)
 * Inspired by iPhone · not affiliated with Apple
 * Chat: KidArcadeChat presets (optional Ollama via window flags)
 */
(function () {
  'use strict';

  const phone = document.getElementById('phone');
  const screen = document.getElementById('screen');
  const statusBar = document.getElementById('status-bar');
  const sbTime = document.getElementById('sb-time');
  const lockTime = document.getElementById('lock-time');
  const lockDate = document.getElementById('lock-date');
  const ncDate = document.getElementById('nc-date');
  const island = document.getElementById('island');
  const islandLabel = document.getElementById('island-label');
  const appGrid = document.getElementById('app-grid');
  const phoneDock = document.getElementById('phone-dock');
  const appBody = document.getElementById('app-body');
  const appTitle = document.getElementById('app-title');
  const appChrome = document.getElementById('app-chrome');
  const appBack = document.getElementById('app-back');
  const controlCenter = document.getElementById('control-center');
  const notifCenter = document.getElementById('notif-center');
  const ncList = document.getElementById('nc-list');
  const lockNotifs = document.getElementById('lock-notifs');
  const toastEl = document.getElementById('phone-toast');
  const panelModel = document.getElementById('panel-model');
  const batLevel = document.getElementById('bat-level');
  const stageEl = document.getElementById('stage');

  /** @type {'lock'|'home'|'app'} */
  let view = 'lock';
  let currentApp = null;
  let flashOn = false;
  let battery = 78;
  let brightness = 100;
  let volume = 60;
  let musicPlaying = false;

  /* ---------- static catalogs (no server) ---------- */
  const FALLBACK_VIDEOS = [
    { id: 'jNQXAC9IVRw', title: 'Me at the zoo', channel: 'jawed', views: '300M views', duration: '0:19', thumb: 'https://i.ytimg.com/vi/jNQXAC9IVRw/hqdefault.jpg' },
    { id: 'aqz-KE-bpKQ', title: 'Big Buck Bunny 60fps 4K', channel: 'Blender Foundation', views: 'sample', duration: '10:34', thumb: 'https://i.ytimg.com/vi/aqz-KE-bpKQ/hqdefault.jpg' },
    { id: 'LXb3EKWsInQ', title: 'COSTA RICA IN 4K', channel: 'Jacob + Katie Schwarz', views: 'travel', duration: '5:15', thumb: 'https://i.ytimg.com/vi/LXb3EKWsInQ/hqdefault.jpg' },
    { id: 'ScMzIvxBSi4', title: 'The Sound of Silence — Disturbed (live)', channel: 'Disturbed', views: 'music', duration: '4:00+', thumb: 'https://i.ytimg.com/vi/ScMzIvxBSi4/hqdefault.jpg' },
    { id: 'hHW1oY26kxQ', title: 'lofi hip hop radio 📚 beats to relax/study to', channel: 'Lofi Girl', views: 'live / chill', duration: 'LIVE', thumb: 'https://i.ytimg.com/vi/hHW1oY26kxQ/hqdefault.jpg' },
    { id: 'dQw4w9WgXcQ', title: 'Rick Astley - Never Gonna Give You Up', channel: 'Rick Astley', views: 'classic', duration: '3:33', thumb: 'https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg' },
    { id: 'kJQP7kiw5Fk', title: 'Luis Fonsi - Despacito ft. Daddy Yankee', channel: 'Luis Fonsi', views: 'music', duration: '4:41', thumb: 'https://i.ytimg.com/vi/kJQP7kiw5Fk/hqdefault.jpg' },
    { id: '9bZkp7q19f0', title: 'PSY - GANGNAM STYLE', channel: 'officialpsy', views: 'music', duration: '4:12', thumb: 'https://i.ytimg.com/vi/9bZkp7q19f0/hqdefault.jpg' },
  ];

  const ROBLOX_SAMPLE = [
    { name: 'Brookhaven 🏡RP', placeId: '4924922222', playersLabel: 'Popular', rating: 92, creator: 'Wolfpaq', playUrl: 'https://www.roblox.com/games/4924922222', appUrl: 'roblox://experiences/start?placeId=4924922222' },
    { name: 'Adopt Me!', placeId: '920587237', playersLabel: 'Popular', rating: 90, creator: 'DreamCraft', playUrl: 'https://www.roblox.com/games/920587237', appUrl: 'roblox://experiences/start?placeId=920587237' },
    { name: 'Blox Fruits', placeId: '2753915549', playersLabel: 'Charts', rating: 91, creator: 'Gamer Robot Inc', playUrl: 'https://www.roblox.com/games/2753915549', appUrl: 'roblox://experiences/start?placeId=2753915549' },
    { name: 'Tower of Hell', placeId: '1962086868', playersLabel: 'Classic', rating: 88, creator: 'YXCeptional Studios', playUrl: 'https://www.roblox.com/games/1962086868', appUrl: 'roblox://experiences/start?placeId=1962086868' },
    { name: 'Murder Mystery 2', placeId: '142823291', playersLabel: 'Classic', rating: 89, creator: 'Nikilis', playUrl: 'https://www.roblox.com/games/142823291', appUrl: 'roblox://experiences/start?placeId=142823291' },
    { name: 'Discover more on Roblox', placeId: '', playersLabel: 'Open site', rating: null, creator: 'roblox.com', playUrl: 'https://www.roblox.com/discover', appUrl: 'roblox://' },
  ];

  /* ---------- localStorage helpers (sim-only YT) ---------- */
  function lsGet(key, fallback) {
    try {
      const v = JSON.parse(localStorage.getItem(key) || 'null');
      return v == null ? fallback : v;
    } catch {
      return fallback;
    }
  }
  function lsSet(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
      return true;
    } catch {
      return false;
    }
  }

  const APPS = [
    { id: 'messages', name: 'Messages', glyph: 'g-messages', emoji: '💬', dock: false },
    { id: 'roblox', name: 'Roblox', glyph: 'g-roblox', emoji: 'R', dock: false },
    { id: 'youtube', name: 'YouTube', glyph: 'g-youtube', emoji: '▶', dock: false },
    { id: 'facetime', name: 'FaceTime', glyph: 'g-facetime', emoji: '📹', dock: false },
    { id: 'calendar', name: 'Calendar', glyph: 'g-clock', emoji: '📅', dock: false },
    { id: 'photos', name: 'Photos', glyph: 'g-photos', emoji: '🖼️', dock: false },
    { id: 'camera', name: 'Camera', glyph: 'g-camera', emoji: '📷', dock: false },
    { id: 'mail', name: 'Mail', glyph: 'g-mail', emoji: '✉️', dock: false },
    { id: 'notes', name: 'Notes', glyph: 'g-notes', emoji: '📝', dock: false },
    { id: 'reminders', name: 'Reminders', glyph: 'g-notes', emoji: '✓', dock: false },
    { id: 'clock', name: 'Clock', glyph: 'g-clock', emoji: '🕐', dock: false },
    { id: 'maps', name: 'Maps', glyph: 'g-maps', emoji: '🗺️', dock: false },
    { id: 'weather', name: 'Weather', glyph: 'g-weather', emoji: '☀️', dock: false },
    { id: 'music', name: 'Music', glyph: 'g-music', emoji: '🎵', dock: false },
    { id: 'wallet', name: 'Wallet', glyph: 'g-wallet', emoji: '💳', dock: false },
    { id: 'games', name: 'Arcade', glyph: 'g-games', emoji: '🕹️', dock: false },
    { id: 'appstore', name: 'App Store', glyph: 'g-appstore', emoji: 'A', dock: false },
    { id: 'health', name: 'Health', glyph: 'g-health', emoji: '❤️', dock: false },
    { id: 'settings', name: 'Settings', glyph: 'g-settings', emoji: '⚙️', dock: false },
    { id: 'kinito', name: 'Kinito', glyph: 'g-kinito', emoji: '👾', dock: false },
    { id: 'calc', name: 'Calculator', glyph: 'g-calc', emoji: '＋', dock: false },
  ];

  const DOCK = [
    { id: 'phone', name: 'Phone', glyph: 'g-phone', emoji: '📞' },
    { id: 'safari', name: 'Safari', glyph: 'g-safari', emoji: '🧭' },
    { id: 'roblox', name: 'Roblox', glyph: 'g-roblox', emoji: 'R' },
    { id: 'youtube', name: 'YouTube', glyph: 'g-youtube', emoji: '▶' },
  ];

  const NOTIFS = [
    { id: 1, app: 'roblox', title: 'Roblox', body: 'Real experiences · tap to play', ago: 'now', color: 'linear-gradient(145deg,#e2231a,#7a1010)', emoji: 'R' },
    { id: 2, app: 'messages', title: 'Kinito', body: 'Hello! Want to chat on your new phone?', ago: 'now', color: 'linear-gradient(145deg,#5b8cff,#3a60c0)', emoji: '👾' },
    { id: 3, app: 'youtube', title: 'YouTube', body: 'Sample feed · paste a link to watch', ago: 'now', color: '#ff0000', emoji: '▶' },
    { id: 4, app: 'games', title: 'Arcade', body: 'I Am Bird · I Am Monkey ready', ago: 'now', color: 'linear-gradient(145deg,#bf5af2,#5e5ce6)', emoji: '🕹️' },
  ];

  let ytHistory = lsGet('phone-sim-yt-history', []) || [];
  function saveYtHistory(v) {
    if (!v || !v.id) return;
    ytHistory = [{ id: v.id, title: v.title, channel: v.channel, thumb: v.thumb, watch: v.watch }, ...ytHistory.filter((x) => x.id !== v.id)].slice(0, 24);
    lsSet('phone-sim-yt-history', ytHistory);
  }

  let ytAccount = {
    id: 'arkhe-user',
    name: 'Arkhē User',
    handle: '@arkhe.sim',
    avatar: 'AU',
    color: '#5b8cff',
  };
  try {
    const saved = lsGet('phone-sim-yt-account', null);
    if (saved && saved.name) ytAccount = { ...ytAccount, ...saved };
  } catch {
    /* ignore */
  }
  function saveYtAccount() {
    lsSet('phone-sim-yt-account', ytAccount);
  }

  /** Session-only big video blobs (localStorage size limits) */
  let ytSessionPosts = [];

  function loadYtPostsStore() {
    const light = lsGet('phone-sim-yt-posts', []) || [];
    return [...ytSessionPosts, ...light.filter((p) => !ytSessionPosts.some((s) => s.id === p.id))];
  }
  function saveYtPost(post) {
    if (!post || !post.id) return;
    if (post.kind === 'file' && post.src && String(post.src).length > 80000) {
      ytSessionPosts = [post, ...ytSessionPosts.filter((x) => x.id !== post.id)].slice(0, 8);
      return;
    }
    const light = (lsGet('phone-sim-yt-posts', []) || []).filter((x) => x.id !== post.id);
    light.unshift(post);
    if (!lsSet('phone-sim-yt-posts', light.slice(0, 20))) {
      ytSessionPosts = [post, ...ytSessionPosts.filter((x) => x.id !== post.id)].slice(0, 8);
    }
  }
  function deleteYtPost(id) {
    ytSessionPosts = ytSessionPosts.filter((x) => x.id !== id);
    const light = (lsGet('phone-sim-yt-posts', []) || []).filter((x) => x.id !== id);
    lsSet('phone-sim-yt-posts', light);
  }

  function loadYtComments(videoId) {
    const store = lsGet('phone-sim-yt-comments', {}) || {};
    return store[videoId] || [];
  }
  function saveYtComment(videoId, comment) {
    const store = lsGet('phone-sim-yt-comments', {}) || {};
    const list = store[videoId] || [];
    list.unshift(comment);
    store[videoId] = list.slice(0, 80);
    lsSet('phone-sim-yt-comments', store);
  }

  const MSG_CONTACTS = {
    kinito: {
      name: 'Kinito',
      av: 'kinito',
      seed: [{ role: 'assistant', content: 'Hello! I am Kinito — texting from your phone!' }],
    },
    chonks: {
      name: 'Desk Chonks',
      av: 'chonks',
      seed: [{ role: 'assistant', content: 'squeak · chonk · vibes 🐾' }],
    },
    bossbot: {
      name: 'BossBot-9000',
      av: 'boss',
      seed: [{ role: 'assistant', content: 'Employee detected. Status report?' }],
    },
    mom: {
      name: 'Mom',
      av: 'mom',
      seed: [{ role: 'assistant', content: 'Did you eat? Love you 💕' }],
    },
    assistant: {
      name: 'Assistant',
      av: 'assistant',
      seed: [{ role: 'assistant', content: 'Hi — how can I help?' }],
    },
  };

  /* ---------- mobile fit / fullscreen phone ---------- */
  function isCompactViewport() {
    return window.matchMedia('(max-width: 520px), (max-height: 720px)').matches ||
      ('ontouchstart' in window && window.innerWidth <= 900);
  }
  function applyViewportMode() {
    const compact = isCompactViewport();
    document.body.classList.toggle('real-device', compact);
    stageEl?.classList.toggle('fullscreen-phone', compact);
    if (!compact && phone) {
      const pad = 24;
      const scale = Math.min(
        1,
        (window.innerWidth - pad * 2 - 40) / 390,
        (window.innerHeight - pad * 2) / 844
      );
      // leave room for side panel on wide screens
      const hasPanel = window.innerWidth > 780;
      const s = Math.min(
        1,
        ((window.innerWidth - pad * 2 - (hasPanel ? 320 : 0)) / 390),
        ((window.innerHeight - pad * 2) / 844)
      );
      phone.style.setProperty('--fit-scale', String(Math.max(0.45, s)));
    } else if (phone) {
      phone.style.removeProperty('--fit-scale');
    }
  }
  window.addEventListener('resize', applyViewportMode);
  applyViewportMode();

  /* ---------- clock ---------- */
  function updateClock() {
    const d = new Date();
    const t = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    const plain = t.replace(/\s?(AM|PM)/i, '');
    sbTime.textContent = plain;
    lockTime.textContent = plain;
    lockDate.textContent = d.toLocaleDateString(undefined, {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
    if (ncDate) {
      ncDate.textContent = d.toLocaleDateString(undefined, {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
      });
    }
  }
  setInterval(updateClock, 15000);
  updateClock();

  if (batLevel) {
    batLevel.style.setProperty('--bat', battery + '%');
  }

  /* ---------- toast / island ---------- */
  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.remove('hidden');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.add('hidden'), ms || 1800);
  }

  function pulseIsland(label, ms) {
    if (label) islandLabel.textContent = label;
    island.classList.add('expanded');
    clearTimeout(pulseIsland._t);
    pulseIsland._t = setTimeout(() => {
      island.classList.remove('expanded');
      islandLabel.textContent = '';
    }, ms || 2200);
  }

  /* ---------- screens ---------- */
  function showScreen(name) {
    view = name;
    document.querySelectorAll('.scr').forEach((s) => {
      s.classList.toggle('active', s.dataset.scr === name);
    });
    phone.classList.toggle('locked-dim', false);
    statusBar.classList.toggle('dark', false);
    if (name === 'app' && currentApp === 'camera') {
      statusBar.style.opacity = '0';
    } else {
      statusBar.style.opacity = '1';
    }
    closeOverlays();
  }

  function goHome() {
    currentApp = null;
    showScreen('home');
  }

  function unlock() {
    showScreen('home');
    pulseIsland('Unlocked', 1200);
  }

  function lock() {
    currentApp = null;
    showScreen('lock');
    closeOverlays();
    toast('Locked');
  }

  function closeOverlays() {
    controlCenter.classList.add('hidden');
    notifCenter.classList.add('hidden');
  }

  /* ---------- icons ---------- */
  function iconHtml(app) {
    return `
      <button type="button" class="app-icon" data-open="${app.id}">
        <div class="app-glyph ${app.glyph}">${app.emoji || ''}</div>
        <span>${app.name}</span>
      </button>`;
  }

  function renderHome() {
    appGrid.innerHTML = APPS.map(iconHtml).join('');
    phoneDock.innerHTML = DOCK.map(iconHtml).join('');
    screen.querySelectorAll('[data-open]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openApp(btn.dataset.open);
      });
    });
  }

  function renderNotifs() {
    const html = NOTIFS.map(
      (n) => `
      <button type="button" class="lock-notif" data-notif="${n.id}" data-app="${n.app}">
        <div class="ni" style="background:${n.color}">${n.emoji}</div>
        <div class="nt"><b>${n.title}</b><span>${n.body}</span></div>
        <div class="ago">${n.ago}</div>
      </button>`
    ).join('');
    lockNotifs.innerHTML = html;
    ncList.innerHTML = html;
    [lockNotifs, ncList].forEach((el) => {
      el.querySelectorAll('[data-app]').forEach((btn) => {
        btn.addEventListener('click', () => {
          closeOverlays();
          if (view === 'lock') unlock();
          openApp(btn.dataset.app);
        });
      });
    });
  }

  /* ---------- open app ---------- */
  let appBackHandler = null;

  function openApp(id) {
    currentApp = id;
    appBackHandler = null;
    const meta =
      APPS.find((a) => a.id === id) ||
      DOCK.find((a) => a.id === id) ||
      { name: id, id };
    appTitle.textContent = meta.name || id;
    appChrome.classList.remove('light', 'hidden-bar');
    appBody.className = 'app-body';
    appBody.innerHTML = '';

    if (id === 'camera' || id === 'youtube' || id === 'roblox') {
      appChrome.classList.add('hidden-bar');
    }
    if (id === 'weather') {
      appChrome.style.background = 'transparent';
      appChrome.style.border = 'none';
      appChrome.style.position = 'absolute';
      appChrome.style.left = '0';
      appChrome.style.right = '0';
    } else {
      appChrome.style.position = '';
      appChrome.style.background = '';
      appChrome.style.border = '';
    }

    showScreen('app');
    renderApp(id);
  }

  function renderApp(id) {
    switch (id) {
      case 'messages':
        return renderMessages();
      case 'phone':
        return renderPhone();
      case 'safari':
        return renderSafari();
      case 'youtube':
        return renderYouTube();
      case 'roblox':
        return renderRoblox();
      case 'camera':
        return renderCamera();
      case 'photos':
        return renderPhotos();
      case 'music':
        return renderMusic();
      case 'weather':
        return renderWeather();
      case 'clock':
        return renderClock();
      case 'calc':
      case 'calculator':
        return renderCalc();
      case 'settings':
        return renderSettings();
      case 'notes':
        return renderNotes();
      case 'maps':
        return renderMaps();
      case 'mail':
        return renderMail();
      case 'wallet':
        return renderWallet();
      case 'games':
      case 'appstore':
        return renderGames(id);
      case 'kinito':
        return renderKinito();
      case 'facetime':
        return renderStub('📹', 'FaceTime', 'Start a simulated video call with friends on this toy phone.');
      case 'health':
        return renderStub('❤️', 'Health', 'Steps today: 4,218 · Move ring 62% · Stand 8 hours.');
      case 'calendar':
        return renderStub('📅', 'Calendar', new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }));
      case 'reminders':
        return renderStub('✓', 'Reminders', '• Milk\n• Feed desk chonks\n• Ship something cool');
      default:
        return renderStub('📱', metaName(id), 'Coming soon on this simulator.');
    }
  }

  function metaName(id) {
    return (APPS.find((a) => a.id === id) || DOCK.find((a) => a.id === id) || {}).name || id;
  }

  function renderStub(emoji, title, body) {
    appBody.innerHTML = `
      <div class="center-stub">
        <div class="big">${emoji}</div>
        <h2>${title}</h2>
        <p style="white-space:pre-line">${esc(body)}</p>
        <button type="button" class="primary" data-home-btn>Done</button>
      </div>`;
    appBody.querySelector('[data-home-btn]')?.addEventListener('click', goHome);
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function openRelative(url, label) {
    // same-tab navigation works best inside Pages / pack static host
    try {
      window.location.href = url;
    } catch {
      window.open(url, '_blank', 'noopener');
    }
    toast('Opening ' + (label || url) + '…');
  }

  /* ---------- Messages + KidArcadeChat ---------- */
  function renderMessages() {
    appTitle.textContent = 'Messages';
    const state = {
      contact: null,
      histories: {},
      busy: false,
    };
    Object.keys(MSG_CONTACTS).forEach((id) => {
      state.histories[id] = MSG_CONTACTS[id].seed.map((m) => ({ ...m }));
    });

    function listView() {
      appTitle.textContent = 'Messages';
      appBody.innerHTML = `
        <div class="im">
          <div class="im-list">
            <div class="im-search">Search</div>
            ${Object.entries(MSG_CONTACTS)
              .map(([id, c]) => {
                const last = state.histories[id].slice(-1)[0];
                return `
                <button type="button" class="im-row" data-c="${id}">
                  <div class="im-av ${c.av}"></div>
                  <div class="im-meta">
                    <b>${c.name}</b>
                    <i>${esc((last && last.content) || '')}</i>
                  </div>
                  <div class="im-time">now</div>
                </button>`;
              })
              .join('')}
            <div class="im-status" id="im-status">preset chat…</div>
          </div>
        </div>`;
      appBody.querySelectorAll('[data-c]').forEach((btn) => {
        btn.addEventListener('click', () => threadView(btn.dataset.c));
      });
      refreshChatStatus(appBody.querySelector('#im-status'));
    }

    function threadView(contact) {
      state.contact = contact;
      const c = MSG_CONTACTS[contact];
      appTitle.textContent = c.name;
      appBody.innerHTML = `
        <div class="im">
          <div class="im-thread">
            <div class="im-log"></div>
            <form class="im-compose" action="javascript:void(0)">
              <input class="im-input" type="text" maxlength="400" placeholder="iMessage" autocomplete="off" enterkeyhint="send" />
              <button type="submit" class="im-send" aria-label="Send">↑</button>
            </form>
          </div>
        </div>`;
      const log = appBody.querySelector('.im-log');
      const input = appBody.querySelector('.im-input');
      const form = appBody.querySelector('.im-compose');
      const sendBtn = appBody.querySelector('.im-send');

      function renderThread() {
        const h = state.histories[contact] || [];
        log.innerHTML = h
          .map((m) => {
            const mine = m.role === 'user';
            return `<div class="bubble-row ${mine ? 'me' : 'them'}"><div class="bubble">${esc(m.content)}</div></div>`;
          })
          .join('');
        log.scrollTop = log.scrollHeight;
      }

      async function send() {
        const text = (input.value || '').trim();
        if (!text || state.busy) return;
        state.busy = true;
        sendBtn.disabled = true;
        input.disabled = true;
        input.value = '';
        state.histories[contact].push({ role: 'user', content: text });
        renderThread();
        const typing = document.createElement('div');
        typing.className = 'bubble-row them';
        typing.innerHTML = '<div class="bubble typing">…</div>';
        log.appendChild(typing);
        log.scrollTop = log.scrollHeight;
        pulseIsland('iMessage', 3000);

        try {
          const hist = state.histories[contact]
            .slice(0, -1)
            .filter((m) => m.role === 'user' || m.role === 'assistant')
            .slice(-10);

          let d;
          if (window.KidArcadeChat && typeof window.KidArcadeChat.chat === 'function') {
            d = await window.KidArcadeChat.chat({
              persona: contact,
              message: text,
              history: hist,
            });
          } else {
            throw new Error('KidArcadeChat missing — load shared/chat-presets.js');
          }
          typing.remove();
          if (!d || !d.ok) throw new Error((d && (d.error || d.hint)) || 'chat failed');
          state.histories[contact].push({
            role: 'assistant',
            content: (d.reply || '').trim() || '…',
          });
          if (state.histories[contact].length > 24) {
            state.histories[contact] = state.histories[contact].slice(-24);
          }
          renderThread();
          if (panelModel && d.model) panelModel.textContent = d.model;
        } catch (e) {
          typing.remove();
          state.histories[contact].push({
            role: 'assistant',
            content: '… (offline) ' + String(e.message || e),
          });
          renderThread();
        }
        state.busy = false;
        sendBtn.disabled = false;
        input.disabled = false;
        input.focus();
      }

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        send();
      });
      input.addEventListener('keydown', (e) => e.stopPropagation());
      renderThread();
      setTimeout(() => input.focus(), 100);
    }

    appBackHandler = () => {
      if (state.contact) {
        state.contact = null;
        listView();
        return true;
      }
      return false;
    };

    listView();
  }

  async function refreshChatStatus(el) {
    // Fake local status — no /api/status on static host
    const hasChat = !!(window.KidArcadeChat && typeof window.KidArcadeChat.chat === 'function');
    const ollama =
      !!(window.KID_ARCADE_OLLAMA_URL || window.OLLAMA_URL) &&
      !!window.KID_ARCADE_PREFER_OLLAMA;
    let model = hasChat ? 'preset:ready' : 'offline';
    if (hasChat && ollama) model = 'preset+ollama';
    if (el) {
      el.textContent = hasChat
        ? '● ' + model
        : '○ chat-presets.js missing';
      el.style.color = hasChat ? '#30d158' : '#ff9f0a';
    }
    if (panelModel) panelModel.textContent = model;
  }

  /* ---------- YouTube (embeds + static fallback) ---------- */
  function renderYouTube() {
    appTitle.textContent = 'YouTube';
    const state = {
      tab: 'home',
      mode: 'feed',
      videos: [],
      myPosts: [],
      playing: null,
      query: '',
      chip: 'All',
      source: '',
      loading: false,
    };

    const CHIPS = ['All', 'Music', 'Gaming', 'News', 'Lo-fi', 'Cats', 'Trailers', 'Tech'];
    const EFFECTS = [
      { id: 'none', label: 'Normal' },
      { id: 'vintage', label: 'Vintage' },
      { id: 'vhs', label: 'VHS' },
      { id: 'neon', label: 'Neon' },
      { id: 'noir', label: 'Noir' },
      { id: 'dream', label: 'Dream' },
      { id: 'chrome', label: 'Chrome' },
      { id: 'heat', label: 'Heat' },
      { id: 'glitch', label: 'Glitch' },
      { id: 'cinema', label: 'Cinema' },
    ];

    function embedUrl(id, autoplay) {
      const ap = autoplay ? '&autoplay=1' : '';
      return (
        'https://www.youtube-nocookie.com/embed/' +
        encodeURIComponent(id) +
        '?playsinline=1&rel=0&modestbranding=1' +
        ap
      );
    }

    function findVideo(id) {
      return (
        state.myPosts.find((x) => x.id === id) ||
        state.videos.find((x) => x.id === id) ||
        ytHistory.find((x) => x.id === id) ||
        FALLBACK_VIDEOS.find((x) => x.id === id) ||
        null
      );
    }

    function cardHtml(v) {
      const isLocal = !!(v.local || (v.id && String(v.id).startsWith('local-')));
      const thumb =
        v.thumb ||
        (isLocal ? '' : 'https://i.ytimg.com/vi/' + v.id + '/hqdefault.jpg');
      const thumbStyle = thumb
        ? `background-image:url('${esc(thumb)}')`
        : 'background:linear-gradient(135deg,#5b8cff,#ff2d55)';
      const sub = [v.channel, v.views || (isLocal ? 'Only you' : '')]
        .filter(Boolean)
        .join(' · ');
      return `
        <button type="button" class="yt-card" data-vid="${esc(v.id)}">
          <div class="yt-thumb" style="${thumbStyle}">
            ${isLocal ? '<span class="yt-priv-badge">Only you</span>' : ''}
            ${v.effect && v.effect !== 'none' ? `<span class="yt-fx-badge">${esc(v.effect)}</span>` : ''}
            ${v.duration ? `<span class="yt-dur">${esc(v.duration)}</span>` : ''}
          </div>
          <div class="yt-meta">
            <div class="yt-av" style="${isLocal ? 'background:' + esc(v.color || ytAccount.color) : ''}">${esc(
              isLocal
                ? v.avatar || ytAccount.avatar
                : (v.channel || 'Y').slice(0, 1).toUpperCase()
            )}</div>
            <div class="yt-meta-text">
              <b>${esc(v.title || 'Video')}</b>
              <span>${esc(sub)}</span>
            </div>
          </div>
        </button>`;
    }

    function miniHtml(v) {
      const isLocal = !!(v.local || (v.id && String(v.id).startsWith('local-')));
      const thumb =
        v.thumb ||
        (isLocal ? '' : 'https://i.ytimg.com/vi/' + v.id + '/hqdefault.jpg');
      const thumbStyle = thumb
        ? `background-image:url('${esc(thumb)}')`
        : 'background:linear-gradient(135deg,#5b8cff,#ff2d55)';
      return `
        <button type="button" class="yt-mini" data-vid="${esc(v.id)}">
          <div class="yt-mini-thumb" style="${thumbStyle}">
            ${v.duration ? `<span class="yt-dur">${esc(v.duration)}</span>` : ''}
          </div>
          <div>
            <b>${esc(v.title || 'Video')}</b>
            <span>${esc(v.channel || '')}${isLocal ? ' · Only you' : ''}</span>
          </div>
        </button>`;
    }

    function shell(inner, opts) {
      opts = opts || {};
      appBody.innerHTML = `
        <div class="yt">
          ${
            opts.hideTop
              ? ''
              : `<div class="yt-top">
            <div class="yt-logo"><span class="play"></span>YouTube</div>
            <form class="yt-search-wrap" action="javascript:void(0)">
              <input class="yt-search" type="search" placeholder="Search or paste URL" value="${esc(state.query)}" enterkeyhint="search" />
              <button type="submit" class="yt-search-btn" title="Search">🔍</button>
            </form>
            <button type="button" class="yt-create-top" data-tab="create" title="Create">＋</button>
          </div>`
          }
          ${inner}
          ${
            opts.hideTabs
              ? ''
              : `<div class="yt-tabs">
            <button type="button" class="yt-tab ${state.tab === 'home' ? 'on' : ''}" data-tab="home"><span class="ico">⌂</span>Home</button>
            <button type="button" class="yt-tab ${state.tab === 'shorts' ? 'on' : ''}" data-tab="shorts"><span class="ico">▷</span>Shorts</button>
            <button type="button" class="yt-tab yt-tab-create ${state.tab === 'create' ? 'on' : ''}" data-tab="create" title="Create / Post">
              <span class="yt-create-fab">＋</span>
              <span>Create</span>
            </button>
            <button type="button" class="yt-tab ${state.tab === 'library' ? 'on' : ''}" data-tab="library"><span class="ico">☰</span>Library</button>
            <button type="button" class="yt-tab ${state.tab === 'web' ? 'on' : ''}" data-tab="web"><span class="ico">◎</span>Site</button>
          </div>`
          }
        </div>`;
      wireChrome();
    }

    function wireChrome() {
      const form = appBody.querySelector('.yt-search-wrap');
      const input = appBody.querySelector('.yt-search');
      form?.addEventListener('submit', (e) => {
        e.preventDefault();
        const q = (input?.value || '').trim();
        if (!q) return;
        state.query = q;
        state.tab = 'home';
        state.mode = 'feed';
        doSearch(q);
      });
      input?.addEventListener('keydown', (e) => e.stopPropagation());
      appBody.querySelectorAll('[data-tab]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const t = btn.dataset.tab;
          state.tab = t;
          state.playing = null;
          if (t === 'home') {
            state.mode = 'feed';
            loadTrending();
          } else if (t === 'shorts') {
            state.mode = 'feed';
            doSearch('shorts');
          } else if (t === 'create') {
            state.mode = 'create';
            showCreate();
          } else if (t === 'library') {
            state.mode = 'feed';
            showLibrary();
          } else if (t === 'web') {
            state.mode = 'web';
            showWeb();
          }
        });
      });
      appBody.querySelectorAll('[data-vid]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.vid;
          const v = findVideo(id) || { id, title: id, channel: 'YouTube' };
          playVideo(v);
        });
      });
    }

    async function loadMyPosts() {
      state.myPosts = loadYtPostsStore();
      return state.myPosts;
    }

    async function loadTrending() {
      state.loading = true;
      state.mode = 'feed';
      paintFeedLoading('Loading…');
      await loadMyPosts();
      state.videos = [...(state.myPosts || []), ...FALLBACK_VIDEOS];
      state.source =
        (state.myPosts.length ? state.myPosts.length + ' yours · ' : '') + 'static catalog';
      paintFeed();
      pulseIsland('YouTube', 1200);
      state.loading = false;
    }

    async function doSearch(q) {
      state.loading = true;
      state.mode = 'feed';
      paintFeedLoading('Searching…');
      const id = extractYtId(q);
      if (id) {
        const hit = FALLBACK_VIDEOS.find((v) => v.id === id) || {
          id,
          title: 'YouTube video',
          channel: 'YouTube',
          thumb: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg',
        };
        state.videos = [hit];
        state.source = 'direct';
        playVideo(hit);
        state.loading = false;
        return;
      }
      const ql = String(q || '').toLowerCase();
      let local = FALLBACK_VIDEOS.filter(
        (v) => v.title.toLowerCase().includes(ql) || v.channel.toLowerCase().includes(ql)
      );
      if (!local.length) local = FALLBACK_VIDEOS.slice();
      // chip-ish filters
      if (ql === 'music' || ql === 'lo-fi' || ql === 'lofi') {
        local = FALLBACK_VIDEOS.filter((v) => /music|lofi|silence|despacito|gangnam|rick/i.test(v.title + v.channel));
      } else if (ql === 'shorts') {
        local = FALLBACK_VIDEOS.filter((v) => v.duration === '0:19' || /zoo|shorts/i.test(v.title)).concat(FALLBACK_VIDEOS).slice(0, 6);
      }
      state.videos = local.length ? local : FALLBACK_VIDEOS.slice();
      state.source = 'static search';
      paintFeed();
      state.loading = false;
    }

    function extractYtId(text) {
      const m = String(text || '').match(
        /(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|youtube\.com\/v\/)([A-Za-z0-9_-]{11})|^([A-Za-z0-9_-]{11})$/
      );
      return m ? m[1] || m[2] : null;
    }

    function paintFeedLoading(msg) {
      shell(`
        <div class="yt-chips">
          ${CHIPS.map(
            (c) =>
              `<button type="button" class="yt-chip ${state.chip === c ? 'on' : ''}" data-chip="${esc(c)}">${esc(c)}</button>`
          ).join('')}
        </div>
        <div class="yt-feed"><div class="yt-empty">${esc(msg)}</div></div>
      `);
      wireChips();
    }

    function paintFeed(err) {
      const cards = state.videos.map(cardHtml).join('');
      shell(`
        <div class="yt-chips">
          ${CHIPS.map(
            (c) =>
              `<button type="button" class="yt-chip ${state.chip === c ? 'on' : ''}" data-chip="${esc(c)}">${esc(c)}</button>`
          ).join('')}
        </div>
        <div class="yt-status">${esc(
          err
            ? err
            : state.source
              ? (state.query ? 'Results' : 'Trending') + ' · ' + state.source
              : ''
        )}</div>
        <div class="yt-feed">
          ${
            cards ||
            `<div class="yt-empty">No videos.<br/>Search or paste a YouTube URL / video ID.</div>`
          }
        </div>
      `);
      wireChips();
    }

    function wireChips() {
      appBody.querySelectorAll('[data-chip]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const c = btn.dataset.chip;
          state.chip = c;
          if (c === 'All') {
            state.query = '';
            loadTrending();
          } else {
            state.query = c;
            doSearch(c);
          }
        });
      });
    }

    function fmtLikes(n) {
      n = +n || 0;
      if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
      if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
      return String(n);
    }

    function commentHtml(c) {
      const isLocal = !!c.local;
      const avStyle = isLocal ? `background:${esc(c.color || ytAccount.color)}` : '';
      const avText = isLocal
        ? esc(c.avatar || (c.author || '?').slice(0, 2).toUpperCase())
        : esc((c.author || '?').replace(/^@/, '').slice(0, 1).toUpperCase());
      const badges = [
        c.pinned ? '<span class="yt-badge pin">Pinned</span>' : '',
        isLocal ? '<span class="yt-badge local">Only on this phone</span>' : '',
      ]
        .filter(Boolean)
        .join(' ');
      return `
        <div class="yt-comment ${isLocal ? 'is-local' : ''}">
          <div class="yt-c-av" style="${avStyle}">${avText}</div>
          <div class="yt-c-body">
            <div class="yt-c-head">
              <b>${esc(c.author || 'User')}</b>
              ${c.handle ? `<span class="yt-c-handle">${esc(c.handle)}</span>` : ''}
              <span class="yt-c-time">${esc(c.time || '')}</span>
            </div>
            ${badges ? `<div class="yt-c-badges">${badges}</div>` : ''}
            <div class="yt-c-text">${esc(c.text || '')}</div>
            <div class="yt-c-meta">
              <span>👍 ${fmtLikes(c.likes)}</span>
              ${isLocal ? '<span class="yt-c-sim">sim-only</span>' : ''}
            </div>
          </div>
        </div>`;
    }

    function playVideo(v) {
      if (!v || !v.id) return;
      state.mode = 'player';
      state.playing = v;
      state.tab = state.tab === 'create' ? 'library' : state.tab;
      saveYtHistory(v);
      const isLocal = !!(v.local || String(v.id).startsWith('local-'));
      const effect = (v.effect || 'none').toLowerCase();
      const related = state.videos.filter((x) => x.id !== v.id).slice(0, 12);
      const watch = v.watch || (isLocal ? '' : 'https://www.youtube.com/watch?v=' + v.id);

      let playerInner = '';
      if (isLocal && v.kind === 'file' && v.src) {
        playerInner = `
          <div class="yt-player-frame yt-local-frame yt-fx yt-fx-${esc(effect)}">
            <video class="yt-local-video" src="${esc(v.src)}" controls playsinline autoplay></video>
            <div class="yt-fx-overlay yt-fx-overlay-${esc(effect)}"></div>
          </div>`;
      } else if (isLocal && (v.kind === 'youtube' || v.youtubeSource)) {
        const yid = v.youtubeSource || extractYtId(v.src || '') || v.id.replace(/^local-/, '');
        playerInner = `
          <div class="yt-player-frame yt-fx yt-fx-${esc(effect)}">
            <iframe
              src="${embedUrl(yid, true)}"
              title="${esc(v.title || 'YouTube')}"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowfullscreen
              referrerpolicy="strict-origin-when-cross-origin"
            ></iframe>
            <div class="yt-fx-overlay yt-fx-overlay-${esc(effect)}"></div>
          </div>`;
      } else {
        playerInner = `
          <div class="yt-player-frame">
            <iframe
              src="${embedUrl(v.id, true)}"
              title="${esc(v.title || 'YouTube')}"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowfullscreen
              referrerpolicy="strict-origin-when-cross-origin"
            ></iframe>
          </div>`;
      }

      shell(
        `
        <div class="yt-player">
          ${playerInner}
          <div class="yt-player-info">
            <h2>${esc(v.title || 'Video')}</h2>
            <div class="sub">${esc(v.channel || 'YouTube')}${v.views ? ' · ' + esc(v.views) : ''}${
              isLocal ? ' · 🔒 Only on this phone' : ''
            }${effect !== 'none' ? ' · fx:' + esc(effect) : ''}</div>
            ${v.description ? `<p class="yt-desc">${esc(v.description)}</p>` : ''}
          </div>
          <div class="yt-player-actions">
            <button type="button" class="yt-act" data-yt-act="like">👍 Like</button>
            ${
              isLocal
                ? `<button type="button" class="yt-act" data-yt-act="delete">🗑 Delete</button>
                   <button type="button" class="yt-act" data-yt-act="create">＋ New</button>`
                : `<button type="button" class="yt-act" data-yt-act="share">↗ Share</button>
                   <button type="button" class="yt-act" data-yt-act="open">Open ▶︎</button>
                   <button type="button" class="yt-act" data-yt-act="site">Full site</button>`
            }
          </div>

          <div class="yt-account-bar">
            <div class="yt-acc-av" style="background:${esc(ytAccount.color)}">${esc(ytAccount.avatar)}</div>
            <div class="yt-acc-meta">
              <b>${esc(ytAccount.name)}</b>
              <span>Signed in · ${esc(ytAccount.handle)}</span>
            </div>
            <span class="yt-acc-pill">● Online</span>
          </div>

          <div class="yt-comments" id="yt-comments">
            <div class="yt-comments-head">
              <h3>Comments <span id="yt-c-count">…</span></h3>
              <span class="yt-comments-note" id="yt-c-note">sim-only</span>
            </div>
            <form class="yt-compose" id="yt-compose" action="javascript:void(0)">
              <div class="yt-c-av" style="background:${esc(ytAccount.color)}">${esc(ytAccount.avatar)}</div>
              <input class="yt-compose-in" id="yt-compose-in" type="text" maxlength="500" placeholder="Add a comment as ${esc(ytAccount.name)}…" autocomplete="off" />
              <button type="submit" class="yt-compose-send">Comment</button>
            </form>
            <div class="yt-compose-hint">Your comments stay in this browser only — not on real YouTube.</div>
            <div class="yt-comment-list" id="yt-comment-list">
              <div class="yt-empty">Loading comments…</div>
            </div>
          </div>

          <div class="yt-related">
            <div class="yt-related-h">Up next</div>
            ${related.map(miniHtml).join('') || '<div class="yt-empty">Search for more videos</div>'}
          </div>
        </div>
      `,
        { hideTop: false, hideTabs: false }
      );

      appBody.querySelector('.yt-logo')?.addEventListener('click', () => {
        state.playing = null;
        state.mode = 'feed';
        paintFeed();
      });

      appBody.querySelectorAll('[data-yt-act]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const a = btn.dataset.ytAct;
          if (a === 'like') toast('Liked as ' + ytAccount.name);
          if (a === 'create') {
            state.tab = 'create';
            showCreate();
          }
          if (a === 'delete' && isLocal) {
            deleteYtPost(v.id);
            toast('Deleted private post');
            await loadMyPosts();
            state.tab = 'library';
            showLibrary();
          }
          if (a === 'share' && watch) {
            if (navigator.clipboard?.writeText) {
              navigator.clipboard.writeText(watch).then(
                () => toast('Link copied'),
                () => toast(watch)
              );
            } else toast(watch);
          }
          if (a === 'open' && watch) {
            window.open(watch, '_blank', 'noopener');
            toast('Opened in browser');
          }
          if (a === 'site' && watch) {
            state.tab = 'web';
            showWeb(watch);
          }
        });
      });

      const listEl = appBody.querySelector('#yt-comment-list');
      const countEl = appBody.querySelector('#yt-c-count');
      const noteEl = appBody.querySelector('#yt-c-note');
      const compose = appBody.querySelector('#yt-compose');
      const composeIn = appBody.querySelector('#yt-compose-in');

      function renderComments(comments) {
        comments = comments || [];
        if (countEl) countEl.textContent = fmtLikes(comments.length);
        if (noteEl) noteEl.textContent = comments.length + ' sim · this browser';
        if (!listEl) return;
        if (!comments.length) {
          listEl.innerHTML =
            '<div class="yt-empty">No comments yet. Be the first — only this browser will see it.</div>';
          return;
        }
        listEl.innerHTML = comments.map(commentHtml).join('');
      }

      function loadComments() {
        renderComments(loadYtComments(v.id));
      }

      compose?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const text = (composeIn?.value || '').trim();
        if (!text) return;
        composeIn.disabled = true;
        saveYtComment(v.id, {
          local: true,
          author: ytAccount.name,
          handle: ytAccount.handle,
          avatar: ytAccount.avatar,
          color: ytAccount.color,
          text,
          likes: 0,
          time: 'now',
        });
        composeIn.value = '';
        toast('Posted (this phone only)');
        pulseIsland('💬 Comment', 1400);
        loadComments();
        composeIn.disabled = false;
        composeIn.focus();
      });
      composeIn?.addEventListener('keydown', (e) => e.stopPropagation());

      loadComments();
      pulseIsland('▶ Playing', 1800);
    }

    function showCreate() {
      state.mode = 'create';
      state.tab = 'create';
      let draft = {
        effect: 'none',
        fileDataUrl: null,
        fileName: '',
        youtubeUrl: '',
        objectUrl: null,
      };

      shell(
        `
        <div class="yt-create">
          <div class="yt-create-head">
            <h2>Create</h2>
            <span class="yt-priv-pill">🔒 Only you · not real YouTube</span>
          </div>
          <div class="yt-create-preview yt-fx yt-fx-none" id="yt-prev-wrap">
            <video class="yt-create-video" id="yt-prev-video" playsinline muted loop></video>
            <div class="yt-create-placeholder" id="yt-prev-ph">Pick a video or paste a YouTube link</div>
            <div class="yt-fx-overlay yt-fx-overlay-none" id="yt-prev-fx"></div>
          </div>
          <div class="yt-create-actions">
            <label class="yt-file-btn">
              📁 Choose video
              <input type="file" id="yt-file" accept="video/*" hidden />
            </label>
            <button type="button" class="yt-file-btn secondary" id="yt-cam-btn">📷 Camera</button>
          </div>
          <input type="file" id="yt-cam" accept="video/*" capture="environment" hidden />
          <div class="yt-create-field">
            <label>Or YouTube URL</label>
            <input type="text" id="yt-src-url" placeholder="https://youtube.com/watch?v=…" />
          </div>
          <div class="yt-create-field">
            <label>Title</label>
            <input type="text" id="yt-title" maxlength="120" placeholder="Title your video" />
          </div>
          <div class="yt-create-field">
            <label>Description</label>
            <textarea id="yt-desc" maxlength="500" rows="2" placeholder="Optional"></textarea>
          </div>
          <div class="yt-create-field">
            <label>Effect</label>
            <div class="yt-fx-chips" id="yt-fx-chips">
              ${EFFECTS.map(
                (e) =>
                  `<button type="button" class="yt-fx-chip ${e.id === 'none' ? 'on' : ''}" data-fx="${e.id}">${e.label}</button>`
              ).join('')}
            </div>
          </div>
          <p class="yt-create-note">Posted only in this browser. Real YouTube never sees it.</p>
          <button type="button" class="yt-post-btn" id="yt-post-btn">Post video</button>
          <div class="yt-create-status" id="yt-post-status"></div>
        </div>
      `,
        { hideTop: true }
      );

      const wrap = appBody.querySelector('#yt-prev-wrap');
      const video = appBody.querySelector('#yt-prev-video');
      const ph = appBody.querySelector('#yt-prev-ph');
      const fxOverlay = appBody.querySelector('#yt-prev-fx');
      const fileIn = appBody.querySelector('#yt-file');
      const camIn = appBody.querySelector('#yt-cam');
      const statusEl = appBody.querySelector('#yt-post-status');

      function applyFx(id) {
        draft.effect = id;
        EFFECTS.forEach((e) => {
          wrap?.classList.toggle('yt-fx-' + e.id, e.id === id);
        });
        if (fxOverlay) {
          fxOverlay.className = 'yt-fx-overlay yt-fx-overlay-' + id;
        }
        appBody.querySelectorAll('[data-fx]').forEach((b) => {
          b.classList.toggle('on', b.dataset.fx === id);
        });
      }

      function showPreviewFile(dataUrl, name) {
        draft.fileDataUrl = dataUrl;
        draft.fileName = name || 'video';
        draft.youtubeUrl = '';
        const urlIn = appBody.querySelector('#yt-src-url');
        if (urlIn) urlIn.value = '';
        if (video) {
          video.src = dataUrl;
          video.style.display = 'block';
          video.play().catch(() => {});
        }
        if (ph) ph.style.display = 'none';
      }

      function readFile(file) {
        if (!file) return;
        if (file.size > 12 * 1024 * 1024) {
          toast('Max 12MB video');
          return;
        }
        const reader = new FileReader();
        reader.onload = () => showPreviewFile(String(reader.result), file.name);
        reader.onerror = () => toast('Could not read file');
        reader.readAsDataURL(file);
      }

      fileIn?.addEventListener('change', () => readFile(fileIn.files && fileIn.files[0]));
      appBody.querySelector('#yt-cam-btn')?.addEventListener('click', () => camIn?.click());
      camIn?.addEventListener('change', () => readFile(camIn.files && camIn.files[0]));

      appBody.querySelector('#yt-src-url')?.addEventListener('input', (e) => {
        const u = e.target.value.trim();
        draft.youtubeUrl = u;
        if (extractYtId(u)) {
          draft.fileDataUrl = null;
          if (video) {
            video.removeAttribute('src');
            video.style.display = 'none';
            video.load();
          }
          if (ph) {
            ph.style.display = 'flex';
            ph.textContent = 'YouTube clip · effect applies when posted';
          }
        }
      });

      appBody.querySelectorAll('[data-fx]').forEach((btn) => {
        btn.addEventListener('click', () => applyFx(btn.dataset.fx));
      });

      appBody.querySelector('#yt-post-btn')?.addEventListener('click', async () => {
        const title =
          (appBody.querySelector('#yt-title')?.value || '').trim() ||
          draft.fileName ||
          'My video';
        const description = (appBody.querySelector('#yt-desc')?.value || '').trim();
        const ytUrl = (appBody.querySelector('#yt-src-url')?.value || '').trim();
        const yid = extractYtId(ytUrl);
        if (!draft.fileDataUrl && !yid) {
          toast('Choose a video file or paste a YouTube URL');
          return;
        }
        const btn = appBody.querySelector('#yt-post-btn');
        if (btn) btn.disabled = true;
        if (statusEl) statusEl.textContent = 'Posting (private)…';
        const post = {
          id: 'local-' + Date.now().toString(36),
          local: true,
          title,
          description,
          effect: draft.effect,
          channel: ytAccount.name,
          avatar: ytAccount.avatar,
          color: ytAccount.color,
          views: 'Only you',
          duration: draft.fileDataUrl ? 'local' : '',
        };
        if (draft.fileDataUrl) {
          post.kind = 'file';
          post.src = draft.fileDataUrl;
        } else {
          post.kind = 'youtube';
          post.youtubeSource = yid;
          post.thumb = 'https://i.ytimg.com/vi/' + yid + '/hqdefault.jpg';
        }
        saveYtPost(post);
        toast('Posted · only you can see it');
        pulseIsland('Posted', 1600);
        await loadMyPosts();
        playVideo(post);
      });
    }

    async function showLibrary() {
      state.mode = 'feed';
      await loadMyPosts();
      const my =
        state.myPosts.length > 0
          ? state.myPosts.map(cardHtml).join('')
          : '<div class="yt-empty">No private uploads yet.<br/>Tap <b>Create</b> (＋) to post.</div>';
      const items = ytHistory.length
        ? ytHistory
            .map(
              (v) =>
                miniHtml({
                  id: v.id,
                  title: v.title,
                  channel: v.channel,
                  thumb: v.thumb || 'https://i.ytimg.com/vi/' + v.id + '/hqdefault.jpg',
                })
            )
            .join('')
        : '<div class="yt-empty">Watch history is empty.</div>';
      shell(`
        <div class="yt-feed" style="padding-top:8px">
          <div class="yt-account-bar yt-account-bar-page">
            <div class="yt-acc-av" style="background:${esc(ytAccount.color)}">${esc(ytAccount.avatar)}</div>
            <div class="yt-acc-meta">
              <b>${esc(ytAccount.name)}</b>
              <span>Signed in · ${esc(ytAccount.handle)}</span>
            </div>
            <span class="yt-acc-pill">● Online</span>
          </div>
          <button type="button" class="yt-post-btn yt-post-btn-inline" data-tab="create">＋ Create / Post video</button>
          <p class="yt-acc-blurb">Your posts & comments stay in <b>this</b> browser only — never on real YouTube.</p>
          <form class="yt-acc-edit" id="yt-acc-edit" action="javascript:void(0)">
            <input id="yt-acc-name" type="text" maxlength="40" value="${esc(ytAccount.name)}" placeholder="Display name" />
            <input id="yt-acc-handle" type="text" maxlength="40" value="${esc(ytAccount.handle)}" placeholder="@handle" />
            <button type="submit" class="yt-act">Save profile</button>
          </form>
          <div class="yt-related-h">Your videos <span class="yt-priv-pill">Only you</span></div>
          ${my}
          <div class="yt-related-h">History</div>
          ${items}
          <div class="yt-related-h" style="margin-top:12px">Paste a link</div>
          <form class="yt-top" style="border:none" action="javascript:void(0)" id="yt-paste">
            <input class="yt-search" id="yt-paste-in" type="text" placeholder="youtube.com/watch?v=… or video ID" />
            <button type="submit" class="yt-search-btn">▶</button>
          </form>
        </div>
      `);
      appBody.querySelector('#yt-paste')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const q = (appBody.querySelector('#yt-paste-in')?.value || '').trim();
        if (!q) return;
        state.query = q;
        doSearch(q);
      });
      appBody.querySelector('#yt-acc-edit')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = (appBody.querySelector('#yt-acc-name')?.value || '').trim() || 'Arkhē User';
        let handle = (appBody.querySelector('#yt-acc-handle')?.value || '').trim() || '@arkhe.sim';
        if (!handle.startsWith('@')) handle = '@' + handle;
        ytAccount = {
          ...ytAccount,
          name: name.slice(0, 40),
          handle: handle.slice(0, 40),
          avatar:
            name
              .split(/\s+/)
              .map((w) => w[0])
              .join('')
              .slice(0, 2)
              .toUpperCase() || 'AU',
        };
        saveYtAccount();
        toast('Signed in as ' + ytAccount.name);
        showLibrary();
      });
    }

    function showWeb(startUrl) {
      state.mode = 'web';
      state.tab = 'web';
      const url = startUrl || 'https://m.youtube.com/';
      shell(
        `
        <div class="yt-web">
          <div class="yt-web-bar">
            <input type="text" id="yt-web-url" value="${esc(url)}" />
            <button type="button" class="yt-act" id="yt-web-go">Go</button>
            <button type="button" class="yt-act" id="yt-web-ext">↗</button>
          </div>
          <iframe class="yt-web-frame" id="yt-web-frame" src="${esc(url)}" title="YouTube site" referrerpolicy="no-referrer-when-downgrade"></iframe>
          <div class="yt-web-note">
            Full youtube.com often blocks in-app browsers. If blank, use
            <b>↗</b> or Home embeds (always work offline with the sample catalog).
            <br/><a href="${esc(url)}" target="_blank" rel="noopener">Open ${esc(url)}</a>
          </div>
        </div>
      `,
        { hideTop: true, hideTabs: false }
      );
      const frame = appBody.querySelector('#yt-web-frame');
      const urlIn = appBody.querySelector('#yt-web-url');
      const go = () => {
        let u = (urlIn.value || '').trim();
        if (!u) return;
        if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
        urlIn.value = u;
        const id = extractYtId(u);
        if (id) {
          doSearch(id);
          return;
        }
        if (frame) frame.src = u;
      };
      appBody.querySelector('#yt-web-go')?.addEventListener('click', go);
      urlIn?.addEventListener('keydown', (e) => {
        e.stopPropagation();
        if (e.key === 'Enter') {
          e.preventDefault();
          go();
        }
      });
      appBody.querySelector('#yt-web-ext')?.addEventListener('click', () => {
        window.open(urlIn?.value || url, '_blank', 'noopener');
      });
    }

    appBackHandler = () => {
      if (state.mode === 'player') {
        state.playing = null;
        state.mode = 'feed';
        if (state.tab === 'library') showLibrary();
        else if (state.tab === 'create') showCreate();
        else paintFeed();
        return true;
      }
      if (state.mode === 'create') {
        state.tab = 'home';
        state.mode = 'feed';
        loadTrending();
        return true;
      }
      if (state.mode === 'web' && state.tab !== 'web') {
        state.mode = 'feed';
        paintFeed();
        return true;
      }
      if (state.tab !== 'home' || state.query) {
        state.tab = 'home';
        state.query = '';
        state.chip = 'All';
        loadTrending();
        return true;
      }
      return false;
    };

    loadTrending();
  }

  /* ---------- Phone keypad ---------- */
  function renderPhone() {
    appTitle.textContent = 'Phone';
    let num = '';
    appBody.innerHTML = `
      <div class="phone-app">
        <div class="phone-num" id="p-num"></div>
        <div class="phone-keypad">
          ${['1','2','3','4','5','6','7','8','9','*','0','#'].map((k) => {
            const sub = { 2: 'ABC', 3: 'DEF', 4: 'GHI', 5: 'JKL', 6: 'MNO', 7: 'PQRS', 8: 'TUV', 9: 'WXYZ', 0: '+' }[k] || '';
            return `<button type="button" class="pk" data-k="${k}">${k}${sub ? `<small>${sub}</small>` : ''}</button>`;
          }).join('')}
        </div>
        <button type="button" class="phone-call-btn" id="p-call" title="Call">📞</button>
        <div class="phone-tabs">
          <span>Favourites</span><span>Recents</span><span class="on">Keypad</span><span>Contacts</span><span>Voicemail</span>
        </div>
      </div>`;
    const display = appBody.querySelector('#p-num');
    appBody.querySelectorAll('[data-k]').forEach((btn) => {
      btn.addEventListener('click', () => {
        if (num.length >= 15) return;
        num += btn.dataset.k;
        display.textContent = formatPhone(num);
      });
    });
    appBody.querySelector('#p-call').addEventListener('click', () => {
      if (!num) {
        toast('Enter a number');
        return;
      }
      pulseIsland('Calling…', 2500);
      toast('Calling ' + formatPhone(num) + '…');
      setTimeout(() => toast('Call ended (sim)'), 2800);
    });
  }

  function formatPhone(n) {
    const d = n.replace(/\D/g, '');
    if (d.length <= 3) return d;
    if (d.length <= 6) return `(${d.slice(0, 3)}) ${d.slice(3)}`;
    return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6, 10)}`;
  }

  /* ---------- Safari ---------- */
  function renderSafari() {
    appTitle.textContent = 'Safari';
    appBody.innerHTML = `
      <div class="safari">
        <div class="safari-bar">
          <input class="safari-url" value="kid-arcade.local" readonly />
        </div>
        <div class="safari-frame">
          <h2>Welcome</h2>
          <p>Simulated Safari start page on the Phone Simulator.</p>
          <p>Favourites open in-sim. Real browsing stays in your browser.</p>
          <div class="safari-links">
            <button type="button" data-go="roblox">Roblox (real)</button>
            <button type="button" data-go="youtube">YouTube</button>
            <button type="button" data-go="messages">Open Messages</button>
            <button type="button" data-go="weather">Weather</button>
            <button type="button" data-go="games">Arcade</button>
            <button type="button" data-go="bird">I Am Bird</button>
            <button type="button" data-go="monkey">I Am Monkey</button>
            <button type="button" data-go="rbxweb">roblox.com ↗</button>
            <button type="button" data-go="ytweb">m.youtube.com ↗</button>
          </div>
        </div>
      </div>`;
    appBody.querySelectorAll('[data-go]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const g = btn.dataset.go;
        if (g === 'ytweb') {
          window.open('https://m.youtube.com/', '_blank', 'noopener');
          toast('Opening YouTube…');
        } else if (g === 'rbxweb') {
          window.open('https://www.roblox.com/discover', '_blank', 'noopener');
          toast('Opening Roblox…');
        } else if (g === 'bird') {
          openRelative('../../games/i-am-bird/', 'I Am Bird');
        } else if (g === 'monkey') {
          openRelative('../../games/i-am-monkey/', 'I Am Monkey');
        } else openApp(g);
      });
    });
  }

  /* ---------- Roblox (static sample + real site) ---------- */
  function renderRoblox() {
    appTitle.textContent = 'Roblox';
    const state = {
      tab: 'home',
      sorts: [],
      games: [],
      query: '',
      source: '',
    };

    function shell(inner) {
      appBody.innerHTML = `
        <div class="rbx">
          <div class="rbx-top">
            <div class="rbx-logo"><span class="rbx-mark">R</span> Roblox</div>
            <form class="rbx-search-wrap" action="javascript:void(0)">
              <input class="rbx-search" type="search" placeholder="Search experiences" value="${esc(state.query)}" enterkeyhint="search" />
            </form>
          </div>
          ${inner}
          <div class="rbx-tabs">
            <button type="button" class="rbx-tab ${state.tab === 'home' ? 'on' : ''}" data-rtab="home"><span>⌂</span>Home</button>
            <button type="button" class="rbx-tab ${state.tab === 'charts' ? 'on' : ''}" data-rtab="charts"><span>★</span>Charts</button>
            <button type="button" class="rbx-tab ${state.tab === 'play' ? 'on' : ''}" data-rtab="play"><span>▶</span>Play</button>
            <button type="button" class="rbx-tab ${state.tab === 'more' ? 'on' : ''}" data-rtab="more"><span>⋯</span>More</button>
          </div>
        </div>`;
      appBody.querySelector('.rbx-search-wrap')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const q = (appBody.querySelector('.rbx-search')?.value || '').trim();
        if (!q) return;
        state.query = q;
        doSearch(q);
      });
      appBody.querySelector('.rbx-search')?.addEventListener('keydown', (e) => e.stopPropagation());
      appBody.querySelectorAll('[data-rtab]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const t = btn.dataset.rtab;
          state.tab = t;
          if (t === 'home' || t === 'charts') loadDiscover();
          else if (t === 'play') showPlayHub();
          else if (t === 'more') showMore();
        });
      });
      wireGameCards();
    }

    function gameCard(g) {
      const thumb = g.thumb
        ? `background-image:url('${esc(g.thumb)}')`
        : 'background:linear-gradient(135deg,#e2231a,#3a1010)';
      const sub = [g.playersLabel, g.rating != null ? g.rating + '%' : '', g.creator]
        .filter(Boolean)
        .join(' · ');
      return `
        <button type="button" class="rbx-card" data-place="${esc(g.placeId || '')}" data-url="${esc(g.playUrl || '')}" data-app="${esc(g.appUrl || '')}" data-name="${esc(g.name || '')}">
          <div class="rbx-thumb" style="${thumb}"></div>
          <div class="rbx-meta">
            <b>${esc(g.name || 'Experience')}</b>
            <span>${esc(sub)}</span>
          </div>
          <span class="rbx-play">Play</span>
        </button>`;
    }

    function wireGameCards() {
      appBody.querySelectorAll('.rbx-card').forEach((btn) => {
        btn.addEventListener('click', () => playGame(btn.dataset));
      });
      appBody.querySelectorAll('[data-rbx-open]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const u = btn.dataset.rbxOpen;
          window.open(u, '_blank', 'noopener');
          toast('Opening real Roblox…');
          pulseIsland('Roblox', 1600);
        });
      });
    }

    function playGame(ds) {
      const name = ds.name || 'Experience';
      const web = ds.url || 'https://www.roblox.com/discover';
      const app = ds.app;
      if (app && app.startsWith('roblox:')) {
        try {
          const a = document.createElement('a');
          a.href = app;
          a.style.display = 'none';
          document.body.appendChild(a);
          a.click();
          a.remove();
        } catch {
          /* ignore */
        }
      }
      window.open(web, '_blank', 'noopener');
      toast('Playing ' + name + ' on real Roblox');
      pulseIsland('▶ ' + name.slice(0, 18), 2000);
    }

    function paintDiscover() {
      const sections = (state.sorts || [])
        .map((s) => {
          const cards = (s.games || []).slice(0, 24).map(gameCard).join('');
          return `
            <section class="rbx-section">
              <h3>${esc(s.name || 'Games')}</h3>
              <div class="rbx-grid">${cards || '<div class="rbx-empty">No games</div>'}</div>
            </section>`;
        })
        .join('');
      shell(`
        <div class="rbx-body">
          <div class="rbx-banner">
            <div>
              <b>Real Roblox</b>
              <span>Sample catalog · Play opens Roblox web/app</span>
            </div>
            <button type="button" class="rbx-banner-btn" data-rbx-open="https://www.roblox.com/home">Open site</button>
          </div>
          <div class="rbx-status">${esc(state.source || 'Loading…')}</div>
          ${
            sections ||
            '<div class="rbx-empty">Couldn’t load catalog.</div>'
          }
          <div class="rbx-local">
            <h3>Kid Arcade (this pack)</h3>
            <button type="button" class="rbx-card local" data-local="bird">
              <div class="rbx-thumb" style="background:linear-gradient(135deg,#6af,#f6c);display:grid;place-items:center;font-size:28px">🐦</div>
              <div class="rbx-meta"><b>I Am Bird</b><span>In this pack</span></div>
              <span class="rbx-play">Open</span>
            </button>
            <button type="button" class="rbx-card local" data-local="monkey" style="margin-top:8px">
              <div class="rbx-thumb" style="background:linear-gradient(135deg,#f80,#a40);display:grid;place-items:center;font-size:28px">🐒</div>
              <div class="rbx-meta"><b>I Am Monkey</b><span>In this pack</span></div>
              <span class="rbx-play">Open</span>
            </button>
          </div>
        </div>
      `);
      appBody.querySelector('[data-local="bird"]')?.addEventListener('click', () => {
        openRelative('../../games/i-am-bird/', 'I Am Bird');
      });
      appBody.querySelector('[data-local="monkey"]')?.addEventListener('click', () => {
        openRelative('../../games/i-am-monkey/', 'I Am Monkey');
      });
    }

    async function loadDiscover() {
      shell(`<div class="rbx-body"><div class="rbx-empty">Loading sample catalog…</div></div>`);
      state.sorts = [
        { name: 'Popular samples', games: ROBLOX_SAMPLE.slice(0, 4) },
        { name: 'More', games: ROBLOX_SAMPLE.slice(4) },
      ];
      state.source = 'static sample · play = real Roblox';
      paintDiscover();
      pulseIsland('Roblox', 1200);
    }

    async function doSearch(q) {
      shell(`<div class="rbx-body"><div class="rbx-empty">Searching “${esc(q)}”…</div></div>`);
      const ql = q.toLowerCase();
      state.games = ROBLOX_SAMPLE.filter(
        (g) => g.name.toLowerCase().includes(ql) || (g.creator || '').toLowerCase().includes(ql)
      );
      if (!state.games.length) {
        state.games = [
          {
            name: 'Search on roblox.com',
            placeId: '',
            playersLabel: 'Open site',
            creator: 'Roblox',
            playUrl: 'https://www.roblox.com/discover/?Keyword=' + encodeURIComponent(q),
            appUrl: 'roblox://',
          },
        ];
      }
      state.source = 'static search';
      shell(`
        <div class="rbx-body">
          <div class="rbx-status">Results for “${esc(q)}” · ${state.games.length}</div>
          <div class="rbx-grid list">${state.games.map(gameCard).join('')}</div>
        </div>
      `);
    }

    function showPlayHub() {
      state.tab = 'play';
      shell(`
        <div class="rbx-body rbx-play-hub">
          <div class="rbx-hero">
            <div class="rbx-mark big">R</div>
            <h2>Play on real Roblox</h2>
            <p>Roblox blocks embedding. This app launches the <b>real</b> Roblox website or app.</p>
          </div>
          <button type="button" class="rbx-cta" data-rbx-open="https://www.roblox.com/home">Open Roblox Home</button>
          <button type="button" class="rbx-cta secondary" data-rbx-open="https://www.roblox.com/discover">Discover experiences</button>
          <button type="button" class="rbx-cta secondary" data-rbx-open="https://www.roblox.com/charts">Charts</button>
          <button type="button" class="rbx-cta ghost" data-rbx-open="roblox://">Open Roblox app</button>
          <p class="rbx-fine">Sign in on roblox.com. Gameplay runs in Roblox — not inside this toy phone frame.</p>
        </div>
      `);
    }

    function showMore() {
      state.tab = 'more';
      shell(`
        <div class="rbx-body">
          <div class="rbx-more">
            <h3>About this Roblox app</h3>
            <p>Public Pages build ships a <b>static sample catalog</b> (no API proxy).</p>
            <p><b>Play</b> opens real <code>roblox.com</code> (and tries the Roblox app deep link if installed).</p>
            <button type="button" class="rbx-cta" data-rbx-open="https://www.roblox.com/">Go to roblox.com</button>
            <button type="button" class="rbx-cta secondary" data-local-bird>Open I Am Bird</button>
          </div>
        </div>
      `);
      appBody.querySelector('[data-local-bird]')?.addEventListener('click', () => {
        openRelative('../../games/i-am-bird/', 'I Am Bird');
      });
    }

    appBackHandler = () => {
      if (state.query || state.tab !== 'home') {
        state.query = '';
        state.tab = 'home';
        loadDiscover();
        return true;
      }
      return false;
    };

    loadDiscover();
  }

  /* ---------- Camera ---------- */
  function renderCamera() {
    appBody.innerHTML = `
      <div class="camera">
        <div class="camera-view">
          <div class="preview-label">Camera preview</div>
        </div>
        <div class="cam-modes"><span>CINEMATIC</span><span>VIDEO</span><span class="on">PHOTO</span><span>PORTRAIT</span><span>PANO</span></div>
        <div class="camera-shutter-row">
          <div class="cam-thumb" id="cam-thumb"></div>
          <button type="button" class="cam-shutter" id="cam-shutter" aria-label="Shutter"><i></i></button>
          <button type="button" class="cam-flip" title="Flip">↺</button>
        </div>
      </div>`;
    const colors = [
      'linear-gradient(135deg,#ff6b9d,#5b8cff)',
      'linear-gradient(135deg,#30d158,#64d2ff)',
      'linear-gradient(135deg,#ffd60a,#ff9f0a)',
      'linear-gradient(135deg,#bf5af2,#ff375f)',
    ];
    let i = 0;
    appBody.querySelector('#cam-shutter').addEventListener('click', () => {
      const c = colors[i++ % colors.length];
      appBody.querySelector('#cam-thumb').style.background = c;
      screen.style.transition = 'filter 0.08s';
      screen.style.filter = 'brightness(2)';
      setTimeout(() => {
        screen.style.filter = '';
      }, 80);
      pulseIsland('Photo saved', 1500);
      toast('Saved to Photos');
    });
  }

  function renderPhotos() {
    appTitle.textContent = 'Photos';
    const grads = [
      'linear-gradient(135deg,#ff6bcb,#5b8cff)',
      'linear-gradient(135deg,#30d158,#64d2ff)',
      'linear-gradient(135deg,#ffd60a,#ff9f0a)',
      'linear-gradient(135deg,#bf5af2,#ff375f)',
      'linear-gradient(135deg,#5ac8fa,#007aff)',
      'linear-gradient(135deg,#a2845e,#636366)',
      'linear-gradient(135deg,#ff453a,#ff6961)',
      'linear-gradient(135deg,#64e07a,#1a9a3a)',
      'linear-gradient(135deg,#c77dff,#5b8cff)',
    ];
    appBody.innerHTML = `<div class="photos-grid">${grads.map((g) => `<div style="background:${g}"></div>`).join('')}</div>`;
  }

  function renderMusic() {
    appTitle.textContent = 'Music';
    appBody.innerHTML = `
      <div class="music-now">
        <div class="music-art"></div>
        <h3>Neon Desk Dreams</h3>
        <p>Arkhē Mix · Simulated</p>
        <div class="music-prog"><i></i></div>
        <div class="music-times"><span>1:12</span><span>3:28</span></div>
        <div class="music-controls">
          <button type="button">⏮</button>
          <button type="button" class="play" id="music-play">${musicPlaying ? '❚❚' : '▶'}</button>
          <button type="button">⏭</button>
        </div>
      </div>`;
    appBody.querySelector('#music-play').addEventListener('click', (e) => {
      musicPlaying = !musicPlaying;
      e.currentTarget.textContent = musicPlaying ? '❚❚' : '▶';
      pulseIsland(musicPlaying ? '♪ Playing' : 'Paused', 1800);
    });
  }

  function renderWeather() {
    appTitle.textContent = '';
    appBody.innerHTML = `
      <div class="weather">
        <div class="city">Cupertino</div>
        <div class="temp">72°</div>
        <div class="cond">Partly Cloudy</div>
        <div class="hi-lo">H:76°  L:58°</div>
        <div class="weather-card">
          <h4>Hourly forecast</h4>
          <div class="weather-hours">
            <div><span>Now</span><b>72°</b>☀️</div>
            <div><span>1PM</span><b>74°</b>☀️</div>
            <div><span>2PM</span><b>75°</b>⛅</div>
            <div><span>3PM</span><b>76°</b>⛅</div>
            <div><span>4PM</span><b>74°</b>🌤</div>
            <div><span>5PM</span><b>71°</b>🌤</div>
          </div>
        </div>
      </div>`;
  }

  function renderClock() {
    appTitle.textContent = 'Clock';
    const d = new Date();
    appBody.innerHTML = `
      <div class="clock-face">
        <div class="clock-digital" id="clk-d">${d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>
        <div class="clock-date-sub">${d.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</div>
        <div class="world-clocks">
          <div class="wc-row"><div><b>Cupertino</b><span>Today</span></div><div class="t" data-tz="America/Los_Angeles"></div></div>
          <div class="wc-row"><div><b>New York</b><span>Today</span></div><div class="t" data-tz="America/New_York"></div></div>
          <div class="wc-row"><div><b>London</b><span>—</span></div><div class="t" data-tz="Europe/London"></div></div>
          <div class="wc-row"><div><b>Tokyo</b><span>—</span></div><div class="t" data-tz="Asia/Tokyo"></div></div>
        </div>
      </div>`;
    function tick() {
      if (currentApp !== 'clock') return;
      const now = new Date();
      const el = appBody.querySelector('#clk-d');
      if (el) {
        el.textContent = now.toLocaleTimeString(undefined, {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
      }
      appBody.querySelectorAll('[data-tz]').forEach((node) => {
        try {
          node.textContent = now.toLocaleTimeString(undefined, {
            timeZone: node.dataset.tz,
            hour: 'numeric',
            minute: '2-digit',
          });
        } catch {
          node.textContent = '—';
        }
      });
      requestAnimationFrame(() => setTimeout(tick, 250));
    }
    tick();
  }

  function renderCalc() {
    appTitle.textContent = 'Calculator';
    let display = '0';
    let acc = null;
    let op = null;
    let fresh = true;
    appBody.innerHTML = `
      <div class="calc">
        <div class="calc-display" id="c-disp">0</div>
        <div class="calc-keys">
          <button type="button" class="ck fn" data-c="ac">AC</button>
          <button type="button" class="ck fn" data-c="sign">+/−</button>
          <button type="button" class="ck fn" data-c="pct">%</button>
          <button type="button" class="ck op" data-c="/">÷</button>
          <button type="button" class="ck" data-c="7">7</button>
          <button type="button" class="ck" data-c="8">8</button>
          <button type="button" class="ck" data-c="9">9</button>
          <button type="button" class="ck op" data-c="*">×</button>
          <button type="button" class="ck" data-c="4">4</button>
          <button type="button" class="ck" data-c="5">5</button>
          <button type="button" class="ck" data-c="6">6</button>
          <button type="button" class="ck op" data-c="-">−</button>
          <button type="button" class="ck" data-c="1">1</button>
          <button type="button" class="ck" data-c="2">2</button>
          <button type="button" class="ck" data-c="3">3</button>
          <button type="button" class="ck op" data-c="+">+</button>
          <button type="button" class="ck zero" data-c="0">0</button>
          <button type="button" class="ck" data-c=".">.</button>
          <button type="button" class="ck op" data-c="=">=</button>
        </div>
      </div>`;
    const disp = appBody.querySelector('#c-disp');
    function show() {
      disp.textContent = display.length > 10 ? Number(display).toExponential(5) : display;
    }
    function compute() {
      const a = acc;
      const b = parseFloat(display);
      if (a == null || op == null) return b;
      if (op === '+') return a + b;
      if (op === '-') return a - b;
      if (op === '*') return a * b;
      if (op === '/') return b === 0 ? 0 : a / b;
      return b;
    }
    appBody.querySelectorAll('[data-c]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const c = btn.dataset.c;
        if (c === 'ac') {
          display = '0';
          acc = null;
          op = null;
          fresh = true;
        } else if (c === 'sign') {
          display = String(-parseFloat(display));
        } else if (c === 'pct') {
          display = String(parseFloat(display) / 100);
        } else if ('+-*/'.includes(c)) {
          acc = compute();
          op = c;
          display = String(acc);
          fresh = true;
        } else if (c === '=') {
          display = String(compute());
          acc = null;
          op = null;
          fresh = true;
        } else if (c === '.') {
          if (fresh) {
            display = '0.';
            fresh = false;
          } else if (!display.includes('.')) display += '.';
        } else {
          if (fresh || display === '0') {
            display = c;
            fresh = false;
          } else display += c;
        }
        show();
      });
    });
  }

  function renderSettings() {
    appTitle.textContent = 'Settings';
    appBody.innerHTML = `
      <div class="settings">
        <div class="set-profile">
          <div class="set-avatar"></div>
          <div><b>Arkhē User</b><span>Simulator account</span></div>
        </div>
        <div class="set-group">
          <div class="set-row"><div class="set-ico" style="background:#0a84ff">✈</div>Airplane Mode <span class="val">Off</span></div>
          <div class="set-row"><div class="set-ico" style="background:#30d158">📶</div>Wi‑Fi <span class="val">KidArcade</span><span class="chev">›</span></div>
          <div class="set-row"><div class="set-ico" style="background:#0a84ff">ᛒ</div>Bluetooth <span class="val">On</span><span class="chev">›</span></div>
          <div class="set-row"><div class="set-ico" style="background:#ff2d55">📡</div>Cellular <span class="chev">›</span></div>
        </div>
        <div class="set-group">
          <div class="set-row"><div class="set-ico" style="background:#8e8e93">🔔</div>Notifications <span class="chev">›</span></div>
          <div class="set-row"><div class="set-ico" style="background:#5e5ce6">🌙</div>Focus <span class="chev">›</span></div>
          <div class="set-row"><div class="set-ico" style="background:#ff9f0a">⏱</div>Screen Time <span class="chev">›</span></div>
        </div>
        <div class="set-group">
          <div class="set-row"><div class="set-ico" style="background:#0a84ff">Aa</div>Display & Brightness <span class="val">${brightness}%</span></div>
          <div class="set-row"><div class="set-ico" style="background:#ff2d55">🔊</div>Sounds & Haptics <span class="val">${volume}%</span></div>
          <div class="set-row"><div class="set-ico" style="background:#636366">⚙️</div>General <span class="chev">›</span></div>
        </div>
        <div class="set-group">
          <div class="set-row"><div class="set-ico" style="background:#30d158">💬</div>Chat brain <span class="val" id="set-model">…</span></div>
          <div class="set-row"><div class="set-ico" style="background:#bf5af2">📱</div>About <span class="val">Phone Sim · Pages</span></div>
        </div>
      </div>`;
    refreshChatStatus(appBody.querySelector('#set-model'));
  }

  function renderNotes() {
    appTitle.textContent = 'Notes';
    const notes = [
      { t: 'Ideas', b: 'Phone sim · arcade · desk pets' },
      { t: 'Groceries', b: 'Milk, oats, pixel snacks' },
      { t: 'Todo', b: 'Ship something fun today' },
    ];
    let editing = null;
    function list() {
      appTitle.textContent = 'Notes';
      appBody.innerHTML = `
        <div class="notes">
          ${notes
            .map(
              (n, i) =>
                `<button type="button" class="note-item" data-n="${i}"><b>${esc(n.t)}</b><span>${esc(n.b)}</span></button>`
            )
            .join('')}
        </div>`;
      appBody.querySelectorAll('[data-n]').forEach((btn) => {
        btn.addEventListener('click', () => edit(+btn.dataset.n));
      });
    }
    function edit(i) {
      editing = i;
      appTitle.textContent = notes[i].t;
      appBody.innerHTML = `
        <div class="notes">
          <textarea class="note-editor">${esc(notes[i].b)}</textarea>
        </div>`;
      const ta = appBody.querySelector('textarea');
      ta.addEventListener('input', () => {
        notes[i].b = ta.value;
      });
      ta.focus();
    }
    appBackHandler = () => {
      if (editing != null) {
        editing = null;
        list();
        return true;
      }
      return false;
    };
    list();
  }

  function renderMaps() {
    appTitle.textContent = 'Maps';
    appBody.innerHTML = `
      <div class="maps">
        <div class="maps-search">Search Maps</div>
        <div class="maps-pin">📍</div>
        <div class="maps-card">
          <b>You are here</b>
          <span>Phone Simulator · Cupertino-ish</span>
        </div>
      </div>`;
  }

  function renderMail() {
    appTitle.textContent = 'Inbox';
    const mails = [
      { from: 'Job Corp™', subj: 'Your shift report', snip: 'Productivity index: adequate.' },
      { from: 'Kinito', subj: 'Hello from the desk', snip: 'I left you a pixel snack…' },
      { from: 'Kid Arcade', subj: 'Welcome to your phone', snip: 'This is a fan simulation.' },
    ];
    appBody.innerHTML = `
      <div class="mail-list">
        ${mails
          .map(
            (m) => `
          <button type="button" class="mail-row">
            <div class="from">${esc(m.from)}</div>
            <b>${esc(m.subj)}</b>
            <div class="snip">${esc(m.snip)}</div>
          </button>`
          )
          .join('')}
      </div>`;
  }

  function renderWallet() {
    appTitle.textContent = 'Wallet';
    appBody.innerHTML = `
      <div class="wallet">
        <div class="wallet-card apple-cash">
          <div class="brand">Sim Cash</div>
          <div class="num">$42.00</div>
        </div>
        <div class="wallet-card transit">
          <div class="brand">Transit Card</div>
          <div class="num">···· 8842</div>
        </div>
      </div>`;
  }

  /* ---------- Games / App Store — relative pack URLs ---------- */
  function renderGames(mode) {
    appTitle.textContent = mode === 'appstore' ? 'App Store' : 'Arcade';
    const games = [
      { t: 'Mac Simulator', d: 'Full desktop · all games inside', e: '💻', c: 'linear-gradient(135deg,#5ac8fa,#0a84ff)', url: '../../mac/' },
      { t: 'I Am Bird', d: 'Bird POV · stars not gore', e: '🐦', c: 'linear-gradient(135deg,#6af,#f6c)', url: '../../games/i-am-bird/' },
      { t: 'I Am Monkey', d: 'Mitts · Ellie chat', e: '🐒', c: 'linear-gradient(135deg,#f80,#a40)', url: '../../games/i-am-monkey/' },
      { t: 'BLOXY Classic', d: '2008-style build & play', e: '🧱', c: 'linear-gradient(135deg,#6cf,#08f)', url: '../../games/bloxy-classic/' },
      { t: 'I Am Cat', d: 'Cat house POV', e: '🐱', c: 'linear-gradient(135deg,#f80,#a40)', url: '../../games/i-am-cat/' },
      { t: 'Job Sim', d: 'Comedy job shifts', e: '💼', c: 'linear-gradient(135deg,#68f,#24a)', url: '../../games/job-sim/' },
      { t: 'Day Life Sim', d: 'One full day', e: '☀️', c: 'linear-gradient(135deg,#fd6,#f80)', url: '../../games/life-day-sim/' },
      { t: 'Minecraft Grass', d: 'Voxel grass mini', e: '🟩', c: 'linear-gradient(135deg,#3a8,#1a5)', url: '../../games/minecraft-grass/' },
      { t: 'Presscoin Clicker', d: 'Click Me!', e: '🪙', c: 'linear-gradient(135deg,#f5c542,#c90)', url: '../../games/presscoin-clicker/' },
      { t: 'Pixel Noob Player', d: 'Chiptune toy', e: '🎵', c: 'linear-gradient(135deg,#a78bfa,#6c9eff)', url: '../../games/pixel-noob-player/' },
      { t: 'Pixl Singing Monsters', d: 'Monster jam', e: '👾', c: 'linear-gradient(135deg,#7c3aed,#22d3ee)', url: '../../games/pixl-singing-monsters/' },
      { t: 'Roblox 2016 Web', d: 'Classic shell fan toy', e: '🟥', c: 'linear-gradient(135deg,#e2231a,#7a1010)', url: '../../games/roblox-2016-web/' },
      { t: 'Kinito Pixel Pet', d: 'Desk friend', e: '👾', c: 'linear-gradient(135deg,#5b8cff,#30d158)', url: '../../games/kinito-pixel-pet/' },
      { t: 'Verity 3am Knock', d: 'Night knock toy', e: '🚪', c: 'linear-gradient(135deg,#1e1b4b,#4c1d95)', url: '../../games/verity-3am-knock/' },
      { t: 'AI City Collapse', d: 'City chaos', e: '🏙️', c: 'linear-gradient(135deg,#64748b,#0ea5e9)', url: '../../games/ai-city-collapse/' },
      { t: 'Bloxy Multiplayer', d: 'Web MP BLOXY', e: '🌐', c: 'linear-gradient(135deg,#38bdf8,#2563eb)', url: '../../games/bloxy-multiplayer/' },
      { t: 'Rec Room Arkhē', d: 'Rec-style room', e: '🥽', c: 'linear-gradient(135deg,#f472b6,#a855f7)', url: '../../games/rec-room/' },
      { t: 'Roblox (real)', d: 'Sample catalog · roblox.com', e: 'R', c: 'linear-gradient(135deg,#e2231a,#7a1010)', app: 'roblox' },
    ];
    appBody.innerHTML = `
      <div class="games-list">
        ${games
          .map(
            (g, i) => `
          <button type="button" class="game-row" data-g="${i}">
            <div class="game-thumb" style="background:${g.c}">${g.e}</div>
            <div><b>${g.t}</b><span>${g.d}</span></div>
            <span class="get">${g.soon ? 'SOON' : 'GET'}</span>
          </button>`
          )
          .join('')}
      </div>`;
    appBody.querySelectorAll('[data-g]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const g = games[+btn.dataset.g];
        if (g.soon) {
          toast('Coming soon');
          return;
        }
        if (g.app) {
          openApp(g.app);
          return;
        }
        openRelative(g.url, g.t);
      });
    });
  }

  function renderKinito() {
    appTitle.textContent = 'Kinito';
    appBody.innerHTML = `
      <div class="center-stub">
        <div class="big">👾</div>
        <h2>Kinito</h2>
        <p>Your pixel desk friend lives here too. Open Messages to chat with offline presets.</p>
        <button type="button" class="primary" data-msg>Open Messages</button>
      </div>`;
    appBody.querySelector('[data-msg]')?.addEventListener('click', () => openApp('messages'));
  }

  /* ---------- gestures / chrome ---------- */
  appBack.addEventListener('click', (e) => {
    e.stopPropagation();
    if (typeof appBackHandler === 'function' && appBackHandler()) return;
    goHome();
  });

  document.querySelectorAll('[data-home]').forEach((bar) => {
    let startY = null;
    bar.addEventListener('pointerdown', (e) => {
      startY = e.clientY;
      bar.setPointerCapture(e.pointerId);
    });
    bar.addEventListener('pointerup', (e) => {
      if (startY == null) return;
      const dy = startY - e.clientY;
      startY = null;
      if (dy > 24 || Math.abs(dy) < 8) {
        if (!controlCenter.classList.contains('hidden') || !notifCenter.classList.contains('hidden')) {
          closeOverlays();
          return;
        }
        if (view === 'lock') unlock();
        else if (view === 'app') goHome();
        else if (view === 'home') {
          toast('Home');
        }
      }
    });
  });

  document.getElementById('btn-power')?.addEventListener('click', () => {
    if (view === 'lock') unlock();
    else lock();
  });

  document.getElementById('btn-flash')?.addEventListener('click', (e) => {
    e.stopPropagation();
    flashOn = !flashOn;
    e.currentTarget.classList.toggle('on', flashOn);
    phone.classList.toggle('flash-on', flashOn);
    toast(flashOn ? 'Flashlight On' : 'Flashlight Off');
  });

  document.getElementById('btn-lock-cam')?.addEventListener('click', (e) => {
    e.stopPropagation();
    unlock();
    openApp('camera');
  });

  document.getElementById('btn-vol-up')?.addEventListener('click', () => {
    volume = Math.min(100, volume + 10);
    pulseIsland('🔊 ' + volume + '%', 1000);
  });
  document.getElementById('btn-vol-down')?.addEventListener('click', () => {
    volume = Math.max(0, volume - 10);
    pulseIsland('🔊 ' + volume + '%', 1000);
  });

  let edgeStart = null;
  statusBar.style.pointerEvents = 'auto';
  statusBar.addEventListener('pointerdown', (e) => {
    edgeStart = { x: e.clientX, y: e.clientY };
  });
  statusBar.addEventListener('pointerup', (e) => {
    if (!edgeStart) return;
    const dy = e.clientY - edgeStart.y;
    const rect = screen.getBoundingClientRect();
    const right = edgeStart.x > rect.left + rect.width * 0.55;
    edgeStart = null;
    if (dy > 20) {
      if (right) {
        notifCenter.classList.add('hidden');
        controlCenter.classList.remove('hidden');
      } else {
        controlCenter.classList.add('hidden');
        notifCenter.classList.remove('hidden');
      }
    }
  });

  statusBar.addEventListener('click', (e) => {
    const rect = statusBar.getBoundingClientRect();
    if (e.clientX > rect.left + rect.width * 0.55) {
      controlCenter.classList.toggle('hidden');
      notifCenter.classList.add('hidden');
    } else {
      notifCenter.classList.toggle('hidden');
      controlCenter.classList.add('hidden');
    }
  });

  controlCenter.addEventListener('click', (e) => {
    if (e.target === controlCenter) closeOverlays();
  });
  notifCenter.addEventListener('click', (e) => {
    if (e.target === notifCenter) closeOverlays();
  });

  document.getElementById('nc-clear')?.addEventListener('click', () => {
    NOTIFS.length = 0;
    renderNotifs();
    toast('Notifications cleared');
  });

  controlCenter.querySelectorAll('[data-cc]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const k = btn.dataset.cc;
      if (btn.classList.contains('cc-orb')) {
        btn.classList.toggle('on');
      }
      if (k === 'flash') {
        flashOn = !flashOn;
        phone.classList.toggle('flash-on', flashOn);
        document.getElementById('btn-flash')?.classList.toggle('on', flashOn);
        toast(flashOn ? 'Flashlight On' : 'Flashlight Off');
      }
      if (k === 'cam') {
        closeOverlays();
        if (view === 'lock') unlock();
        openApp('camera');
      }
      if (k === 'calc') {
        closeOverlays();
        if (view === 'lock') unlock();
        openApp('calc');
      }
      if (k === 'timer') {
        closeOverlays();
        if (view === 'lock') unlock();
        openApp('clock');
      }
      if (k === 'focus') toast(btn.classList.contains('on') ? 'Focus On' : 'Focus Off');
      if (k === 'airplane') toast(btn.classList.contains('on') ? 'Airplane Mode On' : 'Airplane Mode Off');
    });
  });

  document.getElementById('cc-bright')?.addEventListener('input', (e) => {
    brightness = +e.target.value;
    screen.style.filter = `brightness(${brightness / 100})`;
  });
  document.getElementById('cc-vol')?.addEventListener('input', (e) => {
    volume = +e.target.value;
  });

  const lockScr = document.getElementById('scr-lock');
  let lockDrag = null;
  lockScr.addEventListener('pointerdown', (e) => {
    if (e.target.closest('button')) return;
    lockDrag = e.clientY;
  });
  lockScr.addEventListener('pointerup', (e) => {
    if (lockDrag == null) return;
    if (lockDrag - e.clientY > 40) unlock();
    lockDrag = null;
  });

  window.addEventListener('keydown', (e) => {
    if (e.target.matches('input, textarea')) return;
    if (e.key === 'Escape') {
      closeOverlays();
      if (view === 'app') goHome();
    }
    if (e.key === ' ' && view === 'lock') {
      e.preventDefault();
      unlock();
    }
    if (e.key === 'l' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      lock();
    }
  });

  /* ---------- boot ---------- */
  renderHome();
  renderNotifs();
  refreshChatStatus(null);
  showScreen('lock');
  setTimeout(() => pulseIsland('iPhone', 1600), 400);
})();
