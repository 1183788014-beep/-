# Phone Simulator (public)

Browser **iPhone-style** phone for the **Public Kid Arcade** pack — lock/home, Control Center, Messages, YouTube, Roblox, Arcade, and more.

Not affiliated with Apple.

**Kid-made with Grok Build** · family co-design / the kids as co-ideators.

## Run (static — no special server)

From the **pack root** (recommended so sibling games resolve):

```bash
cd projects/public-kid-arcade
python3 -m http.server 8800 --bind 127.0.0.1
```

Open **http://127.0.0.1:8800/apps/phone-simulator/**

Or from this folder:

```bash
cd projects/public-kid-arcade/apps/phone-simulator
python3 -m http.server 8784 --bind 127.0.0.1
```

Arcade links use relative paths (`../i-am-bird/`, `../i-am-monkey/`) — serve from the pack root for those to work.

### GitHub Pages

Host the whole `public-kid-arcade/` tree. Phone sim lives at:

`…/apps/phone-simulator/`

No Python API, no Ollama required for core fun.

## What’s different from the local canon

| Local canon (`creative-visualizers-and-games/phone-simulator`) | This public fork |
|---|---|
| `serve.py` + Ollama `gemma4-e2b` for Messages | `shared/chat-presets.js` (KidArcadeChat) |
| YouTube/Roblox API proxies | Static catalogs + paste URL / open real site |
| Arcade deep-links to localhost game ports | Relative URLs to pack apps |
| Optional family-only paths | Public-safe; no real names |

## Messages

Contacts map to preset personas:

| Contact | Persona id |
|---------|------------|
| Kinito | `kinito` |
| Desk Chonks | `chonks` |
| BossBot-9000 | `bossbot` |
| Mom | `mom` |
| Assistant | `assistant` |

### Optional Ollama (power users only)

Both flags required (URL alone is not enough):

```js
window.KID_ARCADE_OLLAMA_URL = 'http://127.0.0.1:11434';
window.KID_ARCADE_PREFER_OLLAMA = true;
window.KID_ARCADE_OLLAMA_MODEL = 'gemma4-e2b:latest'; // optional
```

Default remains **presets** so anyone on Pages can chat offline.

## Arcade / Games

- **I Am Bird** → `../i-am-bird/`
- **I Am Monkey** → `../i-am-monkey/`
- **Roblox** → sample catalog; **Play** opens real [roblox.com](https://www.roblox.com/)
- Placeholders for more pack apps

## YouTube

- Sample trending catalog (no Piped proxy required)
- Paste a YouTube URL / video ID → plays via `youtube-nocookie.com` embed
- Sim-only comments & private posts use **localStorage** (this browser only)

## Gestures

- **Swipe up** home bar (or tap it) → unlock / Home  
- **Pull down** top-right (or click status right) → Control Center  
- **Pull down** top-left (or click status left) → Notifications  
- **Power** side button → lock / unlock  
- **Space** on lock → unlock · **Esc** → Home  
- On real phones/iPads: **fullscreen phone** mode (less bezel waste)

## Privacy

Do **not** put children’s real names in this tree, commits, or captions. Credit **the kids** / **family co-design** only.

## Provenance

Adapted from `projects/creative-visualizers-and-games/phone-simulator/` (read-only canon). Public fork may strip server deps and gore-adjacent content.
