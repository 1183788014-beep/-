# I Am Monkey (public safe)

**Kid-made with Grok Build** · public fork · **no gore** · **no Ollama required**.

Canon (local, may include blood juice + Gemma) lives at  
`projects/creative-visualizers-and-games/i-am-monkey-arkhe/`.

## Changes from canon
- Blood / AI blood sprites removed → stars / sparks
- Elephant chat uses `shared/chat-presets.js` (GitHub Pages friendly)
- Optional: set `window.KID_ARCADE_OLLAMA_URL` for local Ollama if you want

## Controls
Touch stick + Jump/Punch on phones/tablets; **WASD + mouse** on desktop. Chat panel collapses on small screens so it doesn’t block the stick. Shared kit: `shared/mobile-controls.js`.

## Play
```bash
cd projects/public-kid-arcade
python3 -m http.server 8800 --bind 127.0.0.1
# http://127.0.0.1:8800/apps/i-am-monkey/
```
