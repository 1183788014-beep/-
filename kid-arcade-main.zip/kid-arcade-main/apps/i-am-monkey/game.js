/**
 * I Am Monkey-ish — public safe fork (no gore) · Kid-made with Grok Build · elephant chat presets
 * Inspired by I Am Monkey (not affiliated)
 */
(function () {
  'use strict';

  const canvas = document.getElementById('c');
  const overlay = document.getElementById('overlay');
  const btnStart = document.getElementById('btn-start');
  const chaosEl = document.getElementById('chaos');
  const nearEl = document.getElementById('near-el');
  const toastEl = document.getElementById('toast');
  const chatLog = document.getElementById('chat-log');
  const chatInput = document.getElementById('chat-input');
  const chatSend = document.getElementById('chat-send');
  const aiStatus = document.getElementById('ai-status');
  const btnTalk = document.getElementById('btn-talk');

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.setClearColor(0x6ab0e8, 1);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x6ab0e8, 25, 90);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.06, 120);
  camera.rotation.order = 'YXZ';

  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  scene.add(new THREE.HemisphereLight(0xb0d8ff, 0x3a6a30, 0.5));
  const sun = new THREE.DirectionalLight(0xfff2dd, 0.8);
  sun.position.set(20, 40, 10);
  scene.add(sun);

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function mat(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function box(w, h, d, c) {
    return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c));
  }

  // ——— world ———
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), mat(0x4a9a45));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  // path
  const path = box(8, 0.08, 80, 0xc2a878);
  path.position.set(0, 0.04, 0);
  scene.add(path);

  // trees
  for (let i = 0; i < 35; i++) {
    const g = new THREE.Group();
    const trunk = box(0.7, 3.5, 0.7, 0x6b4420);
    trunk.position.y = 1.75;
    const leaves = new THREE.Mesh(new THREE.SphereGeometry(2.2, 8, 8), mat(0x2d8a3a));
    leaves.position.y = 4.2;
    g.add(trunk, leaves);
    let x = rand(-50, 50), z = rand(-50, 50);
    if (Math.abs(x) < 6) x += Math.sign(x || 1) * 8;
    g.position.set(x, 0, z);
    scene.add(g);
  }

  // rocks / barrels
  for (let i = 0; i < 12; i++) {
    const r = box(rand(0.6, 1.4), rand(0.5, 1.2), rand(0.6, 1.4), 0x7a7a80);
    r.position.set(rand(-20, 20), 0.4, rand(-30, 30));
    scene.add(r);
  }

  // bananas prop
  for (let i = 0; i < 8; i++) {
    const b = box(0.15, 0.08, 0.4, 0xffe040);
    b.position.set(rand(-8, 8), 0.15, rand(-10, 20));
    b.rotation.z = rand(-0.5, 0.5);
    scene.add(b);
  }

  // ——— elephant ———
  const elephant = {
    x: 0, z: -12, mesh: null,
  };
  function buildElephant() {
    const g = new THREE.Group();
    const body = box(2.4, 1.8, 3.2, 0x9a9aaa);
    body.position.y = 1.5;
    const head = box(1.4, 1.2, 1.3, 0x8a8a9a);
    head.position.set(0, 2.0, 1.9);
    const earL = box(0.15, 1.1, 0.9, 0x8a8a9a);
    earL.position.set(-0.9, 2.1, 1.7);
    const earR = earL.clone();
    earR.position.x = 0.9;
    const trunk = box(0.35, 1.4, 0.35, 0x8a8a9a);
    trunk.position.set(0, 1.2, 2.6);
    trunk.rotation.x = 0.35;
    const legPositions = [[-0.7, 0.55, 0.9], [0.7, 0.55, 0.9], [-0.7, 0.55, -0.9], [0.7, 0.55, -0.9]];
    legPositions.forEach(([x, y, z]) => {
      const leg = box(0.45, 1.1, 0.45, 0x8a8a9a);
      leg.position.set(x, y, z);
      g.add(leg);
    });
    // eyes
    const eyeL = box(0.15, 0.15, 0.1, 0x111118);
    eyeL.position.set(-0.35, 2.15, 2.55);
    const eyeR = eyeL.clone();
    eyeR.position.x = 0.35;
    g.add(body, head, earL, earR, trunk, eyeL, eyeR);
    g.position.set(elephant.x, 0, elephant.z);
    scene.add(g);
    elephant.mesh = g;
  }
  buildElephant();

  // ——— people ———
  const people = [];
  const SKINS = [0xffe0bd, 0xf5c59a, 0xc68642, 0x8d5524];
  const SHIRTS = [0x3a7bd5, 0xe74c3c, 0x2ecc71, 0xf1c40f, 0x9b59b6, 0xffffff];

  function makePerson(x, z) {
    const g = new THREE.Group();
    const skin = SKINS[(Math.random() * SKINS.length) | 0];
    const shirt = SHIRTS[(Math.random() * SHIRTS.length) | 0];
    const torso = box(0.55, 0.7, 0.3, shirt);
    torso.position.y = 1.15;
    const head = box(0.4, 0.4, 0.4, skin);
    head.position.y = 1.75;
    const legL = box(0.2, 0.55, 0.22, 0x2c3e50);
    legL.position.set(-0.14, 0.4, 0);
    const legR = box(0.2, 0.55, 0.22, 0x2c3e50);
    legR.position.set(0.14, 0.4, 0);
    const armL = box(0.16, 0.55, 0.16, shirt);
    armL.position.set(-0.4, 1.15, 0);
    const armR = box(0.16, 0.55, 0.16, shirt);
    armR.position.set(0.4, 1.15, 0);
    g.add(torso, head, legL, legR, armL, armR);
    g.position.set(x, 0, z);
    scene.add(g);
    const p = {
      mesh: g,
      parts: { torso, head, legL, legR, armL, armR },
      x, y: 0, z,
      vx: 0, vy: 0, vz: 0,
      rx: 0, ry: rand(0, Math.PI * 2), rz: 0,
      wx: 0, wy: 0, wz: 0,
      yaw: rand(0, Math.PI * 2),
      ragdoll: false,
      limpT: 0,
      walkT: rand(0, 10),
      hitCd: 0,
    };
    people.push(p);
    return p;
  }
  for (let i = 0; i < 40; i++) {
    makePerson(rand(-18, 18), rand(-25, 25));
  }

  function limpPose(p) {
    const t = p.limpT;
    p.parts.armL.rotation.z = 0.9 + Math.sin(t * 9) * 0.5;
    p.parts.armR.rotation.z = -0.9 + Math.cos(t * 8) * 0.5;
    p.parts.legL.rotation.x = 0.5 + Math.sin(t * 5) * 0.5;
    p.parts.legR.rotation.x = 0.4 + Math.cos(t * 5.5) * 0.5;
    p.parts.head.rotation.z = Math.sin(t * 4) * 0.3;
  }

  function startRagdoll(p, ix, iy, iz) {
    if (!p.ragdoll) {
      p.ragdoll = true;
      p.limpT = 0;
      if (p.y < 0.5) p.y = 0.9;
      p.wx = rand(-6, 6);
      p.wy = rand(-3, 3);
      p.wz = rand(-6, 6);
    }
    p.vx += ix || 0;
    p.vy += (iy != null ? iy : 4);
    p.vz += iz || 0;
  }

  // ——— monkey player ———
  const mon = {
    x: 0, y: 1.2, z: 8,
    vx: 0, vy: 0, vz: 0,
    yaw: Math.PI, pitch: 0,
    onGround: true,
    speed: 7,
    sprint: 11,
    jump: 7,
  };
  let locked = false;
  let started = false;
  const keys = Object.create(null);
  let controls = null;
  let chaos = 0;
  let punchCd = 0;
  let punchAnim = 0;
  let punchSide = 1;
  let history = [];

  function isTouchPlay() {
    return !!(controls && controls.isTouchMode && controls.isTouchMode()) ||
      !!(window.KidArcadeControls && KidArcadeControls.isTouchMode && KidArcadeControls.isTouchMode());
  }

  function requestLock() {
    if (!started || isTouchPlay()) return;
    if (window.KidArcadeControls && KidArcadeControls.tryPointerLock) {
      KidArcadeControls.tryPointerLock(canvas);
      return;
    }
    try {
      if (canvas.requestPointerLock) canvas.requestPointerLock();
    } catch (_) { /* soft-fail */ }
  }

  function pollInput() {
    if (controls && controls.getState) return controls.getState();
    let moveX = 0, moveZ = 0;
    if (keys.KeyA || keys.ArrowLeft) moveX -= 1;
    if (keys.KeyD || keys.ArrowRight) moveX += 1;
    if (keys.KeyW || keys.ArrowUp) moveZ -= 1;
    if (keys.KeyS || keys.ArrowDown) moveZ += 1;
    return {
      moveX: moveX, moveZ: moveZ, lookDx: 0, lookDy: 0,
      jump: !!keys.Space, punch: !!keys.KeyF, primary: !!keys.KeyF,
      boost: !!(keys.ShiftLeft || keys.ShiftRight),
      keys: keys, just: {}, chatFocused: document.activeElement === chatInput,
    };
  }

  function mountControls() {
    if (controls || !window.KidArcadeControls) return;
    controls = KidArcadeControls.mount({
      reserveKeyE: true, // E = talk to elephant, not vertical
      actions: [
        { id: 'jump', label: 'Jump' },
        { id: 'punch', label: 'Punch' },
      ],
      onAction: function (id, down) {
        if (!down || !started) return;
        if (id === 'punch' || id === 'primary') tryPunch();
      },
    });
  }

  // monkey hands
  const hands = new THREE.Group();
  camera.add(hands);
  scene.add(camera);

  function makeHand(side) {
    const g = new THREE.Group();
    const fur = 0xc47840;
    const arm = box(0.16, 0.16, 0.5, fur);
    arm.position.set(0, 0, -0.15);
    const fist = box(0.28, 0.24, 0.28, fur);
    fist.position.set(0, 0, -0.48);
    // knuckles
    for (let i = -1; i <= 1; i++) {
      const k = box(0.06, 0.06, 0.06, 0xa06030);
      k.position.set(i * 0.08, 0.1, -0.58);
      g.add(k);
    }
    g.add(arm, fist);
    g.position.set(side * 0.32, -0.32, -0.4);
    g.rotation.x = 0.4;
    g.userData.side = side;
    g.userData.baseZ = -0.4;
    hands.add(g);
    return g;
  }
  const handL = makeHand(-1);
  const handR = makeHand(1);

  // sparks + public-safe hit juice (stars — NO gore / blood)
  const sparks = [];
  const juiceFX = [];

  function spark(x, y, z, col) {
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 4, 4),
      new THREE.MeshBasicMaterial({ color: col || 0xffee55 })
    );
    m.position.set(x, y, z);
    scene.add(m);
    sparks.push({
      mesh: m, x, y, z,
      vx: rand(-3, 3), vy: rand(2, 6), vz: rand(-3, 3),
      life: 0.45,
    });
  }

  function spawnHitJuice(x, y, z, power, dir) {
    const pwr = power || 1.2;
    const n = 8 + ((pwr * 6) | 0);
    const cols = [0xffe566, 0xff9f0a, 0x5b8cff, 0x64d2ff, 0x30d158, 0xff6bcb, 0xffffff];
    for (let i = 0; i < n; i++) {
      const s = rand(0.06, 0.18);
      const mesh = new THREE.Mesh(
        Math.random() < 0.5
          ? new THREE.BoxGeometry(s, s * 0.3, s * 0.12)
          : new THREE.SphereGeometry(s, 5, 5),
        new THREE.MeshBasicMaterial({
          color: cols[(Math.random() * cols.length) | 0],
          transparent: true,
          opacity: 0.95,
        })
      );
      mesh.position.set(x, y, z);
      scene.add(mesh);
      const nx = dir ? dir.x : 0;
      const ny = dir ? dir.y : 0.3;
      const nz = dir ? dir.z : 0;
      juiceFX.push({
        mesh,
        x, y, z,
        vx: nx * rand(2, 8) * pwr + rand(-3, 3),
        vy: ny * rand(2, 6) * pwr + rand(1, 5),
        vz: nz * rand(2, 8) * pwr + rand(-3, 3),
        life: rand(0.35, 0.8),
        spin: rand(-8, 8),
      });
    }
    // KO flash
    const flash = new THREE.Mesh(
      new THREE.SphereGeometry(0.32, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffe566, transparent: true, opacity: 0.85 })
    );
    flash.position.set(x, y, z);
    scene.add(flash);
    juiceFX.push({
      mesh: flash, x, y, z, vx: 0, vy: 1, vz: 0, life: 0.2, grow: true, spin: 0,
    });
  }

  // Stubs keep old call names from punch logic without gore
  function spawnBlood(x, y, z, power, dir) {
    spawnHitJuice(x, y, z, power, dir);
    for (let i = 0; i < 4; i++) spark(x, y, z, 0xffe566);
  }
  function spawnDrip() { /* no-op public */ }
  function leaveBloodStain() { /* no-op public */ }

  function updateBlood(dt) {
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.life -= dt;
      s.vy -= 14 * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      s.mesh.position.set(s.x, s.y, s.z);
      if (s.life <= 0 || s.y < 0) {
        scene.remove(s.mesh);
        sparks.splice(i, 1);
      }
    }
    for (let i = juiceFX.length - 1; i >= 0; i--) {
      const b = juiceFX[i];
      b.life -= dt;
      if (b.grow) {
        b.mesh.scale.multiplyScalar(1 + dt * 10);
        if (b.mesh.material) b.mesh.material.opacity = Math.max(0, b.life * 4);
      } else {
        b.vy -= 18 * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.z += b.vz * dt;
        b.mesh.position.set(b.x, b.y, b.z);
        if (b.spin) b.mesh.rotation.z += b.spin * dt;
      }
      if (b.life <= 0 || b.y < -0.5) {
        scene.remove(b.mesh);
        juiceFX.splice(i, 1);
      }
    }
  }

  function woundPerson(p, dir, power) {
    // public: ragdoll + stars only (no bleed)
    startRagdoll(p, (dir && dir.x) || 0, 3 + (power || 1), (dir && dir.z) || 0);
    spawnHitJuice(p.x, p.y + 1.1, p.z, power || 1, dir);
    chaos += 1;
    if (chaosEl) chaosEl.textContent = String(chaos);
  }


  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), ms || 1600);
  }

  function addChaos(n) {
    chaos += n;
    chaosEl.textContent = String(chaos);
  }

  // sfx
  const sfx = {
    ctx: null,
    ensure() {
      if (this.ctx) return;
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    },
    beep(f, d, type, v) {
      this.ensure();
      if (this.ctx.state === 'suspended') this.ctx.resume();
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type || 'square';
      o.frequency.value = f;
      g.gain.value = v || 0.08;
      o.connect(g);
      g.connect(this.ctx.destination);
      const t = this.ctx.currentTime;
      g.gain.exponentialRampToValueAtTime(0.001, t + d);
      o.start(t);
      o.stop(t + d + 0.02);
    },
    punch() { this.beep(180, 0.08, 'square', 0.12); this.beep(90, 0.1, 'triangle', 0.1); },
    ooh() { this.beep(400, 0.1, 'sine', 0.08); this.beep(500, 0.08, 'sine', 0.06); },
  };

  function forward() {
    return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(0, mon.yaw, 0, 'YXZ'));
  }
  function lookDir() {
    return new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(mon.pitch, mon.yaw, 0, 'YXZ'));
  }

  function distToElephant() {
    return Math.hypot(elephant.x - mon.x, elephant.z - mon.z);
  }

  function tryPunch() {
    if (punchCd > 0) return;
    punchCd = 0.32;
    punchAnim = 0.28;
    punchSide *= -1;
    sfx.punch();

    const dir = lookDir();
    const reach = 2.2;
    const px = mon.x + dir.x * 1.2;
    const py = mon.y + dir.y * 0.5;
    const pz = mon.z + dir.z * 1.2;

    let hit = false;
    for (const p of people) {
      if (p.hitCd > 0) continue;
      const d = Math.hypot(p.x - px, (p.y + 1) - py, p.z - pz);
      if (d < 1.5) {
        p.hitCd = 0.35;
        startRagdoll(p, dir.x * 10, 5 + Math.max(0, mon.vy), dir.z * 10);
        addChaos(3);
        hit = true;
        for (let i = 0; i < 4; i++) spark(p.x, p.y + 1, p.z, 0xffcc44);
        woundPerson(p, { x: dir.x, y: dir.y * 0.4 + 0.15, z: dir.z }, 1.55);
      }
    }
    // punch elephant? gentle
    if (distToElephant() < 4) {
      sfx.ooh();
      toast('Ellie: "Hey! Easy, little monkey."', 1800);
      addChaos(1);
      hit = true;
    }
    if (!hit) toast('*whoosh*', 500);
    else toast('POW!', 700);
  }

  // ——— chat elephant ———
  function chatLine(who, text, cls) {
    const d = document.createElement('div');
    d.className = 'cline';
    d.innerHTML = `<span class="who ${cls || ''}">${esc(who)}</span>${esc(text)}`;
    chatLog.appendChild(d);
    chatLog.scrollTop = chatLog.scrollHeight;
    while (chatLog.children.length > 30) chatLog.removeChild(chatLog.firstChild);
  }
  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  async function refreshStatus() {
    try {
      const r = await fetch('/api/status');
      const d = await r.json();
      aiStatus.textContent = d.ok ? `Local ${d.model}` : 'AI offline';
    } catch {
      aiStatus.textContent = 'Server offline — use python3 serve.py';
    }
  }

  let chatBusy = false;
  async function askElephant(msg) {
    if (chatBusy || !msg.trim()) return;
    if (distToElephant() > 8) {
      toast('Get closer to Ellie the Elephant to talk', 1600);
      return;
    }
    chatBusy = true;
    chatLine('You', msg, 'you');
    history.push({ role: 'user', content: msg });
    chatLine('Ellie', '…', 'el');
    const pending = chatLog.lastChild;
    try {
      let d;
      if (window.KidArcadeChat) {
        d = await window.KidArcadeChat.chat({
          persona: 'elephant',
          message: msg,
          history: history.slice(0, -1),
        });
      } else {
        const r = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: msg, history: history.slice(0, -1) }),
        });
        d = await r.json();
      }
      if (!d.ok) throw new Error(d.error || 'chat failed');
      history.push({ role: 'assistant', content: d.reply });
      if (history.length > 16) history.splice(0, history.length - 16);
      pending.innerHTML = `<span class="who el">Ellie</span>${esc(d.reply)}`;
      aiStatus.textContent = d.model || 'presets';
      if (window.speechSynthesis) {
        const u = new SpeechSynthesisUtterance(d.reply);
        u.rate = 0.95;
        u.pitch = 0.7;
        speechSynthesis.cancel();
        speechSynthesis.speak(u);
      }
    } catch (e) {
      pending.innerHTML = `<span class="who el">Ellie</span>${esc(String(e.message || e))}`;
    }
    chatBusy = false;
  }

  // ——— sim ———
  function updatePeople(dt) {
    for (const p of people) {
      if (p.hitCd > 0) p.hitCd -= dt;
      if (p.ragdoll) {
        p.limpT += dt;
        p.vy -= 22 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        p.rx += p.wx * dt;
        p.ry += p.wy * dt;
        p.rz += p.wz * dt;
        if (p.y < 0.4) {
          // ground bounce — light star juice, no gore
          if (p.vy < -5) {
            spawnBlood(p.x, 0.5, p.z, 0.5, { x: p.vx, y: 0.5, z: p.vz });
          }
          p.y = 0.4;
          p.vy *= -0.25;
          p.vx *= 0.82;
          p.vz *= 0.82;
          p.wx *= 0.7;
          p.wz *= 0.7;
          p.rx += (Math.PI / 2 - p.rx) * Math.min(1, dt * 2.5);
        }
        p.x = clamp(p.x, -55, 55);
        p.z = clamp(p.z, -55, 55);
        limpPose(p);
        p.mesh.position.set(p.x, p.y, p.z);
        p.mesh.rotation.set(p.rx, p.ry, p.rz);
        continue;
      }
      p.walkT += dt;
      p.x += Math.sin(p.walkT * 0.6 + p.yaw) * 1.1 * dt;
      p.z += Math.cos(p.walkT * 0.5 + p.yaw) * 1.1 * dt;
      if (Math.random() < dt * 0.2) p.yaw = rand(0, Math.PI * 2);
      // flee monkey if close
      const d = Math.hypot(p.x - mon.x, p.z - mon.z);
      if (d < 5) {
        const dx = p.x - mon.x;
        const dz = p.z - mon.z;
        p.x += (dx / (d || 1)) * 3 * dt;
        p.z += (dz / (d || 1)) * 3 * dt;
      }
      p.x = clamp(p.x, -55, 55);
      p.z = clamp(p.z, -55, 55);
      p.mesh.position.set(p.x, 0, p.z);
      p.mesh.rotation.set(0, p.yaw, 0);
      p.parts.legL.rotation.x = Math.sin(p.walkT * 6) * 0.5;
      p.parts.legR.rotation.x = -Math.sin(p.walkT * 6) * 0.5;
    }
  }

  function updateMonkey(dt) {
    if (punchCd > 0) punchCd -= dt;
    if (punchAnim > 0) punchAnim -= dt;

    const st = pollInput();
    // Touch look (right-drag); desktop uses pointer-lock mousemove
    if (!st.chatFocused && (st.lookDx || st.lookDy)) {
      mon.yaw -= st.lookDx * 0.0023;
      mon.pitch -= st.lookDy * 0.002;
      mon.pitch = clamp(mon.pitch, -1.3, 1.2);
    }

    const fwd = forward();
    const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, mon.yaw, 0, 'YXZ'));
    let mx = 0, mz = 0;
    const sprint = !!st.boost;
    const spd = sprint ? mon.sprint : mon.speed;
    // moveZ: -1 forward, +1 back · moveX: -1 left, +1 right
    mx += fwd.x * (-st.moveZ) + right.x * st.moveX;
    mz += fwd.z * (-st.moveZ) + right.z * st.moveX;
    const len = Math.hypot(mx, mz);
    if (len > 0) {
      mx = (mx / len) * spd;
      mz = (mz / len) * spd;
    }
    mon.vx += (mx - mon.vx) * Math.min(1, dt * 12);
    mon.vz += (mz - mon.vz) * Math.min(1, dt * 12);

    if (st.jump && mon.onGround) {
      mon.vy = mon.jump;
      mon.onGround = false;
      sfx.ooh();
    }
    mon.vy -= 20 * dt;
    mon.y += mon.vy * dt;
    if (mon.y <= 1.2) {
      mon.y = 1.2;
      mon.vy = 0;
      mon.onGround = true;
    }
    mon.x += mon.vx * dt;
    mon.z += mon.vz * dt;
    mon.x = clamp(mon.x, -55, 55);
    mon.z = clamp(mon.z, -55, 55);

    // body slam into people while sprinting
    const speed = Math.hypot(mon.vx, mon.vz);
    if (speed > 6) {
      for (const p of people) {
        if (p.ragdoll || p.hitCd > 0) continue;
        if (Math.hypot(p.x - mon.x, p.z - mon.z) < 1.1) {
          p.hitCd = 0.4;
          startRagdoll(p, mon.vx * 0.8, 4, mon.vz * 0.8);
          addChaos(2);
          sfx.punch();
          const sl = Math.hypot(mon.vx, mon.vz) || 1;
          woundPerson(p, { x: mon.vx / sl, y: 0.25, z: mon.vz / sl }, 1.35);
        }
      }
    }

    const bob = mon.onGround && len > 0.1 ? Math.sin(performance.now() * 0.018) * 0.04 : 0;
    camera.position.set(mon.x, mon.y + bob, mon.z);
    camera.rotation.x = mon.pitch;
    camera.rotation.y = mon.yaw;

    // hand punch anim
    const punch = punchAnim > 0 ? (0.28 - punchAnim) / 0.28 : 0;
    const punchZ = punch > 0 ? -0.4 - Math.sin(punch * Math.PI) * 0.55 : -0.4;
    if (punchSide > 0) {
      handR.position.z = punchZ;
      handL.position.z = -0.4;
      handR.rotation.x = 0.2 - punch * 0.8;
    } else {
      handL.position.z = punchZ;
      handR.position.z = -0.4;
      handL.rotation.x = 0.2 - punch * 0.8;
    }
    // idle sway
    if (punchAnim <= 0) {
      handL.rotation.x = 0.4 + Math.sin(performance.now() * 0.005) * 0.05;
      handR.rotation.x = 0.4 - Math.sin(performance.now() * 0.005) * 0.05;
      handL.position.z = -0.4;
      handR.position.z = -0.4;
    }

    const de = distToElephant();
    nearEl.textContent = de < 8 ? 'Elephant: nearby — talk!' : de < 16 ? 'Elephant: close' : 'Elephant: far';
    nearEl.style.color = de < 8 ? '#9fef9f' : '#fff';
  }

  function updateSparks(dt) {
    for (let i = sparks.length - 1; i >= 0; i--) {
      const s = sparks[i];
      s.life -= dt;
      s.vy -= 12 * dt;
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.z += s.vz * dt;
      s.mesh.position.set(s.x, s.y, s.z);
      if (s.life <= 0 || s.y < 0) {
        scene.remove(s.mesh);
        sparks.splice(i, 1);
      }
    }
  }

  // elephant idle
  function updateElephant(dt) {
    if (!elephant.mesh) return;
    elephant.mesh.rotation.y = Math.sin(performance.now() * 0.0005) * 0.15;
    // face monkey when close
    if (distToElephant() < 12) {
      const dx = mon.x - elephant.x;
      const dz = mon.z - elephant.z;
      elephant.mesh.rotation.y = Math.atan2(dx, dz);
    }
  }

  // input
  function resize() {
    renderer.setSize(innerWidth, innerHeight, false);
    camera.aspect = innerWidth / Math.max(1, innerHeight);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('click', () => {
    if (started) requestLock();
  });
  document.addEventListener('pointerlockchange', () => {
    locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!locked) return;
    mon.yaw -= e.movementX * 0.0023;
    mon.pitch -= e.movementY * 0.002;
    mon.pitch = clamp(mon.pitch, -1.3, 1.2);
  });
  window.addEventListener('keydown', (e) => {
    // Always allow E/T chat focus even when shared controls own WASD
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    if (!controls) keys[e.code] = true;
    if (!started) return;
    if (!controls && e.code === 'KeyF') tryPunch();
    if (e.code === 'KeyE') {
      if (distToElephant() < 8) {
        chatInput.focus();
        try { document.exitPointerLock(); } catch (_) { /* ignore */ }
        toast('Talking to Ellie…', 1200);
      } else toast('Find the elephant first', 1200);
    }
    if (e.code === 'KeyT' && document.activeElement !== chatInput) {
      chatInput.focus();
      try { document.exitPointerLock(); } catch (_) { /* ignore */ }
    }
  });
  window.addEventListener('keyup', (e) => {
    if (!controls) keys[e.code] = false;
  });
  document.addEventListener('mousedown', (e) => {
    if (!started || e.button !== 0 || document.activeElement === chatInput) return;
    if (e.target && e.target.closest && (
      e.target.closest('#kid-arcade-controls') || e.target.closest('#chat-panel')
    )) return;
    if (locked) tryPunch();
  });

  chatSend.addEventListener('click', () => {
    const t = chatInput.value.trim();
    chatInput.value = '';
    askElephant(t);
  });
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      chatSend.click();
    }
    e.stopPropagation();
  });
  // Blur chat on outside tap so look/move resume
  chatInput.addEventListener('focus', () => {
    try { document.exitPointerLock(); } catch (_) { /* ignore */ }
  });
  btnTalk.addEventListener('click', () => {
    if (distToElephant() > 8) {
      toast('Walk closer to the elephant', 1500);
      return;
    }
    askElephant('Hey Ellie! What do you think of me being a chaos monkey?');
  });

  const chatToggle = document.getElementById('chat-toggle');
  const chatPanel = document.getElementById('chat-panel');
  if (chatToggle && chatPanel) {
    chatToggle.addEventListener('click', () => {
      const collapsed = chatPanel.classList.toggle('kac-chat-collapsed');
      chatToggle.textContent = collapsed ? 'Show' : 'Hide';
      chatToggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    });
    // Default collapsed on coarse / narrow so stick & punch stay free
    try {
      if (matchMedia('(max-width: 900px), (pointer: coarse)').matches) {
        chatPanel.classList.add('kac-chat-collapsed');
        chatToggle.textContent = 'Show';
        chatToggle.setAttribute('aria-expanded', 'false');
      }
    } catch (_) { /* ignore */ }
  }

  btnStart.addEventListener('click', () => {
    started = true;
    overlay.classList.add('hidden');
    sfx.ensure();
    sfx.ctx.resume();
    sfx.ooh();
    mountControls();
    requestLock();
    refreshStatus();
    toast(isTouchPlay()
      ? 'Stick to move · drag right to look · Punch!'
      : 'Ooh ooh! Punch tourists · chat with Ellie', 2500);
    chatLine('Ellie', 'Hello little monkey. Come closer if you want to talk.', 'el');
  });

  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (started) {
      updateMonkey(dt);
      updatePeople(dt);
      updateElephant(dt);
      updateSparks(dt);
      updateBlood(dt);
    } else {
      camera.position.set(mon.x, mon.y, mon.z);
      camera.rotation.set(mon.pitch, mon.yaw, 0);
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  refreshStatus();
  setInterval(refreshStatus, 20000);
})();
