/**
 * I Am Bird-ish — comedy bird POV chaos sandbox
 * Public fork (no gore) · Kid-made with Grok Build · Inspired by Estoty's I Am Bird (not affiliated)
 */
(function () {
  'use strict';

  const canvas = document.getElementById('c');
  const overlay = document.getElementById('overlay');
  const btnStart = document.getElementById('btn-start');
  const killsEl = document.getElementById('kills');
  const heatEl = document.getElementById('heat-label');
  const grabEl = document.getElementById('grab-label');
  const weaponEl = document.getElementById('weapon');
  const wantedEl = document.getElementById('wanted');

  // ——— renderer / camera ———
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
  renderer.setClearColor(0x87b8e8, 1);
  renderer.shadowMap.enabled = false;

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x87b8e8, 40, 160);

  const camera = new THREE.PerspectiveCamera(75, 1, 0.08, 250);
  camera.rotation.order = 'YXZ';

  // lights
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const sun = new THREE.DirectionalLight(0xfff2dd, 0.85);
  sun.position.set(30, 50, 20);
  scene.add(sun);
  scene.add(new THREE.HemisphereLight(0xa0c8ff, 0x406030, 0.45));

  // ——— bird state ———
  const bird = {
    x: 0, y: 8, z: 12,
    vx: 0, vy: 0, vz: 0,
    yaw: 0, pitch: -0.15,
    speed: 18,
    boost: 28,
    radius: 0.45,
  };
  let locked = false;
  const keys = Object.create(null);
  let controls = null;

  // chaos
  let kills = 0;
  let heat = 0; // 0..100
  let grabbed = null; // person index
  let weapon = null; // { type, ammo?, mesh? }
  let attackCd = 0;
  let poopCd = 0;
  let gameStarted = false;

  function isTouchPlay() {
    return !!(controls && controls.isTouchMode && controls.isTouchMode()) ||
      !!(window.KidArcadeControls && KidArcadeControls.isTouchMode && KidArcadeControls.isTouchMode());
  }

  function requestLock() {
    if (!gameStarted || isTouchPlay()) return;
    if (window.KidArcadeControls && KidArcadeControls.tryPointerLock) {
      KidArcadeControls.tryPointerLock(canvas);
      return;
    }
    try {
      if (canvas.requestPointerLock) canvas.requestPointerLock();
    } catch (_) { /* soft-fail */ }
  }

  function pollInput() {
    if (controls && controls.getState) return controls.getState();
    let moveX = 0, moveZ = 0;
    if (keys.KeyA || keys.ArrowLeft) moveX -= 1;
    if (keys.KeyD || keys.ArrowRight) moveX += 1;
    if (keys.KeyW || keys.ArrowUp) moveZ -= 1;
    if (keys.KeyS || keys.ArrowDown) moveZ += 1;
    return {
      moveX: moveX, moveZ: moveZ, lookDx: 0, lookDy: 0,
      boost: !!(keys.ShiftLeft || keys.ShiftRight),
      grab: !!keys.KeyV, up: !!keys.KeyQ, down: !!keys.KeyE,
      primary: false, secondary: false, jump: false, punch: false,
      keys: keys, just: {},
    };
  }

  function mountControls() {
    if (controls || !window.KidArcadeControls) return;
    controls = KidArcadeControls.mount({
      actions: [
        { id: 'primary', label: 'Peck' },
        { id: 'secondary', label: 'Poop' },
        { id: 'boost', label: 'Boost' },
        { id: 'up', label: 'Up', small: true },
        { id: 'down', label: 'Down', small: true },
        { id: 'grab', label: 'Grab', small: true },
      ],
      onAction: function (id, down) {
        if (id === 'grab' && !down) {
          releaseGrab();
          return;
        }
        if (!down || !gameStarted) return;
        if (id === 'primary' || id === 'punch' || id === 'jump') tryAttack();
        if (id === 'secondary' || id === 'poop') tryPoop();
      },
    });
  }

  // ——— helpers ———
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function mat(c) { return new THREE.MeshLambertMaterial({ color: c }); }
  function box(w, h, d, c) {
    return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c));
  }

  // ——— world ———
  function buildWorld() {
    // ground
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(200, 200),
      mat(0x4a9a50)
    );
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    // plaza pavement
    const plaza = new THREE.Mesh(
      new THREE.BoxGeometry(50, 0.15, 50),
      mat(0x8a8a90)
    );
    plaza.position.y = 0.05;
    scene.add(plaza);

    // roads
    for (let i = -2; i <= 2; i++) {
      const road = box(8, 0.12, 180, 0x3a3a40);
      road.position.set(i * 40, 0.06, 0);
      scene.add(road);
      const road2 = box(180, 0.12, 8, 0x3a3a40);
      road2.position.set(0, 0.06, i * 40);
      scene.add(road2);
    }

    // buildings
    for (let i = 0; i < 40; i++) {
      const w = rand(6, 14);
      const h = rand(8, 28);
      const d = rand(6, 14);
      const b = box(w, h, d, new THREE.Color().setHSL(rand(0.05, 0.15), 0.15, rand(0.35, 0.55)).getHex());
      let x = rand(-80, 80);
      let z = rand(-80, 80);
      if (Math.abs(x) < 28 && Math.abs(z) < 28) {
        x += Math.sign(x || 1) * 30;
        z += Math.sign(z || 1) * 30;
      }
      b.position.set(x, h / 2, z);
      scene.add(b);
    }

    // trees
    for (let i = 0; i < 25; i++) {
      const g = new THREE.Group();
      const trunk = box(0.6, 2.5, 0.6, 0x6a4420);
      trunk.position.y = 1.25;
      const leaves = new THREE.Mesh(new THREE.SphereGeometry(2, 8, 8), mat(0x2d8a3a));
      leaves.position.y = 3.5;
      g.add(trunk, leaves);
      g.position.set(rand(-70, 70), 0, rand(-70, 70));
      if (Math.hypot(g.position.x, g.position.z) < 18) g.position.x += 25;
      scene.add(g);
    }

    // park benches / props
    for (let i = 0; i < 8; i++) {
      const bench = box(2.2, 0.4, 0.6, 0x6b4a2a);
      bench.position.set(rand(-20, 20), 0.35, rand(-20, 20));
      scene.add(bench);
    }
  }
  buildWorld();

  // ——— people (simple multi-part + ragdoll) ———
  const people = [];
  const SKINS = [0xffe0bd, 0xf5c59a, 0xc68642, 0x8d5524];
  const SHIRTS = [0x3a7bd5, 0xe74c3c, 0x2ecc71, 0xf1c40f, 0x9b59b6, 0xecf0f1, 0x1abc9c];
  const PANTS = [0x2c3e50, 0x34495e, 0x5d4e37, 0x1a1a2e];

  function makePerson(x, z, isCop) {
    const g = new THREE.Group();
    const skin = SKINS[(Math.random() * SKINS.length) | 0];
    const shirt = isCop ? 0x1a3a6a : SHIRTS[(Math.random() * SHIRTS.length) | 0];
    const pants = isCop ? 0x1a1a28 : PANTS[(Math.random() * PANTS.length) | 0];

    const torso = box(0.55, 0.7, 0.3, shirt);
    torso.position.y = 1.15;
    const head = box(0.4, 0.4, 0.4, skin);
    head.position.y = 1.75;
    const legL = box(0.2, 0.55, 0.22, pants);
    legL.position.set(-0.14, 0.4, 0);
    const legR = box(0.2, 0.55, 0.22, pants);
    legR.position.set(0.14, 0.4, 0);
    const armL = box(0.16, 0.55, 0.16, shirt);
    armL.position.set(-0.4, 1.15, 0);
    const armR = box(0.16, 0.55, 0.16, shirt);
    armR.position.set(0.4, 1.15, 0);

    if (isCop) {
      const hat = box(0.45, 0.15, 0.45, 0x0a1a30);
      hat.position.y = 2.0;
      g.add(hat);
      const badge = box(0.12, 0.12, 0.05, 0xffd700);
      badge.position.set(0.2, 1.25, 0.18);
      g.add(badge);
    }

    g.add(torso, head, legL, legR, armL, armR);
    g.position.set(x, 0, z);
    scene.add(g);

    const p = {
      mesh: g,
      parts: { torso, head, legL, legR, armL, armR },
      x, y: 0, z,
      vx: 0, vy: 0, vz: 0,
      // whole-body tumble (connected ragdoll — never dismembers)
      rx: 0, ry: rand(0, Math.PI * 2), rz: 0,
      wx: 0, wy: 0, wz: 0,
      yaw: rand(0, Math.PI * 2),
      ragdoll: false,
      dead: false,
      limpT: 0,
      hp: isCop ? 60 : 30,
      isCop: !!isCop,
      walkT: rand(0, 10),
      grabOffset: null,
      stun: 0,
      hitCd: 0,
    };
    people.push(p);
    return p;
  }

  // civilians
  for (let i = 0; i < 55; i++) {
    makePerson(rand(-35, 35), rand(-35, 35), false);
  }
  // police patrol
  for (let i = 0; i < 6; i++) {
    makePerson(rand(-40, 40), rand(-40, 40), true);
  }

  // ——— public-safe hit juice (stars / feathers — NO gore) ———
  const juiceFX = [];
  const JUICE_COLORS = [0xffe566, 0xff9f0a, 0x5b8cff, 0x64d2ff, 0x30d158, 0xff6bcb, 0xffffff];

  function spawnHitJuice(x, y, z, power) {
    const n = 6 + ((power || 1) * 4) | 0;
    for (let i = 0; i < n; i++) {
      const col = JUICE_COLORS[(Math.random() * JUICE_COLORS.length) | 0];
      const s = rand(0.06, 0.16);
      // star-ish box or sphere puff
      const mesh = new THREE.Mesh(
        Math.random() < 0.45
          ? new THREE.BoxGeometry(s, s * 0.35, s * 0.15)
          : new THREE.SphereGeometry(s, 5, 5),
        new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.95 })
      );
      mesh.position.set(x, y, z);
      scene.add(mesh);
      juiceFX.push({
        mesh,
        x, y, z,
        vx: rand(-4, 4) * (power || 1),
        vy: rand(2, 7) * (power || 1),
        vz: rand(-4, 4) * (power || 1),
        life: rand(0.35, 0.85),
        spin: rand(-8, 8),
      });
    }
    // KO flash ring
    const flash = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffe566, transparent: true, opacity: 0.8 })
    );
    flash.position.set(x, y, z);
    scene.add(flash);
    juiceFX.push({
      mesh: flash,
      x, y, z,
      vx: 0, vy: 1.5, vz: 0,
      life: 0.22,
      grow: true,
      spin: 0,
    });
  }

  // alias so remaining call sites keep working if any
  function spawnCartoonBlood(x, y, z, power) {
    spawnHitJuice(x, y, z, power);
  }

  function updateBlood(dt) {
    for (let i = juiceFX.length - 1; i >= 0; i--) {
      const b = juiceFX[i];
      b.life -= dt;
      if (b.grow) {
        b.mesh.scale.multiplyScalar(1 + dt * 10);
        if (b.mesh.material) b.mesh.material.opacity = Math.max(0, b.life * 4);
      } else {
        b.vy -= 16 * dt;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.z += b.vz * dt;
        if (b.y < 0.05) {
          scene.remove(b.mesh);
          juiceFX.splice(i, 1);
          continue;
        }
        b.mesh.position.set(b.x, b.y, b.z);
        if (b.spin) b.mesh.rotation.z += b.spin * dt;
      }
      if (b.life <= 0) {
        scene.remove(b.mesh);
        juiceFX.splice(i, 1);
      }
    }
  }

  function startRagdoll(p, ix, iy, iz) {
    // Keep ONE connected body — tumble as a whole floppy person
    if (!p.ragdoll) {
      p.ragdoll = true;
      p.limpT = 0;
      // lay center of mass roughly mid-torso height
      if (p.y < 0.5) p.y = 0.9;
      // random spin so they cartwheel
      p.wx = rand(-6, 6) + (iz || 0) * 0.3;
      p.wy = rand(-3, 3);
      p.wz = rand(-6, 6) + (ix || 0) * 0.3;
      // flop limbs into a limp pose (still attached)
      limpPose(p, 1);
    }
    p.vx += ix || 0;
    p.vy += (iy != null ? iy : 3) + 1.5;
    p.vz += iz || 0;
    // extra angular kick
    p.wx += rand(-4, 4);
    p.wz += rand(-4, 4);
  }

  function limpPose(p, amount) {
    const a = amount || 1;
    const t = p.limpT || 0;
    // floppy limb wiggle while tumbling — limbs stay parented
    p.parts.armL.rotation.z = 0.9 * a + Math.sin(t * 9) * 0.5;
    p.parts.armR.rotation.z = -0.9 * a + Math.cos(t * 8) * 0.5;
    p.parts.armL.rotation.x = Math.sin(t * 7) * 0.8;
    p.parts.armR.rotation.x = Math.cos(t * 6.5) * 0.8;
    p.parts.legL.rotation.x = 0.4 * a + Math.sin(t * 5) * 0.6;
    p.parts.legR.rotation.x = 0.5 * a + Math.cos(t * 5.5) * 0.6;
    p.parts.head.rotation.z = Math.sin(t * 4) * 0.35;
    p.parts.head.rotation.x = Math.cos(t * 3) * 0.25;
  }

  function damagePerson(p, dmg, ix, iy, iz) {
    // throttle multi-hit same frame / continuous fly-through
    if (p.hitCd > 0 && dmg > 0) {
      // still apply a little impulse
      p.vx += (ix || 0) * 0.15;
      p.vy += (iy || 0) * 0.1;
      p.vz += (iz || 0) * 0.15;
      return;
    }
    p.hitCd = 0.28;

    // already KO — fling + stars
    if (p.dead) {
      startRagdoll(p, ix || 0, iy || 2, iz || 0);
      spawnCartoonBlood(p.x, p.y + 0.8, p.z, 0.55);
      return;
    }
    p.hp -= dmg;
    startRagdoll(p, ix || 0, iy || 2, iz || 0);
    spawnCartoonBlood(p.x, (p.y || 0) + 1.1, p.z, 0.9 + Math.min(1.5, dmg / 20));
    if (p.hp <= 0 && !p.dead) {
      p.dead = true;
      kills++;
      heat = clamp(heat + (p.isCop ? 18 : 8), 0, 100);
      killsEl.textContent = String(kills);
      updateHeatUI();
      maybeSpawnCops();
      music.setIntensity(heat / 100);
      spawnCartoonBlood(p.x, p.y + 1, p.z, 1.4);
    } else {
      heat = clamp(heat + 2, 0, 100);
      updateHeatUI();
      music.setIntensity(heat / 100);
    }
  }

  function updateHeatUI() {
    heatEl.textContent = 'Heat: ' + Math.round(heat);
    heatEl.className = 'heat' + (heat > 50 ? ' hi' : '');
    wantedEl.classList.toggle('show', heat >= 25);
  }

  function maybeSpawnCops() {
    const aliveCops = people.filter((p) => p.isCop && !p.dead).length;
    const totalCops = people.filter((p) => p.isCop).length;
    const want = Math.min(18, 6 + Math.floor(heat / 12));
    let guard = 0;
    while (aliveCops + guard < want && totalCops + guard < 20 && guard < 4) {
      const a = rand(0, Math.PI * 2);
      const r = rand(22, 48);
      makePerson(bird.x + Math.cos(a) * r, bird.z + Math.sin(a) * r, true);
      guard++;
    }
  }

  // ——— weapons on ground ———
  const pickups = [];
  const WEAPON_DEFS = {
    knife: { name: '🔪 Knife', dmg: 25, range: 1.8, melee: true, color: 0xcccccc },
    sword: { name: '⚔️ Sword', dmg: 40, range: 2.4, melee: true, color: 0xa0c0ff },
    gun: { name: '🔫 Pistol', dmg: 35, range: 40, melee: false, color: 0x333338, ammo: 12 },
  };

  function spawnPickup(type, x, z) {
    const def = WEAPON_DEFS[type];
    const m = box(type === 'sword' ? 0.15 : 0.25, type === 'sword' ? 1.2 : 0.15, 0.15, def.color);
    if (type === 'sword') m.position.set(x, 0.7, z);
    else m.position.set(x, 0.2, z);
    if (type === 'knife') {
      m.scale.set(0.7, 0.7, 2);
    }
    scene.add(m);
    pickups.push({ type, mesh: m, x, z, taken: false });
  }

  // scatter weapons
  ['knife', 'knife', 'sword', 'sword', 'gun', 'gun', 'gun', 'knife'].forEach((t) => {
    spawnPickup(t, rand(-30, 30), rand(-30, 30));
  });

  // ——— projectiles (poop + bullets) ———
  const projectiles = [];

  function fireProjectile(kind) {
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(bird.pitch, bird.yaw, 0, 'YXZ'));
    const speed = kind === 'poop' ? 14 : 55;
    const col = kind === 'poop' ? 0x6b4423 : 0xffee55;
    const size = kind === 'poop' ? 0.22 : 0.08;
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(size, 6, 6),
      new THREE.MeshBasicMaterial({ color: col })
    );
    m.position.set(bird.x + dir.x * 0.8, bird.y + dir.y * 0.8, bird.z + dir.z * 0.8);
    scene.add(m);
    projectiles.push({
      mesh: m,
      x: m.position.x, y: m.position.y, z: m.position.z,
      vx: dir.x * speed + bird.vx * 0.3,
      vy: dir.y * speed + bird.vy * 0.3 + (kind === 'poop' ? 1 : 0),
      vz: dir.z * speed + bird.vz * 0.3,
      kind,
      life: kind === 'poop' ? 3 : 1.2,
      dmg: kind === 'poop' ? 8 : (weapon && WEAPON_DEFS[weapon.type] ? WEAPON_DEFS[weapon.type].dmg : 20),
    });
  }

  // ——— music (procedural heat intensity) ———
  const music = {
    ctx: null,
    master: null,
    nodes: [],
    intensity: 0,
    timer: null,
    step: 0,
    ensure() {
      if (this.ctx) return;
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.12;
      this.master.connect(this.ctx.destination);
    },
    setIntensity(t) {
      this.intensity = clamp(t, 0, 1);
      if (this.master) {
        this.master.gain.value = 0.08 + this.intensity * 0.18;
      }
    },
    beep(freq, dur, type, vol) {
      if (!this.ctx) return;
      const o = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      o.type = type || 'square';
      o.frequency.value = freq;
      g.gain.value = vol || 0.08;
      o.connect(g);
      g.connect(this.master);
      const t = this.ctx.currentTime;
      g.gain.setValueAtTime(vol || 0.08, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      o.start(t);
      o.stop(t + dur + 0.02);
    },
    tick() {
      if (!this.ctx || this.ctx.state !== 'running') return;
      const i = this.intensity;
      // base chill bird chirp when low heat
      if (i < 0.2) {
        if (this.step % 8 === 0) this.beep(880 + Math.random() * 200, 0.08, 'sine', 0.04);
      } else {
        // police-ish siren layers
        const siren = 400 + Math.sin(this.step * 0.4) * (200 + i * 300);
        this.beep(siren, 0.12, 'sawtooth', 0.03 + i * 0.05);
        if (i > 0.4 && this.step % 2 === 0) this.beep(100 + i * 40, 0.08, 'square', 0.05 + i * 0.04);
        if (i > 0.7 && this.step % 1 === 0) this.beep(60, 0.06, 'square', 0.06);
      }
      // kick when high
      if (i > 0.5 && this.step % 4 === 0) this.beep(80, 0.1, 'triangle', 0.08);
      this.step++;
    },
    startLoop() {
      this.ensure();
      if (this.timer) return;
      const beat = () => {
        this.tick();
        // faster as heat rises
        const ms = 280 - this.intensity * 160;
        this.timer = setTimeout(beat, ms);
      };
      beat();
    },
  };

  // sfx
  function sfxHit() {
    music.ensure();
    music.beep(150, 0.1, 'square', 0.1);
  }
  function sfxPoop() {
    music.ensure();
    music.beep(90, 0.15, 'triangle', 0.12);
  }
  function sfxGrab() {
    music.ensure();
    music.beep(400, 0.08, 'sine', 0.08);
  }

  // ——— input ———
  function resize() {
    const w = innerWidth;
    const h = innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  canvas.addEventListener('click', () => {
    if (!gameStarted) return;
    requestLock();
  });
  document.addEventListener('pointerlockchange', () => {
    locked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!locked) return;
    bird.yaw -= e.movementX * 0.0022;
    bird.pitch -= e.movementY * 0.0022;
    bird.pitch = clamp(bird.pitch, -1.4, 1.4);
  });
  // Fallback keyboard when shared controls are unavailable
  window.addEventListener('keydown', (e) => {
    if (controls) return; // KidArcadeControls owns keys
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA')) return;
    keys[e.code] = true;
    if (e.code === 'KeyP' && gameStarted) tryPoop();
    if ((e.code === 'KeyF' || e.code === 'Space') && gameStarted) tryAttack();
  });
  window.addEventListener('keyup', (e) => {
    if (controls) return;
    keys[e.code] = false;
    if (e.code === 'KeyV') releaseGrab();
  });
  document.addEventListener('mousedown', (e) => {
    if (!gameStarted || e.button !== 0) return;
    // Touch/UI buttons handle their own attack; only fire on locked mouse click
    if (isTouchPlay() && !locked) return;
    if (e.target && e.target.closest && e.target.closest('#kid-arcade-controls')) return;
    tryAttack();
  });

  btnStart.addEventListener('click', () => {
    gameStarted = true;
    overlay.classList.add('hidden');
    music.ensure();
    music.ctx.resume();
    music.startLoop();
    mountControls();
    requestLock();
  });

  // ——— actions ———
  function tryPoop() {
    if (poopCd > 0) return;
    poopCd = 0.35;
    sfxPoop();
    fireProjectile('poop');
  }

  function tryAttack() {
    if (attackCd > 0) return;
    if (!weapon) {
      // beak peck — short range
      attackCd = 0.35;
      beakAttack(12, 2.2);
      return;
    }
    const def = WEAPON_DEFS[weapon.type];
    if (def.melee) {
      attackCd = 0.4;
      beakAttack(def.dmg, def.range);
      sfxHit();
    } else {
      if (weapon.ammo <= 0) {
        weaponEl.textContent = '🔫 empty — find another gun';
        return;
      }
      attackCd = 0.22;
      weapon.ammo--;
      weaponEl.textContent = def.name + ' (' + weapon.ammo + ')';
      fireProjectile('bullet');
      music.beep(900, 0.05, 'square', 0.1);
    }
  }

  function beakAttack(dmg, range) {
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(bird.pitch, bird.yaw, 0, 'YXZ'));
    for (const p of people) {
      if (p.dead && p.ragdoll) continue;
      const dx = p.x - bird.x;
      const dy = (p.y + 1) - bird.y;
      const dz = p.z - bird.z;
      const dist = Math.hypot(dx, dy, dz);
      if (dist < range) {
        const dot = (dx * dir.x + dy * dir.y + dz * dir.z) / (dist || 1);
        if (dot > 0.35 || dist < 1.2) {
          damagePerson(p, dmg, dir.x * 8, 4, dir.z * 8);
          sfxHit();
        }
      }
    }
  }

  function tryGrab() {
    if (grabbed != null) return;
    let best = -1;
    let bestD = 3.2;
    for (let i = 0; i < people.length; i++) {
      const p = people[i];
      if (p.dead && !p.ragdoll) continue;
      const d = Math.hypot(p.x - bird.x, (p.y + 1) - bird.y, p.z - bird.z);
      if (d < bestD) {
        bestD = d;
        best = i;
      }
    }
    if (best >= 0) {
      grabbed = best;
      const p = people[best];
      if (!p.ragdoll) startRagdoll(p, 0, 2, 0);
      sfxGrab();
      grabEl.textContent = 'Grab: holding ' + (p.isCop ? 'cop' : 'civilian') + '!';
      heat = clamp(heat + 1, 0, 100);
      updateHeatUI();
    }
  }

  function releaseGrab() {
    if (grabbed == null) return;
    const p = people[grabbed];
    const dir = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(bird.pitch, bird.yaw, 0, 'YXZ'));
    // throw whole body
    startRagdoll(p, dir.x * 18 + bird.vx, 8 + dir.y * 10 + bird.vy, dir.z * 18 + bird.vz);
    p.wx += rand(-10, 10);
    p.wz += rand(-10, 10);
    // fall damage chance
    if (!p.dead) {
      p.hp -= 15;
      if (p.hp <= 0) {
        p.dead = true;
        kills++;
        heat = clamp(heat + 10, 0, 100);
        killsEl.textContent = String(kills);
        updateHeatUI();
        music.setIntensity(heat / 100);
        spawnCartoonBlood(p.x, p.y + 0.5, p.z, 1.2);
      }
    }
    grabbed = null;
    grabEl.textContent = 'Grab: empty';
  }

  function tryPickupWeapons() {
    for (const pk of pickups) {
      if (pk.taken) continue;
      const d = Math.hypot(pk.x - bird.x, pk.z - bird.z);
      const dy = Math.abs(0.5 - bird.y);
      if (d < 2.2 && dy < 3) {
        pk.taken = true;
        pk.mesh.visible = false;
        const def = WEAPON_DEFS[pk.type];
        weapon = {
          type: pk.type,
          ammo: def.ammo || 0,
        };
        weaponEl.textContent = def.melee ? def.name : def.name + ' (' + weapon.ammo + ')';
        music.beep(600, 0.1, 'sine', 0.1);
      }
    }
  }

  // ——— simulation ———
  function updateBird(dt) {
    const st = pollInput();

    // Touch look (right-drag); desktop uses pointer-lock mousemove
    if (st.lookDx || st.lookDy) {
      bird.yaw -= st.lookDx * 0.0022;
      bird.pitch -= st.lookDy * 0.0022;
      bird.pitch = clamp(bird.pitch, -1.4, 1.4);
    }

    // hold grab (V / button)
    if (st.grab) tryGrab();

    const forward = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(bird.pitch, bird.yaw, 0, 'YXZ'));
    const right = new THREE.Vector3(1, 0, 0).applyEuler(new THREE.Euler(0, bird.yaw, 0, 'YXZ'));

    let ax = 0, ay = 0, az = 0;
    const spd = st.boost ? bird.boost : bird.speed;
    const fAmt = -st.moveZ; // +1 forward
    const sAmt = st.moveX;  // +1 right
    if (fAmt > 0) {
      ax += forward.x * spd * fAmt;
      ay += forward.y * spd * fAmt;
      az += forward.z * spd * fAmt;
    } else if (fAmt < 0) {
      ax += forward.x * spd * 0.6 * fAmt;
      ay += forward.y * spd * 0.6 * fAmt;
      az += forward.z * spd * 0.6 * fAmt;
    }
    ax += right.x * spd * 0.75 * sAmt;
    az += right.z * spd * 0.75 * sAmt;
    if (st.up) ay += spd * 0.9;
    if (st.down) ay -= spd * 0.9;

    // light gravity when not thrusting up
    if (ay <= 0.1 && !st.up && fAmt <= 0) {
      ay -= 4;
    }

    // accelerate toward wish
    bird.vx += (ax - bird.vx) * Math.min(1, dt * 3);
    bird.vy += (ay - bird.vy) * Math.min(1, dt * 3);
    bird.vz += (az - bird.vz) * Math.min(1, dt * 3);

    // damping
    bird.vx *= 1 - dt * 0.4;
    bird.vy *= 1 - dt * 0.4;
    bird.vz *= 1 - dt * 0.4;

    bird.x += bird.vx * dt;
    bird.y += bird.vy * dt;
    bird.z += bird.vz * dt;

    bird.y = clamp(bird.y, 0.8, 60);
    bird.x = clamp(bird.x, -95, 95);
    bird.z = clamp(bird.z, -95, 95);

    camera.position.set(bird.x, bird.y, bird.z);
    camera.rotation.x = bird.pitch;
    camera.rotation.y = bird.yaw;

    // fly-through whole-body ragdoll
    for (const p of people) {
      const d = Math.hypot(p.x - bird.x, (p.y + 0.9) - bird.y, p.z - bird.z);
      const speed = Math.hypot(bird.vx, bird.vy, bird.vz);
      if (d < 1.5 && speed > 6) {
        const ix = bird.vx * 0.9;
        const iy = Math.abs(bird.vy) * 0.5 + 5;
        const iz = bird.vz * 0.9;
        damagePerson(p, p.dead ? 0 : 10 + speed * 0.5, ix, iy, iz);
        sfxHit();
      }
    }

    tryPickupWeapons();

    // carry grabbed person under bird (whole body, floppy)
    if (grabbed != null) {
      const p = people[grabbed];
      if (!p.ragdoll) startRagdoll(p, 0, 1, 0);
      const hold = new THREE.Vector3(0, -1.3, -0.9).applyEuler(new THREE.Euler(bird.pitch, bird.yaw, 0, 'YXZ'));
      p.x = bird.x + hold.x;
      p.y = bird.y + hold.y;
      p.z = bird.z + hold.z;
      p.vx = bird.vx;
      p.vy = bird.vy;
      p.vz = bird.vz;
      // dangle / spin gently while held
      p.wx = Math.sin(performance.now() * 0.008) * 2;
      p.wy = 1.5;
      p.wz = Math.cos(performance.now() * 0.007) * 2;
      p.limpT += 0.05;
      limpPose(p, 1);
      p.mesh.position.set(p.x, p.y, p.z);
      p.mesh.rotation.set(p.rx, p.ry, p.rz);
    }
  }

  function updatePeople(dt) {
    for (const p of people) {
      if (p.hitCd > 0) p.hitCd -= dt;
      if (p.ragdoll) {
        // WHOLE-BODY ragdoll physics (connected mesh group)
        if (grabbed != null && people[grabbed] === p) {
          // pose updated in updateBird while held
          continue;
        }
        p.limpT += dt;
        p.vy -= 22 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.z += p.vz * dt;
        p.rx += p.wx * dt;
        p.ry += p.wy * dt;
        p.rz += p.wz * dt;
        // ground: bounce as one body, settle on side/back
        if (p.y < 0.45) {
          p.y = 0.45;
          if (p.vy < -6 && p.hitCd <= 0) {
            // hard landing squish — cartoon blobs only
            spawnCartoonBlood(p.x, 0.5, p.z, 0.45);
            p.hitCd = 0.4;
          }
          p.vy *= -0.28;
          p.vx *= 0.82;
          p.vz *= 0.82;
          p.wx *= 0.7;
          p.wy *= 0.7;
          p.wz *= 0.7;
          // settle flat-ish
          if (Math.hypot(p.vx, p.vz) < 0.8 && Math.abs(p.vy) < 1.5) {
            p.vx *= 0.9;
            p.vz *= 0.9;
            // ease toward lying on back
            const targetRx = Math.PI / 2;
            p.rx += (targetRx - p.rx) * Math.min(1, dt * 3);
            p.wx *= 0.85;
            p.wz *= 0.85;
          }
        }
        p.x = clamp(p.x, -90, 90);
        p.z = clamp(p.z, -90, 90);
        limpPose(p, 1);
        p.mesh.position.set(p.x, p.y, p.z);
        p.mesh.rotation.set(p.rx, p.ry, p.rz);
        p.mesh.visible = true;
        continue;
      }

      if (p.dead) continue;

      p.walkT += dt;
      // cops chase bird when heat high
      if (p.isCop && heat >= 20) {
        const dx = bird.x - p.x;
        const dz = bird.z - p.z;
        const dist = Math.hypot(dx, dz) || 1;
        const spd = 3.5 + heat * 0.04;
        p.x += (dx / dist) * spd * dt;
        p.z += (dz / dist) * spd * dt;
        p.yaw = Math.atan2(dx, dz);
        if (dist < 12 && bird.y < 10 && Math.random() < dt * 0.4) {
          if (dist < 4 && bird.y < 4) {
            bird.vx += (Math.random() - 0.5) * 8;
            bird.vz += (Math.random() - 0.5) * 8;
            music.beep(1200, 0.04, 'square', 0.05);
          }
        }
      } else {
        p.x += Math.sin(p.walkT * 0.7 + p.yaw) * 1.2 * dt;
        p.z += Math.cos(p.walkT * 0.5 + p.yaw) * 1.2 * dt;
        if (Math.random() < dt * 0.2) p.yaw = rand(0, Math.PI * 2);
      }
      p.x = clamp(p.x, -90, 90);
      p.z = clamp(p.z, -90, 90);
      p.y = 0;
      p.mesh.position.set(p.x, 0, p.z);
      p.mesh.rotation.set(0, p.yaw, 0);
      // walk anim
      p.parts.legL.rotation.x = Math.sin(p.walkT * 6) * 0.5;
      p.parts.legR.rotation.x = -Math.sin(p.walkT * 6) * 0.5;
      p.parts.armL.rotation.z = 0;
      p.parts.armR.rotation.z = 0;
      p.parts.armL.rotation.x = 0;
      p.parts.armR.rotation.x = 0;
      p.parts.head.rotation.set(0, 0, 0);
    }
  }

  function updateProjectiles(dt) {
    for (let i = projectiles.length - 1; i >= 0; i--) {
      const pr = projectiles[i];
      pr.life -= dt;
      pr.vy -= (pr.kind === 'poop' ? 16 : 2) * dt;
      pr.x += pr.vx * dt;
      pr.y += pr.vy * dt;
      pr.z += pr.vz * dt;
      pr.mesh.position.set(pr.x, pr.y, pr.z);

      let hit = false;
      if (pr.y < 0.1) {
        hit = true;
        // poop stain
        if (pr.kind === 'poop') {
          const stain = new THREE.Mesh(
            new THREE.CircleGeometry(0.35, 8),
            new THREE.MeshBasicMaterial({ color: 0x5a3a18, transparent: true, opacity: 0.7 })
          );
          stain.rotation.x = -Math.PI / 2;
          stain.position.set(pr.x, 0.08, pr.z);
          scene.add(stain);
        }
      }
      for (const p of people) {
        if (p.dead && pr.kind !== 'poop') continue;
        const d = Math.hypot(p.x - pr.x, (p.y + 1) - pr.y, p.z - pr.z);
        if (d < 1.1) {
          damagePerson(p, pr.dmg, pr.vx * 0.3, 3, pr.vz * 0.3);
          hit = true;
          sfxHit();
          break;
        }
      }
      if (pr.life <= 0 || hit) {
        scene.remove(pr.mesh);
        projectiles.splice(i, 1);
      }
    }
  }

  // heat slowly decays if not chaos
  function updateHeat(dt) {
    if (heat > 0) {
      heat = Math.max(0, heat - dt * 0.35);
      updateHeatUI();
      music.setIntensity(heat / 100);
    }
  }

  // ——— loop ———
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;

    if (gameStarted) {
      if (attackCd > 0) attackCd -= dt;
      if (poopCd > 0) poopCd -= dt;
      updateBird(dt);
      updatePeople(dt);
      updateProjectiles(dt);
      updateBlood(dt);
      updateHeat(dt);
    }

    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
