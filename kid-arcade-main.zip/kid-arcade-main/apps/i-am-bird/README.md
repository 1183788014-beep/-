# I Am Bird (public safe)

**Kid-made with Grok Build** · public fork · **no gore**.

Canon (local, may include gore juice) lives at `projects/creative-visualizers-and-games/i-am-bird-arkhe/`.  
This folder is a **fork for GitHub Pages / public play**.

## Changes from canon
- Blood particles → stars / feather-ish hit juice
- HUD: KO score (same counter id, soft label)
- Copy softened for family audience

## Controls
Touch stick + on-screen buttons on phones/tablets; **WASD + mouse** (pointer lock) on desktop. Shared kit: `shared/mobile-controls.js`.

## Play
Open `index.html` via any static server, or from the arcade root.

```bash
cd projects/public-kid-arcade
python3 -m http.server 8800 --bind 127.0.0.1
# open http://127.0.0.1:8800/apps/i-am-bird/
```
