/**
 * Mac Simulator (public) — browser macOS-style desktop
 * Inspired by macOS · not affiliated with Apple
 * Public pack: KidArcadeChat presets + relative game URLs (no localhost / Ollama required)
 */
(function () {
  'use strict';

  const boot = document.getElementById('boot');
  const bootFill = document.getElementById('boot-fill');
  const desktop = document.getElementById('desktop');
  const windowsEl = document.getElementById('windows');
  const clockEl = document.getElementById('clock');
  const menuApp = document.getElementById('menu-app');
  const appleMenu = document.getElementById('apple-menu');
  const spotlight = document.getElementById('spotlight');
  const spotInput = document.getElementById('spot-input');
  const spotResults = document.getElementById('spot-results');
  const toastEl = document.getElementById('toast');

  let zTop = 20;
  let winId = 0;
  /** @type {Map<string, HTMLElement>} */
  const openWins = new Map();
  let focusedId = null;
  let compactForced = null; // null = auto, true/false = user override

  /**
   * Game base path:
   * - Pack mode (apps/mac-simulator): ../../games/
   * - Standalone Pages (mac/): ./games/
   * Set on <body data-games-base="..."> or window.MAC_GAMES_BASE
   */
  const GAMES_BASE = (
    window.MAC_GAMES_BASE ||
    document.body.getAttribute('data-games-base') ||
    '../../games/'
  ).replace(/\/?$/, '/');
  const PHONE_URL =
    window.MAC_PHONE_URL ||
    document.body.getAttribute('data-phone-url') ||
    '../phone-simulator/index.html';

  function gameUrl(folder) {
    return GAMES_BASE + folder + '/index.html';
  }

  /** Catalog of playable titles (all open in-window via iframe) */
  const GAME_CATALOG = [
    { id: 'bird', folder: 'i-am-bird', title: 'I Am Bird', desc: 'Bird POV plaza · stars not gore', thumb: '🐦', tone: 'linear-gradient(135deg,#6af,#f6c)', w: 960, h: 640 },
    { id: 'monkey', folder: 'i-am-monkey', title: 'I Am Monkey', desc: 'Mitts · flop · Ellie chat', thumb: '🐒', tone: 'linear-gradient(135deg,#c84,#640)', w: 960, h: 640 },
    { id: 'bloxy', folder: 'bloxy-classic', title: 'BLOXY Classic', desc: '2008-style build & play', thumb: '🧱', tone: 'linear-gradient(135deg,#6cf,#08f)', w: 960, h: 640 },
    { id: 'cat', folder: 'i-am-cat', title: 'I Am Cat', desc: 'Cat house POV sim', thumb: '🐱', tone: 'linear-gradient(135deg,#f80,#a40)', w: 900, h: 600 },
    { id: 'jobsim', folder: 'job-sim', title: 'Job Sim', desc: 'Comedy job shifts', thumb: '💼', tone: 'linear-gradient(135deg,#68f,#24a)', w: 900, h: 600 },
    { id: 'lifesim', folder: 'life-day-sim', title: 'Day Life Sim', desc: 'One full day routine', thumb: '☀️', tone: 'linear-gradient(135deg,#fd6,#f80)', w: 900, h: 600 },
    { id: 'minecraft', folder: 'minecraft-grass', title: 'Minecraft Grass', desc: 'Voxel grass mini', thumb: '🟩', tone: 'linear-gradient(135deg,#3a8,#1a5)', w: 900, h: 600 },
    { id: 'presscoin', folder: 'presscoin-clicker', title: 'Presscoin Clicker', desc: 'Click Me! idle toy', thumb: '🪙', tone: 'linear-gradient(135deg,#f5c542,#c90)', w: 720, h: 560 },
    { id: 'chiptune', folder: 'pixel-noob-player', title: 'Pixel Noob Player', desc: 'Chiptune player toy', thumb: '🎵', tone: 'linear-gradient(135deg,#a78bfa,#6c9eff)', w: 720, h: 520 },
    { id: 'msm', folder: 'pixl-singing-monsters', title: 'Pixl Singing Monsters', desc: 'Monster jam fan toy', thumb: '👾', tone: 'linear-gradient(135deg,#7c3aed,#22d3ee)', w: 900, h: 600 },
    { id: 'rbx2016', folder: 'roblox-2016-web', title: 'Roblox 2016 Web', desc: 'Classic web shell fan toy', thumb: '🟥', tone: 'linear-gradient(135deg,#e2231a,#7a1010)', w: 960, h: 640 },
    { id: 'kinito', folder: 'kinito-pixel-pet', title: 'Kinito Pixel Pet', desc: 'Pixel desk friend', thumb: '👾', tone: 'linear-gradient(135deg,#5b8cff,#30d158)', w: 720, h: 560 },
    { id: 'verity', folder: 'verity-3am-knock', title: 'Verity 3am Knock', desc: 'Spooky-lite night knock', thumb: '🚪', tone: 'linear-gradient(135deg,#1e1b4b,#4c1d95)', w: 900, h: 600 },
    { id: 'aicity', folder: 'ai-city-collapse', title: 'AI City Collapse', desc: 'City chaos toy', thumb: '🏙️', tone: 'linear-gradient(135deg,#64748b,#0ea5e9)', w: 960, h: 640 },
    { id: 'bloxymp', folder: 'bloxy-multiplayer', title: 'Bloxy Multiplayer', desc: 'Web MP BLOXY (solo ok)', thumb: '🌐', tone: 'linear-gradient(135deg,#38bdf8,#2563eb)', w: 960, h: 640 },
    { id: 'recroom', folder: 'rec-room', title: 'Rec Room Arkhē', desc: 'Rec-style room toy', thumb: '🥽', tone: 'linear-gradient(135deg,#f472b6,#a855f7)', w: 960, h: 640 },
  ];

  const APPS = {
    finder: { title: 'Finder', w: 640, h: 420 },
    safari: { title: 'Safari', w: 720, h: 480 },
    messages: { title: 'Messages', w: 640, h: 520 },
    mail: { title: 'Mail', w: 560, h: 420 },
    maps: { title: 'Maps', w: 640, h: 440 },
    photos: { title: 'Photos', w: 560, h: 400 },
    notes: { title: 'Notes', w: 560, h: 400 },
    calc: { title: 'Calculator', w: 300, h: 400 },
    terminal: { title: 'Terminal', w: 560, h: 340 },
    settings: { title: 'System Settings', w: 640, h: 420 },
    about: { title: 'About This Mac', w: 360, h: 320 },
    trash: { title: 'Trash', w: 480, h: 320 },
    games: { title: 'Games', w: 780, h: 560 },
    roblox: { title: 'Roblox', w: 780, h: 520 },
    phone: { title: 'Phone Simulator', w: 420, h: 780, url: PHONE_URL },
  };

  // Register every catalog game as an openable window app
  GAME_CATALOG.forEach((g) => {
    APPS[g.id] = {
      title: g.title,
      w: g.w || 900,
      h: g.h || 600,
      url: gameUrl(g.folder),
      game: true,
    };
  });

  const LOCAL_GAMES = [
    {
      id: 'phone',
      title: 'Phone Simulator',
      desc: 'iPhone-style shell · Messages presets',
      thumb: '📱',
      tone: 'linear-gradient(135deg,#22d3ee,#6c9eff)',
      status: 'play',
    },
    ...GAME_CATALOG.map((g) => ({
      id: g.id,
      title: g.title,
      desc: g.desc,
      thumb: g.thumb,
      tone: g.tone,
      status: 'play',
    })),
  ];

  function isCompact() {
    if (compactForced !== null) return compactForced;
    return window.innerWidth < 720 || window.innerHeight < 520;
  }

  function applyCompactClass() {
    const on = isCompact();
    document.body.classList.toggle('compact', on);
    const btn = document.getElementById('btn-compact');
    if (btn) btn.classList.toggle('active-toggle', on);
  }

  function toggleCompact() {
    compactForced = !isCompact();
    applyCompactClass();
    toast(compactForced ? 'Compact mode on' : 'Compact mode off');
  }

  function toast(msg, ms) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), ms || 2000);
  }

  function updateClock() {
    const d = new Date();
    const opts = { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' };
    clockEl.textContent = d.toLocaleString(undefined, opts).replace(',', '');
  }
  setInterval(updateClock, 15000);
  updateClock();
  applyCompactClass();
  window.addEventListener('resize', applyCompactClass);

  // Boot
  (function bootSeq() {
    let p = 0;
    const t = setInterval(() => {
      p += 4 + Math.random() * 8;
      if (p >= 100) {
        p = 100;
        clearInterval(t);
        bootFill.style.width = '100%';
        setTimeout(() => {
          boot.classList.add('fade');
          desktop.classList.remove('hidden');
          setTimeout(() => boot.remove(), 600);
          openApp('games');
          toast('Welcome — Games library');
        }, 350);
      } else {
        bootFill.style.width = p + '%';
      }
    }, 80);
  })();

  function setFocused(id) {
    focusedId = id;
    openWins.forEach((el, wid) => {
      el.classList.toggle('focused', wid === id);
      if (wid === id) {
        el.style.zIndex = String(++zTop);
        const app = el.dataset.app;
        menuApp.textContent = APPS[app]?.title || 'Finder';
      }
    });
    document.querySelectorAll('.dock-item').forEach((b) => {
      b.classList.toggle('open', openWins.has(b.dataset.app));
    });
  }

  function closeWin(id) {
    const el = openWins.get(id);
    if (!el) return;
    el.remove();
    openWins.delete(id);
    if (focusedId === id) {
      const last = [...openWins.keys()].pop();
      if (last) setFocused(last);
      else menuApp.textContent = 'Finder';
    }
    document.querySelectorAll('.dock-item').forEach((b) => {
      b.classList.toggle('open', openWins.has(b.dataset.app));
    });
  }

  function minimizeWin(id) {
    const el = openWins.get(id);
    if (!el) return;
    el.classList.add('minimized');
    toast('Minimized (tap Dock to restore)');
  }

  function restoreWin(app) {
    for (const [id, el] of openWins) {
      if (el.dataset.app === app) {
        el.classList.remove('minimized');
        setFocused(id);
        return true;
      }
    }
    return false;
  }

  function openApp(app) {
    // Finder always means "Games folder" experience for public arcade
    if (app === 'recents') app = 'finder';
    if (!APPS[app]) return;
    // If Finder already open, re-show Games folder (don't restore a stale sidebar)
    if (app === 'finder') {
      for (const [, win] of openWins) {
        if (win.dataset.app === 'finder' && !win.classList.contains('minimized')) {
          setFocused(win.dataset.id);
          fillFinder(win, 'games');
          return;
        }
      }
    }
    if (restoreWin(app)) return;

    const meta = APPS[app];
    const id = 'w' + ++winId;
    const el = document.createElement('div');
    el.className = 'window focused';
    el.dataset.id = id;
    el.dataset.app = app;

    const compact = isCompact();
    const left = compact ? 4 : 60 + (openWins.size % 5) * 28;
    const top = compact ? 4 : 36 + (openWins.size % 4) * 24;
    el.style.left = left + 'px';
    el.style.top = top + 'px';

    if (compact) {
      el.style.width = 'calc(100% - 8px)';
      el.style.height = 'calc(100% - 96px)';
      el.dataset.maxed = '1';
      el.dataset.ol = left + 'px';
      el.dataset.ot = top + 'px';
      el.dataset.ow = Math.min(meta.w, window.innerWidth - 16) + 'px';
      el.dataset.oh = Math.min(meta.h, window.innerHeight - 120) + 'px';
    } else {
      const maxW = Math.max(280, window.innerWidth - 24);
      const maxH = Math.max(180, window.innerHeight - 100);
      el.style.width = Math.min(meta.w, maxW) + 'px';
      el.style.height = Math.min(meta.h, maxH) + 'px';
    }
    el.style.zIndex = String(++zTop);

    el.innerHTML = `
      <div class="win-titlebar" data-drag>
        <div class="traffic">
          <button type="button" class="close" data-act="close" title="Close"></button>
          <button type="button" class="min" data-act="min" title="Minimize"></button>
          <button type="button" class="max" data-act="max" title="Zoom"></button>
        </div>
        <div class="win-title">${meta.title}</div>
      </div>
      <div class="win-body">${renderApp(app, meta)}</div>
      <div class="resize-handle n" data-resize="n"></div>
      <div class="resize-handle s" data-resize="s"></div>
      <div class="resize-handle e" data-resize="e"></div>
      <div class="resize-handle w" data-resize="w"></div>
      <div class="resize-handle se" data-resize="se"></div>
      <div class="resize-handle sw" data-resize="sw"></div>
      <div class="resize-handle ne" data-resize="ne"></div>
      <div class="resize-handle nw" data-resize="nw"></div>
    `;

    windowsEl.appendChild(el);
    openWins.set(id, el);
    setFocused(id);
    wireWindow(el, id, app);
    initAppLogic(el, app);
  }

  function wireWindow(el, id, app) {
    const MIN_W = 280;
    const MIN_H = 180;

    el.addEventListener('pointerdown', () => setFocused(id));

    el.querySelector('[data-act="close"]').addEventListener('click', (e) => {
      e.stopPropagation();
      closeWin(id);
    });
    el.querySelector('[data-act="min"]').addEventListener('click', (e) => {
      e.stopPropagation();
      minimizeWin(id);
    });
    el.querySelector('[data-act="max"]').addEventListener('click', (e) => {
      e.stopPropagation();
      if (el.dataset.maxed) {
        el.style.left = el.dataset.ol;
        el.style.top = el.dataset.ot;
        el.style.width = el.dataset.ow;
        el.style.height = el.dataset.oh;
        delete el.dataset.maxed;
      } else {
        el.dataset.ol = el.style.left;
        el.dataset.ot = el.style.top;
        el.dataset.ow = el.style.width;
        el.dataset.oh = el.style.height;
        el.dataset.maxed = '1';
        el.style.left = '8px';
        el.style.top = '8px';
        el.style.width = 'calc(100% - 16px)';
        el.style.height = 'calc(100% - 90px)';
      }
    });

    const bar = el.querySelector('[data-drag]');
    let drag = null;
    bar.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.traffic')) return;
      if (el.dataset.maxed) return;
      setFocused(id);
      drag = {
        ox: e.clientX - el.offsetLeft,
        oy: e.clientY - el.offsetTop,
      };
      bar.setPointerCapture(e.pointerId);
    });
    bar.addEventListener('pointermove', (e) => {
      if (!drag) return;
      el.style.left = Math.max(0, e.clientX - drag.ox) + 'px';
      el.style.top = Math.max(0, e.clientY - drag.oy) + 'px';
    });
    bar.addEventListener('pointerup', () => {
      drag = null;
    });

    el.querySelectorAll('[data-resize]').forEach((handle) => {
      handle.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (el.dataset.maxed) return;
        setFocused(id);
        const dir = handle.dataset.resize;
        const start = {
          x: e.clientX,
          y: e.clientY,
          l: el.offsetLeft,
          t: el.offsetTop,
          w: el.offsetWidth,
          h: el.offsetHeight,
        };
        el.classList.add('resizing');
        handle.setPointerCapture(e.pointerId);

        function onMove(ev) {
          const dx = ev.clientX - start.x;
          const dy = ev.clientY - start.y;
          let l = start.l;
          let t = start.t;
          let w = start.w;
          let h = start.h;

          if (dir.includes('e')) w = start.w + dx;
          if (dir.includes('s')) h = start.h + dy;
          if (dir.includes('w')) {
            w = start.w - dx;
            l = start.l + dx;
          }
          if (dir.includes('n')) {
            h = start.h - dy;
            t = start.t + dy;
          }

          if (w < MIN_W) {
            if (dir.includes('w')) l = start.l + start.w - MIN_W;
            w = MIN_W;
          }
          if (h < MIN_H) {
            if (dir.includes('n')) t = start.t + start.h - MIN_H;
            h = MIN_H;
          }

          l = Math.max(-w + 80, l);
          t = Math.max(0, t);

          el.style.left = l + 'px';
          el.style.top = t + 'px';
          el.style.width = w + 'px';
          el.style.height = h + 'px';
        }
        function onUp() {
          el.classList.remove('resizing');
          handle.removeEventListener('pointermove', onMove);
          handle.removeEventListener('pointerup', onUp);
        }
        handle.addEventListener('pointermove', onMove);
        handle.addEventListener('pointerup', onUp);
      });
    });
  }

  function renderApp(app, meta) {
    if (meta && meta.soon) {
      return `
        <div class="coming-soon">
          <div class="soon-emoji">🚧</div>
          <h3>${meta.title}</h3>
          <p>Coming soon to the public arcade pack.</p>
          <p class="dim">This title is not shipped here yet — no localhost server needed.</p>
        </div>`;
    }

    if (meta && meta.url) {
      const src = meta.url;
      return `
        <div class="game-frame-wrap">
          <div class="game-frame-bar">
            <span>🎮 ${meta.title}</span>
            <span class="dim frame-hint">Playing inside this window · drag edges to resize</span>
            <button type="button" class="frame-reload" data-reload-frame title="Reload game">↻</button>
            <a class="frame-pop" href="${src}" target="_blank" rel="noopener">Open tab ↗</a>
          </div>
          <iframe
            class="game-frame"
            src="${src}"
            title="${meta.title}"
            allow="gamepad; fullscreen; autoplay; pointer-lock"
            allowfullscreen
            loading="eager"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>`;
    }

    switch (app) {
      case 'finder':
      case 'trash':
        return `
          <div class="finder-body" data-finder-default="games">
            <div class="finder-side">
              <button type="button" class="active" data-f="games">􀛹 Games</button>
              <button type="button" data-f="apps">􀎭 Applications</button>
              <button type="button" data-f="desk">􀈂 Desktop</button>
              <button type="button" data-f="docs">􀈷 Documents</button>
              <button type="button" data-f="down">􀈄 Downloads</button>
            </div>
            <div class="finder-main">
              <h3 id="f-title">${app === 'trash' ? 'Trash' : 'Games'}</h3>
              <p class="finder-hint" id="f-hint">Click a game to open it in a window</p>
              <div class="file-grid" id="f-grid"></div>
            </div>
          </div>`;
      case 'games':
        return `
          <div class="games-library">
            <h3>Games</h3>
            <p class="games-library-lead">Kid-made arcade · opens <b>inside</b> a Mac window. ${GAME_CATALOG.length} titles ready — click to play.</p>
            <div class="game-grid" id="games-grid"></div>
          </div>`;
      case 'roblox':
        return `
          <div class="roblox-body">
            <div class="roblox-top">
              <div class="logo">R</div>
              <input type="text" value="Arcade catalog (fan sim)" readonly />
            </div>
            <div class="roblox-hero">
              <div class="banner">
                <h3>BLOXY Classic</h3>
                <p>2008-style build &amp; play</p>
                <button type="button" class="play-btn" data-play="bloxy">Play</button>
              </div>
              <div class="banner" style="background:radial-gradient(circle at 70% 30%,#c8844088,transparent 50%),linear-gradient(135deg,#2a2040,#1a1028)">
                <h3>I Am Bird</h3>
                <p>Plaza chaos · stars not gore</p>
                <button type="button" class="play-btn" data-play="bird">Play</button>
              </div>
            </div>
            <div class="roblox-list">
              <h4>All games · open in-window</h4>
              <div class="roblox-row" id="roblox-row"></div>
            </div>
            <p style="padding:0 20px 16px;font-size:11px;color:#666">Fan simulator · not affiliated with Roblox Corporation</p>
          </div>`;
      case 'safari':
        return `
          <div class="safari-bar">
            <input type="text" value="https://kid-arcade.local/mac-sim" readonly />
          </div>
          <div class="safari-page">
            <h2>Mac Simulator</h2>
            <p>macOS-inspired desktop. Open apps from the Dock, <b>drag edges to resize</b>, try Spotlight.</p>
            <p>Games open Bird &amp; Monkey from this pack. Messages uses offline chat presets (no server).</p>
            <p style="color:#5ac8fa">Dock · Compact mode · Messages · Games</p>
            <p style="margin-top:12px;font-size:12px;color:#888">Kid-made with Grok Build · family co-design · public-safe fork</p>
          </div>`;
      case 'notes':
        return `
          <div class="notes-body">
            <div class="notes-list">
              <button type="button" class="active" data-note="0">Shopping<span class="meta">Today</span></button>
              <button type="button" data-note="1">Ideas<span class="meta">Yesterday</span></button>
              <button type="button" data-note="2">Todo<span class="meta">Mon</span></button>
            </div>
            <div class="notes-edit">
              <textarea id="note-area">• milk
• coffee beans
• pixel pet snacks
• more desk chonks?</textarea>
            </div>
          </div>`;
      case 'calc':
        return `
          <div class="calc-body">
            <div class="calc-display" id="calc-out">0</div>
            <button type="button" class="fn" data-c="C">C</button>
            <button type="button" class="fn" data-c="±">±</button>
            <button type="button" class="fn" data-c="%">%</button>
            <button type="button" class="op" data-c="/">÷</button>
            <button type="button" data-c="7">7</button>
            <button type="button" data-c="8">8</button>
            <button type="button" data-c="9">9</button>
            <button type="button" class="op" data-c="*">×</button>
            <button type="button" data-c="4">4</button>
            <button type="button" data-c="5">5</button>
            <button type="button" data-c="6">6</button>
            <button type="button" class="op" data-c="-">−</button>
            <button type="button" data-c="1">1</button>
            <button type="button" data-c="2">2</button>
            <button type="button" data-c="3">3</button>
            <button type="button" class="op" data-c="+">+</button>
            <button type="button" class="zero" data-c="0">0</button>
            <button type="button" data-c=".">.</button>
            <button type="button" class="op" data-c="=">=</button>
          </div>`;
      case 'terminal':
        return `
          <div class="term-body">
            <div class="line dim">Last login: ${new Date().toDateString()} on console</div>
            <div class="line">arkhe@mac-sim ~ % <span class="dim">welcome to Mac Simulator shell (public)</span></div>
            <div id="term-log"></div>
            <div class="term-input-row">
              <span>arkhe@mac-sim ~ %</span>
              <input id="term-in" type="text" autocomplete="off" spellcheck="false" />
            </div>
          </div>`;
      case 'settings':
        return `
          <div class="settings-body">
            <div class="settings-nav">
              <button type="button" class="active">General</button>
              <button type="button">Appearance</button>
              <button type="button">Desktop</button>
              <button type="button">Sound</button>
              <button type="button">Privacy</button>
            </div>
            <div class="settings-main">
              <h3>General</h3>
              <label>Dark Mode <input type="checkbox" checked disabled /></label>
              <label>Wallpaper vibe
                <input type="range" id="wall-vibe" min="0" max="100" value="55" />
              </label>
              <label>Compact mode <input type="checkbox" id="set-compact" /></label>
              <label>Reduce motion <input type="checkbox" /></label>
              <p style="margin-top:16px;color:#888;font-size:12px">Settings are simulated for fun. Chat = offline presets.</p>
            </div>
          </div>`;
      case 'about':
        return `
          <div class="about-body">
            <div class="apple-big"></div>
            <h2>Mac Simulator</h2>
            <p>macOS-inspired desktop toy</p>
            <p>Version 1.0 · Public Kid Arcade</p>
            <p style="margin-top:16px">Chip: Browser GPU<br/>Memory: Your RAM<br/>Serial: FAKE-NOT-APPLE</p>
            <p style="margin-top:12px;font-size:11px">Kid-made with Grok Build · family co-design</p>
            <p style="margin-top:8px;font-size:11px">Not affiliated with Apple Inc.</p>
          </div>`;
      case 'messages':
        return `
          <div class="imessage">
            <aside class="im-sidebar">
              <div class="im-side-head">Messages</div>
              <button type="button" class="im-contact active" data-contact="kinito">
                <span class="av kinito"></span>
                <span class="meta"><b>Kinito</b><i class="preview">Hello! I am Kinito!</i></span>
              </button>
              <button type="button" class="im-contact" data-contact="chonks">
                <span class="av chonks"></span>
                <span class="meta"><b>Desk Chonks</b><i class="preview">squeak · chonk · vibes</i></span>
              </button>
              <button type="button" class="im-contact" data-contact="bossbot">
                <span class="av boss"></span>
                <span class="meta"><b>BossBot-9000</b><i class="preview">Clock in. Be obsolete.</i></span>
              </button>
              <button type="button" class="im-contact" data-contact="siri">
                <span class="av siri"></span>
                <span class="meta"><b>Assistant</b><i class="preview">How can I help?</i></span>
              </button>
              <div class="im-status">preset chat…</div>
            </aside>
            <section class="im-thread">
              <div class="im-thread-head im-head">Kinito</div>
              <div class="im-log"></div>
              <form class="im-compose" action="javascript:void(0)">
                <input class="im-input" type="text" maxlength="400" placeholder="iMessage" autocomplete="off" enterkeyhint="send" />
                <button type="submit" class="im-send" title="Send" aria-label="Send">↑</button>
              </form>
            </section>
          </div>`;
      case 'mail':
        return `
          <div class="mail-body">
            <p style="color:#888;margin-bottom:12px">Inbox · 3 messages</p>
            <div class="msg-row"><div><b>Welcome to Mac Simulator</b><br/><span style="color:#aaa">Your desktop is ready…</span></div></div>
            <div class="msg-row"><div><b>Job Corp™</b><br/><span style="color:#aaa">Your shift report is ready</span></div></div>
            <div class="msg-row"><div><b>Apple (not really)</b><br/><span style="color:#aaa">This is a fan simulation</span></div></div>
          </div>`;
      case 'maps':
        return `
          <div class="maps-body" style="background:linear-gradient(135deg,#1a3a2a,#1a2a40);min-height:280px;display:grid;place-items:center">
            <div style="text-align:center">
              <div style="font-size:40px;margin-bottom:8px">🗺️</div>
              <p>Cupertino-ish · simulated map</p>
              <p style="color:#888;font-size:12px;margin-top:6px">You're here: Mac Simulator</p>
            </div>
          </div>`;
      case 'photos':
        return `
          <div class="photos-body">
            <div class="photos-grid">
              <div style="background:linear-gradient(135deg,#ff6bcb,#5b8cff)"></div>
              <div style="background:linear-gradient(135deg,#30d158,#64d2ff)"></div>
              <div style="background:linear-gradient(135deg,#ffd60a,#ff9f0a)"></div>
              <div style="background:linear-gradient(135deg,#bf5af2,#ff375f)"></div>
              <div style="background:linear-gradient(135deg,#5ac8fa,#007aff)"></div>
              <div style="background:linear-gradient(135deg,#a2845e,#636366)"></div>
            </div>
          </div>`;
      default:
        return `<div style="padding:24px">App not found.</div>`;
    }
  }

  /** Finder sidebar content — items with `open` launch real apps/games */
  function finderItemsFor(key) {
    if (key === 'games') {
      return LOCAL_GAMES.map((g) => ({
        n: g.title,
        c: g.tone,
        open: g.id,
        thumb: g.thumb,
        sub: g.desc,
      }));
    }
    if (key === 'apps') {
      return [
        { n: 'Games', c: 'linear-gradient(145deg,#bf5af2,#0a84ff)', open: 'games', thumb: '🕹️' },
        { n: 'Messages', c: 'linear-gradient(145deg,#30d158,#1a9a3a)', open: 'messages', thumb: '💬' },
        { n: 'Safari', c: 'linear-gradient(145deg,#64d2ff,#0a84ff)', open: 'safari', thumb: '🧭' },
        { n: 'Phone Simulator', c: 'linear-gradient(145deg,#22d3ee,#6c9eff)', open: 'phone', thumb: '📱' },
        { n: 'Notes', c: 'linear-gradient(145deg,#ffd60a,#ff9f0a)', open: 'notes', thumb: '📝' },
        { n: 'Calculator', c: 'linear-gradient(145deg,#636366,#48484a)', open: 'calc', thumb: '🔢' },
        { n: 'Terminal', c: 'linear-gradient(145deg,#1c1c1e,#000)', open: 'terminal', thumb: '⬛' },
        { n: 'System Settings', c: 'linear-gradient(145deg,#8e8e93,#636366)', open: 'settings', thumb: '⚙️' },
      ];
    }
    // "recents" removed — always treat as games so nothing can fall back to a dead Recents view
    if (key === 'recents') {
      return finderItemsFor('games');
    }
    if (key === 'desk') {
      return [
        { n: 'Games', c: 'linear-gradient(145deg,#bf5af2,#5e5ce6)', open: 'games', thumb: '🕹️' },
        { n: 'Messages', c: 'linear-gradient(145deg,#30d158,#1a9a3a)', open: 'messages', thumb: '💬' },
        { n: 'Phone Simulator', c: 'linear-gradient(145deg,#22d3ee,#6c9eff)', open: 'phone', thumb: '📱' },
      ];
    }
    if (key === 'docs') {
      return [
        { n: 'How to play.txt', c: 'linear-gradient(145deg,#30d158,#248a3d)', open: 'games', thumb: '📄', sub: 'Opens Games library' },
        { n: 'Arcade ideas', c: 'linear-gradient(145deg,#ffd60a,#ff9f0a)', open: 'notes', thumb: '💡' },
      ];
    }
    if (key === 'down') {
      return [
        { n: 'Open Games library', c: 'linear-gradient(145deg,#bf5af2,#5e5ce6)', open: 'games', thumb: '⬇️' },
      ];
    }
    if (key === 'trash') {
      return [{ n: 'Empty', c: 'linear-gradient(145deg,#8e8e93,#636366)', thumb: '🗑️', sub: 'Nothing useful here' }];
    }
    return finderItemsFor('games');
  }

  const NOTES = [
    '• milk\n• coffee beans\n• pixel pet snacks\n• more desk chonks?',
    'Game jam ideas:\n- mac simulator ✓\n- bird + monkey public ✓\n- more presets',
    '- [x] Wake up\n- [ ] Ship something\n- [ ] Sleep',
  ];

  function fillFinder(el, key) {
    const grid = el.querySelector('#f-grid');
    const title = el.querySelector('#f-title');
    const hint = el.querySelector('#f-hint');
    if (!grid) return;
    const names = {
      recents: 'Games', // legacy alias — never show Recents
      apps: 'Applications',
      games: 'Games',
      desk: 'Desktop',
      docs: 'Documents',
      down: 'Downloads',
      trash: 'Trash',
    };
    // Never allow Recents as a real folder
    let k = key || 'games';
    if (k === 'recents') k = 'games';
    if (title) title.textContent = names[k] || k;
    if (hint) {
      hint.textContent =
        k === 'trash'
          ? 'Nothing to open here'
          : k === 'games'
            ? 'Click a game — it opens in a window'
            : 'Click an item to open it';
    }

    // Sidebar active state
    el.querySelectorAll('.finder-side button').forEach((b) => {
      b.classList.toggle('active', b.dataset.f === k);
    });

    const files = finderItemsFor(k);
    grid.innerHTML = files
      .map((f, i) => {
        const openable = !!f.open;
        return `
        <button type="button" class="file-item${openable ? ' openable' : ''}" data-idx="${i}" ${
          openable ? `data-open="${f.open}"` : 'disabled'
        } title="${openable ? 'Open ' + f.n : f.n}">
          <div class="fi" style="background:${f.c}">${f.thumb || ''}</div>
          <span class="file-name">${f.n}</span>
          ${f.sub ? `<span class="file-sub">${f.sub}</span>` : ''}
        </button>`;
      })
      .join('');

    grid.querySelectorAll('[data-open]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const id = btn.dataset.open;
        if (id && APPS[id]) openApp(id);
        else if (id === 'games') openApp('games');
        else toast('Can’t open that');
      });
    });
  }

  function fillGamesGrid(el) {
    const grid = el.querySelector('#games-grid');
    if (!grid) return;
    grid.innerHTML = LOCAL_GAMES.map((g) => {
      return `
      <button type="button" class="game-card" data-play="${g.id}">
        <div class="thumb" style="background:${g.tone}">${g.thumb}</div>
        <h4>${g.title}</h4>
        <p>${g.desc}</p>
      </button>`;
    }).join('');
    grid.querySelectorAll('[data-play]').forEach((btn) => {
      btn.addEventListener('click', () => openApp(btn.dataset.play));
    });
  }

  function fillRobloxRow(el) {
    const row = el.querySelector('#roblox-row');
    if (!row) return;
    const picks = LOCAL_GAMES.filter((g) => g.id !== 'roblox' && g.id !== 'phone');
    row.innerHTML = picks
      .map(
        (g) => `
      <button type="button" class="game-card" data-play="${g.id}">
        <div class="thumb" style="background:${g.tone}">${g.thumb}</div>
        <h4>${g.title}</h4>
        <p>${g.desc}</p>
      </button>`
      )
      .join('');
    el.querySelectorAll('[data-play]').forEach((btn) => {
      btn.addEventListener('click', () => openApp(btn.dataset.play));
    });
  }

  const MSG_CONTACTS = {
    kinito: {
      name: 'Kinito',
      seed: [{ role: 'assistant', content: 'Hello! I am Kinito!' }],
    },
    chonks: {
      name: 'Desk Chonks',
      seed: [{ role: 'assistant', content: 'squeak · chonk · vibes · we live on your desk!' }],
    },
    bossbot: {
      name: 'BossBot-9000',
      seed: [{ role: 'assistant', content: 'Employee detected. State your productivity metrics.' }],
    },
    siri: {
      name: 'Assistant',
      seed: [{ role: 'assistant', content: 'Hi — I can help with short answers. What do you need?' }],
    },
  };

  function initMessages(el) {
    const root = el.querySelector('.imessage') || el;
    const log = root.querySelector('.im-log');
    const input = root.querySelector('.im-input');
    const sendBtn = root.querySelector('.im-send');
    const head = root.querySelector('.im-head');
    const status = root.querySelector('.im-status');
    if (!log || !input || !sendBtn) {
      console.warn('[messages] missing chat DOM');
      return;
    }

    const histories = {};
    let contact = 'kinito';
    let busy = false;

    Object.keys(MSG_CONTACTS).forEach((id) => {
      histories[id] = MSG_CONTACTS[id].seed.map((m) => ({ ...m }));
    });

    function esc(s) {
      return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    }

    function setBusy(on) {
      busy = on;
      input.disabled = on;
      sendBtn.disabled = on;
      sendBtn.setAttribute('aria-busy', on ? 'true' : 'false');
    }

    function setStatusLine(model, ok) {
      if (!status) return;
      if (ok === false) {
        status.textContent = '○ chat unavailable';
        status.style.color = '#ff453a';
        return;
      }
      const id = model || 'preset:' + contact;
      status.textContent = '● ' + id;
      status.style.color = '#30d158';
    }

    function renderThread() {
      const h = histories[contact] || [];
      log.innerHTML = h
        .map((m) => {
          const mine = m.role === 'user';
          return `<div class="bubble-row ${mine ? 'me' : 'them'}"><div class="bubble">${esc(m.content)}</div></div>`;
        })
        .join('');
      log.scrollTop = log.scrollHeight;
      root.querySelectorAll('.im-contact').forEach((btn) => {
        const id = btn.dataset.contact;
        const last = (histories[id] || []).slice(-1)[0];
        const prev = btn.querySelector('.preview');
        if (prev && last) {
          prev.textContent =
            last.content.slice(0, 42) + (last.content.length > 42 ? '…' : '');
        }
      });
    }

    function selectContact(id) {
      if (!MSG_CONTACTS[id] || busy) return;
      contact = id;
      if (head) head.textContent = MSG_CONTACTS[id].name || id;
      root.querySelectorAll('.im-contact').forEach((b) => {
        b.classList.toggle('active', b.dataset.contact === id);
      });
      renderThread();
      setStatusLine('preset:' + contact, true);
      input.focus();
    }

    function refreshStatus() {
      if (window.KidArcadeChat) {
        setStatusLine('preset:' + contact, true);
      } else {
        setStatusLine(null, false);
        if (status) {
          status.textContent = '○ presets missing · check shared/chat-presets.js';
          status.style.color = '#ff9f0a';
        }
      }
    }

    async function send() {
      const text = (input.value || '').trim();
      if (!text || busy) return;
      setBusy(true);
      input.value = '';
      const threadContact = contact;
      histories[threadContact].push({ role: 'user', content: text });
      renderThread();

      const typing = document.createElement('div');
      typing.className = 'bubble-row them';
      typing.innerHTML = '<div class="bubble typing">…</div>';
      log.appendChild(typing);
      log.scrollTop = log.scrollHeight;

      try {
        if (!window.KidArcadeChat || typeof window.KidArcadeChat.chat !== 'function') {
          throw new Error('KidArcadeChat not loaded');
        }
        const hist = histories[threadContact]
          .slice(0, -1)
          .filter((m) => m.role === 'user' || m.role === 'assistant')
          .slice(-10);
        const d = await window.KidArcadeChat.chat({
          persona: threadContact,
          message: text,
          history: hist,
        });
        typing.remove();
        if (!d || !d.ok) {
          throw new Error((d && (d.error || d.hint)) || 'chat failed');
        }
        const reply = (d.reply || '').trim() || '…';
        histories[threadContact].push({ role: 'assistant', content: reply });
        if (histories[threadContact].length > 24) {
          histories[threadContact] = histories[threadContact].slice(-24);
        }
        if (contact === threadContact) renderThread();
        setStatusLine(d.model || 'preset:' + threadContact, true);
      } catch (e) {
        typing.remove();
        histories[threadContact].push({
          role: 'assistant',
          content:
            '… (chat error) ' +
            String(e.message || e) +
            ' — presets load from ../../shared/chat-presets/ (serve pack root, not file://)',
        });
        if (contact === threadContact) renderThread();
        if (status) {
          status.textContent = '○ chat error';
          status.style.color = '#ff453a';
        }
      }
      setBusy(false);
      input.focus();
    }

    root.querySelectorAll('.im-contact').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        selectContact(btn.dataset.contact);
      });
    });
    const form = root.querySelector('.im-compose');
    form?.addEventListener('submit', (e) => {
      e.preventDefault();
      e.stopPropagation();
      send();
    });
    sendBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      send();
    });
    input.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    });
    input.addEventListener('keyup', (e) => e.stopPropagation());
    input.addEventListener('keypress', (e) => e.stopPropagation());
    form?.addEventListener('mousedown', (e) => e.stopPropagation());

    selectContact('kinito');
    refreshStatus();
    setTimeout(() => input.focus(), 120);
  }

  function initAppLogic(el, app) {
    // In-window game iframe: reload button
    const frame = el.querySelector('iframe.game-frame');
    const reloadBtn = el.querySelector('[data-reload-frame]');
    if (frame && reloadBtn) {
      reloadBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        try {
          frame.src = frame.src;
        } catch (_) {
          /* ignore */
        }
      });
    }

    if (app === 'messages') {
      initMessages(el);
    }
    if (app === 'finder' || app === 'trash') {
      // Always land on Games (never Recents)
      const startKey = app === 'trash' ? 'trash' : 'games';
      fillFinder(el, startKey);
      el.querySelectorAll('.finder-side button').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          let key = btn.dataset.f || 'games';
          if (key === 'recents') key = 'games';
          el.querySelectorAll('.finder-side button').forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
          fillFinder(el, key);
        });
      });
    }

    if (app === 'games') fillGamesGrid(el);
    if (app === 'roblox') fillRobloxRow(el);

    if (app === 'notes') {
      const area = el.querySelector('#note-area');
      el.querySelectorAll('[data-note]').forEach((btn) => {
        btn.addEventListener('click', () => {
          el.querySelectorAll('[data-note]').forEach((b) => b.classList.remove('active'));
          btn.classList.add('active');
          if (area) area.value = NOTES[+btn.dataset.note] || '';
        });
      });
    }

    if (app === 'calc') {
      let expr = '';
      const out = el.querySelector('#calc-out');
      el.querySelectorAll('[data-c]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const c = btn.dataset.c;
          if (c === 'C') expr = '';
          else if (c === '=') {
            try {
              // eslint-disable-next-line no-new-func
              const v = Function('"use strict";return (' + expr.replace(/[^0-9+\-*/().% ]/g, '') + ')')();
              expr = String(v);
            } catch {
              expr = 'Error';
            }
          } else if (c === '±') {
            if (expr) expr = String(-parseFloat(expr) || expr);
          } else {
            if (expr === 'Error') expr = '';
            expr += c;
          }
          out.textContent = expr || '0';
        });
      });
    }

    if (app === 'terminal') {
      const log = el.querySelector('#term-log');
      const input = el.querySelector('#term-in');
      const print = (t, dim) => {
        const d = document.createElement('div');
        d.className = 'line' + (dim ? ' dim' : '');
        d.textContent = t;
        log.appendChild(d);
        log.parentElement.scrollTop = log.parentElement.scrollHeight;
      };
      input?.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter') return;
        const cmd = input.value.trim();
        print('arkhe@mac-sim ~ % ' + cmd);
        input.value = '';
        const c = cmd.toLowerCase();
        if (c === 'help') print('cmds: help, clear, date, whoami, open <app>, neofetch, cowsay');
        else if (c === 'clear') log.innerHTML = '';
        else if (c === 'date') print(new Date().toString());
        else if (c === 'whoami') print('arkhe');
        else if (c === 'neofetch') {
          print('arkhe@mac-sim');
          print('OS: Mac Simulator 1.0 (public)');
          print('Host: Browser / GitHub Pages');
          print('Shell: js-sh');
          print('Chat: KidArcadeChat presets');
          print('Pet: Kinito + Desk Chonks');
        } else if (c.startsWith('open ')) {
          const name = c.slice(5).trim();
          const map = {
            finder: 'finder',
            safari: 'safari',
            notes: 'notes',
            calc: 'calc',
            calculator: 'calc',
            terminal: 'terminal',
            settings: 'settings',
            games: 'games',
            roblox: 'roblox',
            messages: 'messages',
            bird: 'bird',
            monkey: 'monkey',
            phone: 'phone',
            bloxy: 'bloxy',
          };
          if (map[name]) {
            openApp(map[name]);
            print('opened ' + name);
          } else print('app not found: ' + name, true);
        } else if (c === 'cowsay' || c.startsWith('cowsay ')) {
          print(' ________');
          print('< moo OS >');
          print(' --------');
          print('        \\   ^__^');
          print('         \\  (oo)\\_______');
          print('            (__)\\       )\\/\\');
          print('                ||----w |');
        } else if (c === '') {
          /* empty */
        } else print('command not found: ' + cmd, true);
      });
      setTimeout(() => input?.focus(), 100);
    }

    if (app === 'settings') {
      const range = el.querySelector('#wall-vibe');
      range?.addEventListener('input', () => {
        const v = +range.value;
        desktop.style.filter = `hue-rotate(${(v - 55) * 2}deg) saturate(${0.8 + v / 100})`;
      });
      const cb = el.querySelector('#set-compact');
      if (cb) {
        cb.checked = isCompact();
        cb.addEventListener('change', () => {
          compactForced = cb.checked;
          applyCompactClass();
          toast(cb.checked ? 'Compact mode on' : 'Compact mode off');
        });
      }
    }
  }

  // Dock + desktop icons
  document.querySelectorAll('[data-app]').forEach((btn) => {
    btn.addEventListener('click', () => openApp(btn.dataset.app));
  });

  document.getElementById('btn-compact')?.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleCompact();
  });

  // Apple menu
  document.getElementById('btn-apple').addEventListener('click', (e) => {
    e.stopPropagation();
    appleMenu.classList.toggle('hidden');
  });
  appleMenu.querySelectorAll('[data-act]').forEach((btn) => {
    btn.addEventListener('click', () => {
      appleMenu.classList.add('hidden');
      const a = btn.dataset.act;
      if (a === 'about') openApp('about');
      else if (a === 'settings') openApp('settings');
      else if (a === 'compact') toggleCompact();
      else if (a === 'sleep') {
        desktop.style.filter = 'brightness(0.15)';
        toast('Sleeping… click to wake');
        const wake = () => {
          desktop.style.filter = '';
          document.removeEventListener('click', wake);
        };
        setTimeout(() => document.addEventListener('click', wake), 300);
      } else if (a === 'restart') {
        toast('Restarting…');
        setTimeout(() => location.reload(), 800);
      } else if (a === 'shutdown') {
        desktop.classList.add('hidden');
        document.body.style.background = '#000';
        toast("It's now safe to close this tab");
      }
    });
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#btn-apple') && !e.target.closest('#apple-menu')) {
      appleMenu.classList.add('hidden');
    }
  });

  // Spotlight
  const SPOT = [
    { app: 'finder', label: 'Finder', ico: 'finder' },
    { app: 'safari', label: 'Safari', ico: 'safari' },
    { app: 'games', label: 'Games', ico: 'games' },
    { app: 'roblox', label: 'Roblox', ico: 'roblox' },
    { app: 'bird', label: 'I Am Bird', ico: 'games' },
    { app: 'monkey', label: 'I Am Monkey', ico: 'games' },
    { app: 'phone', label: 'Phone Simulator', ico: 'games' },
    { app: 'notes', label: 'Notes', ico: 'notes' },
    { app: 'calc', label: 'Calculator', ico: 'calc' },
    { app: 'terminal', label: 'Terminal', ico: 'terminal' },
    { app: 'settings', label: 'System Settings', ico: 'settings' },
    { app: 'messages', label: 'Messages', ico: 'messages' },
    { app: 'mail', label: 'Mail', ico: 'mail' },
    { app: 'photos', label: 'Photos', ico: 'photos' },
    { app: 'maps', label: 'Maps', ico: 'maps' },
    { app: 'about', label: 'About This Mac', ico: 'about' },
  ];

  function openSpotlight() {
    spotlight.classList.remove('hidden');
    spotInput.value = '';
    renderSpot('');
    setTimeout(() => spotInput.focus(), 50);
  }
  function closeSpotlight() {
    spotlight.classList.add('hidden');
  }
  function renderSpot(q) {
    const qq = q.toLowerCase().trim();
    const list = SPOT.filter((s) => !qq || s.label.toLowerCase().includes(qq));
    spotResults.innerHTML = list
      .map(
        (s, i) =>
          `<button type="button" data-app="${s.app}" class="${i === 0 ? 'active' : ''}"><div class="si ico ${s.ico}"></div>${s.label}</button>`
      )
      .join('');
    spotResults.querySelectorAll('button').forEach((b) => {
      b.addEventListener('click', () => {
        openApp(b.dataset.app);
        closeSpotlight();
      });
    });
  }
  document.getElementById('btn-spotlight').addEventListener('click', openSpotlight);
  spotInput.addEventListener('input', () => renderSpot(spotInput.value));
  spotInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeSpotlight();
    if (e.key === 'Enter') {
      const first = spotResults.querySelector('button');
      if (first) {
        openApp(first.dataset.app);
        closeSpotlight();
      }
    }
  });
  spotlight.addEventListener('click', (e) => {
    if (e.target === spotlight) closeSpotlight();
  });

  window.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.code === 'Space') {
      e.preventDefault();
      if (spotlight.classList.contains('hidden')) openSpotlight();
      else closeSpotlight();
    }
    if (e.key === 'Escape') {
      closeSpotlight();
      appleMenu.classList.add('hidden');
    }
  });
})();
