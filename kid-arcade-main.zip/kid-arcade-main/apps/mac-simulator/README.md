# Mac Simulator (public)

Browser **macOS-inspired** desktop for the Public Kid Arcade pack.  
Boot, Dock, windows, Spotlight, **Games** (iframe → sibling apps), and **Messages** via offline presets.

Not affiliated with Apple.

**Fork of** canon `projects/creative-visualizers-and-games/mac-simulator/` — public-safe, static only.  
**Credits:** Kid-made with Grok Build · family co-design. No children’s real names.

## Play (GitHub Pages / static)

No Python, no Ollama required.

1. Serve the **pack root** (so sibling apps resolve):

```bash
cd projects/public-kid-arcade
python3 -m http.server 8800 --bind 127.0.0.1
```

2. Open **http://127.0.0.1:8800/apps/mac-simulator/**

Or open the [pack lobby](../../index.html) → **Mac Simulator**.

On GitHub Pages: `…/public-kid-arcade/apps/mac-simulator/` (path depends on repo/Pages base).

> Opening `index.html` as a `file://` URL may block fetch of chat presets; use any static server or Pages.

## Messages

Dock → **Messages**. Contacts use `shared/chat-presets.js` + persona JSON:

| Contact | Persona id |
|---------|------------|
| Kinito | `kinito` |
| Desk Chonks | `chonks` |
| BossBot-9000 | `bossbot` |
| Assistant | `siri` |

Status line shows `preset:<id>` (or `ollama:…` if optional local Ollama is configured).

## Games

Playable (relative, no localhost):

- **I Am Bird** → `../i-am-bird/index.html`
- **I Am Monkey** → `../i-am-monkey/index.html`
- **Phone Simulator** → `../phone-simulator/index.html` (if present in pack)

Other arcade cards show **Coming soon** (no dead localhost links).

## Touch / compact

- Coarse pointers get larger Dock / desk hit targets.
- Narrow screens auto-enable **compact mode** (or use menu bar **Compact** / Apple menu).
- Windows can still be dragged with pointer events and resized from edges.

## Optional Ollama (devs only)

```js
window.KID_ARCADE_OLLAMA_URL = 'http://127.0.0.1:11434';
window.KID_ARCADE_PREFER_OLLAMA = true; // required — URL alone is not enough
window.KID_ARCADE_OLLAMA_MODEL = 'gemma4-e2b:latest';
```

Default remains **presets** so strangers can play without your machine.

## Not used

Canon’s `serve.py` (Gemma `/api/chat`) is **not** part of this public fork. Static hosting only.
