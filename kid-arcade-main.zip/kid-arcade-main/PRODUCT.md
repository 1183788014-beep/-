# Public Kid Arcade — Product bar

Standing definition of what “public ready” means for this pack.  
Use before adding games, shipping Pages, or claiming an emulator is visitor-safe.

**Audience:** random people on phones, iPads, and laptops.  
**Credit:** the kids · family co-design · Grok Build  
**Not:** family workstation setup guides as the default path.

---

## Product principles

### 1. Pages-first

- The tree is **static**: HTML, CSS, JS, images, JSON.  
- **Relative links only** (`apps/...`, `shared/...`, `../...`). No `localhost`, no absolute machine paths, no hard-coded family ports as the only way in.  
- Root lobby is [`index.html`](./index.html).  
- [`.nojekyll`](./.nojekyll) present so GitHub Pages serves the tree as-is.  
- A visitor who opens the Pages URL can play **without** cloning or installing tooling.

### 2. Mobile + desktop controls

Every public app must be playable with:

| Context | Minimum bar |
|---------|-------------|
| Phone / iPad | Touch: tappable UI, readable type, no unusable hover-only controls |
| Desktop | Keyboard and/or mouse as appropriate to the genre |
| Layout | Viewport meta; HUD and buttons not permanently clipped at common widths |

Emulators may be “desktop-first” or “phone-first” in *chrome*, but must not be blank or broken on the other class of device.

### 3. No gore in public

- No blood particles, blood sprite sheets, or “real injury” juice in this pack.  
- Comedy substitutes only (stars, sparks, feathers, soft KOs, silly text).  
- Copy and HUD labels stay family-audience safe.  
- Local canon under `creative-visualizers-and-games/` may keep experimental juice — **do not** “fix public” by editing canon in place.

### 4. Chat always works without Ollama

- Default brain: [`shared/chat-presets.js`](./shared/chat-presets.js) + [`shared/chat-presets/*.json`](./shared/chat-presets/).  
- Opening Messages / in-game chat on Pages **must** produce kid-safe replies with zero network AI.  
- Optional local Ollama (`window.KID_ARCADE_OLLAMA_URL` / model override) is **advanced only**, documented as optional, never required.  
- If Ollama is configured and fails, **fall back to presets** — never leave the user on a dead spinner with no reply path.

### 5. Emulators host games via relative links

- Phone and Mac public shells launch games with paths like `../i-am-bird/` or lobby-relative URLs that work on Pages **and** `python3 -m http.server` from this folder.  
- Do not require `:8783` / `:8784` / other local canon ports for public play.  
- Deep-links that only work on the family LAN are canon-only.

### 6. Privacy hard rules

Never in this pack, its git history intended for public remotes, or Pages content:

- Children’s or family **real names**  
- Ages, school, home, location  
- Face photos or household-identifying media  
- Household contact details  
- Tokens, PATs, OAuth secrets, private URLs  

Public credit language only: **the kids**, **family co-design**, **kid-led**, **Grok Build**.

---

## Lobby expectations

[`index.html`](./index.html) must keep clear sections:

1. **Emulators** — Phone, Mac (graceful if a folder is still landing)  
2. **Games** — playable public forks + honest “more coming”  
3. **About** — what/who, privacy one-liner, chat offline note, public vs canon  

Cards use relative `href`s and state **Play** vs roadmap clearly.

---

## Definition of Done — new public game

A game may be listed as **Play** on the lobby when **all** of the following are true:

| # | Gate |
|---|------|
| 1 | **Fork, not in-place edit** — lives under `apps/<slug>/`; canon path recorded in [`ORIGIN.md`](./ORIGIN.md) |
| 2 | **Static** — runs from this pack’s document root on Pages / `http.server` with no custom backend |
| 3 | **Relative assets** — no broken absolute or localhost-only asset URLs |
| 4 | **No gore** — blood / injury juice removed or replaced with comedy VFX |
| 5 | **Chat (if any)** — uses shared presets; works offline; Ollama optional only |
| 6 | **Controls** — touch **and** desktop path documented or obvious in-UI; viewport OK on phone |
| 7 | **Privacy** — no real names, ages, location, faces, tokens in files or commit messages destined for public |
| 8 | **Lobby card** — title, one-line pitch, badges, relative link under **Games** |
| 9 | **App README** — public-safe; points at canon path; how to run from pack root |
| 10 | **Smoke check** — open lobby → card → first interactive frame without console-fatal missing files |

Optional but preferred:

- Same game reachable from Phone / Mac launcher via relative link  
- `prefers-reduced-motion` not required, but avoid seizure-risk flashes  

**Not Done** if any gate fails — keep the card on roadmap or omit until fixed.

---

## Definition of Done — public emulator shell

| # | Gate |
|---|------|
| 1 | Under `apps/phone-simulator/` or `apps/mac-simulator/` with ORIGIN map |
| 2 | Static serve works; Messages (if present) on **presets** by default |
| 3 | Game launchers use **relative** public game paths |
| 4 | Touch or pointer usable for core navigation (home, open app, back) |
| 5 | No required Ollama; no gore; privacy clean |
| 6 | Lobby **Emulators** card links with honest badges |

---

## Anti-goals (explicit)

- Shipping the family’s local Ollama model as a dependency  
- Publishing multiplayer that needs a private always-on server without saying so  
- Merging gore-canon into the public pack “for authenticity”  
- Using children’s real names “just in a comment”  
- Treating a green local demo on `:878x` as Pages-ready  

---

## Versioning mindset

- **v0** — lobby + first games + preset architecture; emulator links may lead parallel work  
- **v1** — emulators + games all smoke-clean on real Pages URL  
- Later — more toys only through the DoD tables above  

Product questions default to: *Can a stranger on an iPhone open the link and have fun in under 30 seconds?*
